/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.16-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: churchcrm
-- ------------------------------------------------------
-- Server version	10.11.16-MariaDB-ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `calendar_events`
--

DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_events` (
  `calendar_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`calendar_id`,`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendar_events`
--

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
INSERT INTO `calendar_events` VALUES
(2,1),
(2,2),
(2,3);
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `calendars`
--

DROP TABLE IF EXISTS `calendars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendars` (
  `calendar_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `accesstoken` varchar(99) DEFAULT NULL,
  `foregroundColor` varchar(6) DEFAULT NULL,
  `backgroundColor` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`calendar_id`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `calendars`
--

LOCK TABLES `calendars` WRITE;
/*!40000 ALTER TABLE `calendars` DISABLE KEYS */;
INSERT INTO `calendars` VALUES
(1,'Public Calendar',NULL,'FFFFFF','00AA00'),
(2,'Private Calendar',NULL,'FFFFFF','0000AA'),
(3,'C',NULL,'FA8072','212F3D'),
(4,'Ca',NULL,'FA8072','212F3D'),
(5,'Ca',NULL,'FA8072','212F3D');
/*!40000 ALTER TABLE `calendars` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `config_cfg`
--

DROP TABLE IF EXISTS `config_cfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `config_cfg` (
  `cfg_name` varchar(50) NOT NULL DEFAULT '',
  `cfg_value` text DEFAULT NULL,
  PRIMARY KEY (`cfg_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `config_cfg`
--

LOCK TABLES `config_cfg` WRITE;
/*!40000 ALTER TABLE `config_cfg` DISABLE KEYS */;
INSERT INTO `config_cfg` VALUES
('aFinanceQueries','28,30,31,32'),
('bAllowPrereleaseUpgrade',''),
('bEnableExternalCalendarAPI','1'),
('bEnableNonDeductible',''),
('bEnableSelfRegistration','1'),
('bForceUppercaseZip',''),
('bHideFamilyNewsletter',''),
('bHideFriendDate',''),
('bHideWeddingDate',''),
('bPHPMailerAutoTLS',''),
('bRequire2FA',''),
('bSearchIncludeFamilyCustomProperties',''),
('bSendUserDeletedEmail',''),
('bSMTPAuth','0'),
('bUseDonationEnvelopes',''),
('bUseScannedChecks',''),
('iChurchLatitude','14.730037465858'),
('iChurchLongitude','-17.498531817648'),
('iMapZoom','7'),
('IncludeDataInNewPersonNotifications',''),
('plugin.external-backup.enabled','0'),
('plugin.holidays.categories','official,religious'),
('plugin.holidays.countries','USA'),
('plugin.holidays.enabled','1'),
('sChurchAddress','123 Main St'),
('sChurchChkAcctNum','111111111'),
('sChurchCity','Dakar'),
('sChurchCountry','SN'),
('sChurchEmail','demo@churchcrm.io'),
('sChurchName','CMCI Sénégal'),
('sChurchPhone','555 123 4234'),
('sChurchState','DK'),
('sChurchZip','13500'),
('sConfirmSigner','Elder Joe Smith'),
('sDefaultCity','Daar'),
('sDefaultCountry','SN'),
('sDefaultState','DK'),
('sDefaultZip','13500'),
('sDirectoryDisclaimer1','Every effort was made to insure the accuracy of this directory.  If there are any errors or omissions, please contact the church office.This directory is for the use of the people of'),
('sDistanceUnit','kilometers'),
('sLanguage','fr_FR'),
('sLogLevel','100'),
('sPHPMailerSMTPSecure',''),
('sPledgeSummary2','as of'),
('sReminderSigner','Elder Joe Smith'),
('sSMTPHost','mailserver:1025'),
('sSMTPPass',''),
('sSMTPUser',''),
('sSystemID','def13ac8-93e1-4dde-948b-ef899437d2f8'),
('sTaxSigner','Elder Joe Smith'),
('sTimeZone','Africa/Dakar'),
('sTwoFASecretKey','ChangeThisToASecureRandomStringBeforeUse');
/*!40000 ALTER TABLE `config_cfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit_dep`
--

DROP TABLE IF EXISTS `deposit_dep`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_dep` (
  `dep_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `dep_Date` date DEFAULT NULL,
  `dep_Comment` text DEFAULT NULL,
  `dep_EnteredBy` mediumint(9) unsigned DEFAULT NULL,
  `dep_Closed` tinyint(1) NOT NULL DEFAULT 0,
  `dep_Type` enum('Bank','CreditCard','BankDraft') NOT NULL DEFAULT 'Bank',
  PRIMARY KEY (`dep_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci PACK_KEYS=0;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit_dep`
--

LOCK TABLES `deposit_dep` WRITE;
/*!40000 ALTER TABLE `deposit_dep` DISABLE KEYS */;
INSERT INTO `deposit_dep` VALUES
(1,'2025-12-13','Updated Test Deposit',NULL,0,'Bank'),
(2,'2018-02-18','',NULL,0,'Bank'),
(3,'2018-02-25','',NULL,0,'Bank'),
(4,'2018-03-04','',NULL,0,'Bank'),
(5,'2018-03-11','',NULL,0,'Bank'),
(6,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(7,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(8,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(9,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(10,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(11,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(12,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(13,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(14,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(15,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(16,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(17,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(18,'2021-04-25','Selenium Test Deposit',NULL,0,'Bank'),
(20,'2025-12-13','Test Deposit',NULL,0,'Bank'),
(21,'2025-12-13','Test Deposit',NULL,0,'Bank');
/*!40000 ALTER TABLE `deposit_dep` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donateditem_di`
--

DROP TABLE IF EXISTS `donateditem_di`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `donateditem_di` (
  `di_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `di_item` varchar(32) NOT NULL,
  `di_FR_ID` mediumint(9) unsigned NOT NULL,
  `di_donor_ID` mediumint(9) NOT NULL DEFAULT 0,
  `di_buyer_ID` mediumint(9) NOT NULL DEFAULT 0,
  `di_multibuy` smallint(1) NOT NULL DEFAULT 0,
  `di_title` varchar(128) NOT NULL,
  `di_description` text DEFAULT NULL,
  `di_sellprice` decimal(8,2) DEFAULT NULL,
  `di_estprice` decimal(8,2) DEFAULT NULL,
  `di_minimum` decimal(8,2) DEFAULT NULL,
  `di_materialvalue` decimal(8,2) DEFAULT NULL,
  `di_EnteredBy` smallint(5) unsigned NOT NULL DEFAULT 0,
  `di_EnteredDate` date NOT NULL,
  `di_picture` text DEFAULT NULL,
  PRIMARY KEY (`di_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donateditem_di`
--

LOCK TABLES `donateditem_di` WRITE;
/*!40000 ALTER TABLE `donateditem_di` DISABLE KEYS */;
/*!40000 ALTER TABLE `donateditem_di` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donationfund_fun`
--

DROP TABLE IF EXISTS `donationfund_fun`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `donationfund_fun` (
  `fun_ID` tinyint(3) NOT NULL AUTO_INCREMENT,
  `fun_Active` enum('true','false') NOT NULL DEFAULT 'true',
  `fun_Name` varchar(30) DEFAULT NULL,
  `fun_Description` varchar(100) DEFAULT NULL,
  `fun_Order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`fun_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `donationfund_fun`
--

LOCK TABLES `donationfund_fun` WRITE;
/*!40000 ALTER TABLE `donationfund_fun` DISABLE KEYS */;
INSERT INTO `donationfund_fun` VALUES
(1,'true','Pledges','Pledge income for the operating budget',1),
(2,'true','New Building Fund','',2),
(3,'true','Music Ministry','',3);
/*!40000 ALTER TABLE `donationfund_fun` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `email_count`
--

DROP TABLE IF EXISTS `email_count`;
/*!50001 DROP VIEW IF EXISTS `email_count`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `email_count` AS SELECT
 1 AS `email`,
  1 AS `total` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `email_list`
--

DROP TABLE IF EXISTS `email_list`;
/*!50001 DROP VIEW IF EXISTS `email_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8mb4;
/*!50001 CREATE VIEW `email_list` AS SELECT
 1 AS `email`,
  1 AS `type`,
  1 AS `id` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `event_attend`
--

DROP TABLE IF EXISTS `event_attend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_attend` (
  `attend_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL DEFAULT 0,
  `person_id` int(11) NOT NULL DEFAULT 0,
  `checkin_date` datetime DEFAULT NULL,
  `checkin_id` int(11) DEFAULT NULL,
  `checkout_date` datetime DEFAULT NULL,
  `checkout_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`attend_id`),
  UNIQUE KEY `event_id` (`event_id`,`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_attend`
--

LOCK TABLES `event_attend` WRITE;
/*!40000 ALTER TABLE `event_attend` DISABLE KEYS */;
INSERT INTO `event_attend` VALUES
(1,3,104,'2017-04-15 17:23:46',26,NULL,NULL);
/*!40000 ALTER TABLE `event_attend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_audience`
--

DROP TABLE IF EXISTS `event_audience`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_audience` (
  `event_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`event_id`,`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_audience`
--

LOCK TABLES `event_audience` WRITE;
/*!40000 ALTER TABLE `event_audience` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_audience` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `event_types`
--

DROP TABLE IF EXISTS `event_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `event_types` (
  `type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(255) NOT NULL DEFAULT '',
  `type_defstarttime` time NOT NULL DEFAULT '00:00:00',
  `type_defrecurtype` enum('none','weekly','monthly','yearly') NOT NULL DEFAULT 'none',
  `type_defrecurDOW` enum('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday') NOT NULL DEFAULT 'Sunday',
  `type_defrecurDOM` char(2) NOT NULL DEFAULT '0',
  `type_defrecurDOY` date NOT NULL DEFAULT '2016-01-01',
  `type_active` int(1) NOT NULL DEFAULT 1,
  `type_grpid` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `event_types`
--

LOCK TABLES `event_types` WRITE;
/*!40000 ALTER TABLE `event_types` DISABLE KEYS */;
INSERT INTO `event_types` VALUES
(1,'Church Service','10:30:00','weekly','Sunday','','2016-01-01',1,NULL),
(2,'Sunday School','09:30:00','weekly','Sunday','','2016-01-01',1,NULL);
/*!40000 ALTER TABLE `event_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventcountnames_evctnm`
--

DROP TABLE IF EXISTS `eventcountnames_evctnm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventcountnames_evctnm` (
  `evctnm_countid` int(5) NOT NULL AUTO_INCREMENT,
  `evctnm_eventtypeid` smallint(5) NOT NULL DEFAULT 0,
  `evctnm_countname` varchar(20) NOT NULL DEFAULT '',
  `evctnm_notes` varchar(20) NOT NULL DEFAULT '',
  UNIQUE KEY `evctnm_countid` (`evctnm_countid`),
  UNIQUE KEY `evctnm_eventtypeid` (`evctnm_eventtypeid`,`evctnm_countname`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventcountnames_evctnm`
--

LOCK TABLES `eventcountnames_evctnm` WRITE;
/*!40000 ALTER TABLE `eventcountnames_evctnm` DISABLE KEYS */;
INSERT INTO `eventcountnames_evctnm` VALUES
(1,1,'Total',''),
(2,1,'Members',''),
(3,1,'Visitors',''),
(4,2,'Total',''),
(5,2,'Members',''),
(6,2,'Visitors','');
/*!40000 ALTER TABLE `eventcountnames_evctnm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `eventcounts_evtcnt`
--

DROP TABLE IF EXISTS `eventcounts_evtcnt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `eventcounts_evtcnt` (
  `evtcnt_eventid` int(5) NOT NULL DEFAULT 0,
  `evtcnt_countid` int(5) NOT NULL DEFAULT 0,
  `evtcnt_countname` varchar(20) DEFAULT NULL,
  `evtcnt_countcount` int(6) DEFAULT NULL,
  `evtcnt_notes` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`evtcnt_eventid`,`evtcnt_countid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eventcounts_evtcnt`
--

LOCK TABLES `eventcounts_evtcnt` WRITE;
/*!40000 ALTER TABLE `eventcounts_evtcnt` DISABLE KEYS */;
INSERT INTO `eventcounts_evtcnt` VALUES
(1,4,'Total',25,''),
(1,5,'Members',10,''),
(1,6,'Visitors',0,''),
(2,1,'Total',100,''),
(2,2,'Members',0,''),
(2,3,'Visitors',0,''),
(3,4,'Total',100,''),
(3,5,'Members',0,''),
(3,6,'Visitors',0,'');
/*!40000 ALTER TABLE `eventcounts_evtcnt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events_event`
--

DROP TABLE IF EXISTS `events_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `events_event` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_type` int(11) NOT NULL DEFAULT 0,
  `event_title` varchar(255) NOT NULL DEFAULT '',
  `event_desc` varchar(255) DEFAULT NULL,
  `event_text` text DEFAULT NULL,
  `event_start` datetime NOT NULL,
  `event_end` datetime NOT NULL,
  `inactive` int(1) NOT NULL DEFAULT 0,
  `location_id` int(11) DEFAULT NULL,
  `secondary_contact_person_id` int(11) DEFAULT NULL,
  `primary_contact_person_id` int(11) DEFAULT NULL,
  `event_url` text DEFAULT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events_event`
--

LOCK TABLES `events_event` WRITE;
/*!40000 ALTER TABLE `events_event` DISABLE KEYS */;
INSERT INTO `events_event` VALUES
(1,2,'Sunday School Class Changes','This is when the students move to new classes','','2016-11-20 12:30:00','2016-11-20 13:30:00',0,NULL,NULL,NULL,NULL),
(2,1,'Christmas Service','christmas service','','2016-12-24 22:30:00','2016-12-25 01:30:00',0,NULL,NULL,NULL,NULL),
(3,2,'Summer Camp','Summer Camp','','2017-06-06 09:30:00','2017-06-11 09:30:00',0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `events_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family_custom`
--

DROP TABLE IF EXISTS `family_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `family_custom` (
  `fam_ID` mediumint(9) NOT NULL DEFAULT 0,
  `c1` mediumint(9) DEFAULT NULL,
  `c2` varchar(30) DEFAULT NULL,
  `c3` enum('winter','spring','summer','fall') DEFAULT NULL,
  `c4` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`fam_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family_custom`
--

LOCK TABLES `family_custom` WRITE;
/*!40000 ALTER TABLE `family_custom` DISABLE KEYS */;
INSERT INTO `family_custom` VALUES
(1016,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `family_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family_custom_master`
--

DROP TABLE IF EXISTS `family_custom_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `family_custom_master` (
  `fam_custom_Order` smallint(6) NOT NULL DEFAULT 0,
  `fam_custom_Field` varchar(5) NOT NULL DEFAULT '',
  `fam_custom_Name` varchar(40) NOT NULL DEFAULT '',
  `fam_custom_Special` mediumint(8) unsigned DEFAULT NULL,
  `fam_custom_FieldSec` tinyint(4) NOT NULL DEFAULT 1,
  `type_ID` tinyint(4) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family_custom_master`
--

LOCK TABLES `family_custom_master` WRITE;
/*!40000 ALTER TABLE `family_custom_master` DISABLE KEYS */;
INSERT INTO `family_custom_master` VALUES
(1,'c1','Sponser',9,1,9),
(2,'c2','Emergency Phone',NULL,1,11),
(3,'c3','Vacation Season',NULL,1,7),
(4,'c4','Family Custom Drop Down List',25,1,12);
/*!40000 ALTER TABLE `family_custom_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `family_fam`
--

DROP TABLE IF EXISTS `family_fam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `family_fam` (
  `fam_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `fam_Name` varchar(50) DEFAULT NULL,
  `fam_Address1` varchar(255) DEFAULT NULL,
  `fam_Address2` varchar(255) DEFAULT NULL,
  `fam_City` varchar(50) DEFAULT NULL,
  `fam_State` varchar(50) DEFAULT NULL,
  `fam_Zip` varchar(50) DEFAULT NULL,
  `fam_Country` varchar(50) DEFAULT NULL,
  `fam_HomePhone` varchar(30) DEFAULT NULL,
  `fam_Email` varchar(100) DEFAULT NULL,
  `fam_WeddingDate` date DEFAULT NULL,
  `fam_DateEntered` datetime NOT NULL,
  `fam_DateLastEdited` datetime DEFAULT NULL,
  `fam_EnteredBy` smallint(5) NOT NULL DEFAULT 0,
  `fam_EditedBy` smallint(5) unsigned DEFAULT 0,
  `fam_scanCheck` text DEFAULT NULL,
  `fam_scanCredit` text DEFAULT NULL,
  `fam_SendNewsLetter` enum('FALSE','TRUE') NOT NULL DEFAULT 'FALSE',
  `fam_DateDeactivated` date DEFAULT NULL,
  `fam_Latitude` double DEFAULT NULL,
  `fam_Longitude` double DEFAULT NULL,
  `fam_Envelope` mediumint(9) NOT NULL DEFAULT 0,
  PRIMARY KEY (`fam_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1075 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `family_fam`
--

LOCK TABLES `family_fam` WRITE;
/*!40000 ALTER TABLE `family_fam` DISABLE KEYS */;
INSERT INTO `family_fam` VALUES
(1006,'Assemblée chez les BAGOA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1007,'Assemblee chez Nemlin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1008,'Assemblée chez les YOTA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1009,'Assemblée chez les NAKIZENON',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1010,'Assemblée chez les METINOU',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1011,'Assemblée chez Northya',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1012,'Assemblee chez les KOFFI',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1013,'Assemblée chez la famille SAGNA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1014,'Assemblée chez Mane DIOUF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1015,'Assemblee chez Maxime',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1016,'Assemblée chez Alphonsine','','','','DK','','SN','','',NULL,'2026-05-02 07:57:59','2026-05-02 09:36:17',1,1492,NULL,NULL,'FALSE',NULL,14.702255885187,-17.463948273316,0),
(1017,'Assemblee chez Amex',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1018,'Assemblee chez TSAMBA Princesse',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1019,'Assemblée chez les BAKAM',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1020,'Assemblée chez Bandiaky',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1021,'Assemblée chez les OSSA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1022,'Assemblee chez les NKOUNKOU',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1023,'Assemblée chez Armelle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1024,'Assemblée chez Ghislain',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:57:59',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1025,'Assemblée chez Jennifer OSSEY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1026,'Assemblée chez Eric',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1027,'Assemblée chez Samyrah',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1028,'Assemblée chez Marcelle Olive',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1029,'Assemblée chez Elisabeth V',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1030,'Assemblée chez Fabiola',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1031,'Assemblée chez Britch',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1032,'Assemblée chez Sepha',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1033,'Assemblée chez Leila Chatare',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1034,'Assemblee chez Emmanuel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1035,'Assemblee chez Emmanuely',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1036,'Assemblee chez Hanniel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1037,'Assemblee chez Reveli',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1038,'Assemblée chez les KOSSONOU',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1039,'Assemblee chez Christophe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1040,'Assemblée chez Maryse',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1041,'Assemblée chez Docteur Joe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1042,'Assemblee chez Roy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1043,'Assemblée chez Cyr',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1044,'Assemblee chez Marie BIVEGHE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1045,'Assemblée chez Christian',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1046,'Assemblées chez les MALONGA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1047,'Assemblée chez Doriane WOUAMBA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1048,'Assemblée chez Yasid',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1049,'Assemblée chez les AKPO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1050,'Assemblée chez Nash',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1051,'Assemblée chez Ulrich',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1052,'Assemblée chez les NDOSSANI',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1053,'Assemblee chez les BOLEGA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1054,'Assemblee chez Lisa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1055,'Assemblée chez Jov',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1056,'Assemblée chez Marisa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1057,'Assemblée chez Loriz',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1058,'Assemblee chez Gloria',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1059,'Assemblée chez Heather',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1060,'Assemblee chez DIMI Ravel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1061,'Assemblee chez Joana',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1062,'Assemblée chez Oméga',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1063,'Assemblee chez Silnelle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1064,'Assemblee chez Karene',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1065,'Assemblée chez Darcy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1066,'Assemblee chez Marie-Noëlle',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1067,'Assemblée de maison chez TOTO Privat',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1068,'Assemblée chez Jéhovah jireh',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1069,'Assemblée chez Belcera',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1070,'Assemblée chez Rachel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1071,'Assemblee chez Vanne Henry',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1072,'Assemblee chez Edward',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:00',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1073,'Administrateur',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 07:58:35',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0),
(1074,'Administrateur',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-02 08:04:33',NULL,1,0,NULL,NULL,'FALSE',NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `family_fam` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fundraiser_fr`
--

DROP TABLE IF EXISTS `fundraiser_fr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fundraiser_fr` (
  `fr_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `fr_date` date DEFAULT NULL,
  `fr_title` varchar(128) NOT NULL,
  `fr_description` text DEFAULT NULL,
  `fr_EnteredBy` smallint(5) unsigned NOT NULL DEFAULT 0,
  `fr_EnteredDate` date NOT NULL,
  PRIMARY KEY (`fr_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fundraiser_fr`
--

LOCK TABLES `fundraiser_fr` WRITE;
/*!40000 ALTER TABLE `fundraiser_fr` DISABLE KEYS */;
INSERT INTO `fundraiser_fr` VALUES
(1,'2016-11-19','2016 Car Wash','Youth Car Wash',1,'2016-11-19');
/*!40000 ALTER TABLE `fundraiser_fr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_grp`
--

DROP TABLE IF EXISTS `group_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_grp` (
  `grp_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `grp_Type` tinyint(4) NOT NULL DEFAULT 0,
  `grp_RoleListID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `grp_DefaultRole` mediumint(9) NOT NULL DEFAULT 0,
  `grp_Name` varchar(50) NOT NULL DEFAULT '',
  `grp_Description` text DEFAULT NULL,
  `grp_hasSpecialProps` tinyint(1) NOT NULL DEFAULT 0,
  `grp_active` tinyint(1) NOT NULL DEFAULT 1,
  `grp_include_email_export` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`grp_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_grp`
--

LOCK TABLES `group_grp` WRITE;
/*!40000 ALTER TABLE `group_grp` DISABLE KEYS */;
INSERT INTO `group_grp` VALUES
(1,4,13,2,'Angels class',NULL,0,1,1),
(2,4,14,2,'Class 1-3',NULL,0,1,1),
(3,4,15,2,'Class 4-5',NULL,0,1,1),
(4,4,16,2,'Class 6-7',NULL,0,1,1),
(5,4,17,2,'High School Class',NULL,0,1,1),
(6,4,18,2,'Youth Meeting',NULL,0,1,1),
(7,0,19,1,'Boys Scouts',NULL,0,1,1),
(8,0,20,1,'Girl Scouts',NULL,0,0,0),
(9,0,21,1,'Church Board',NULL,0,1,0),
(10,1,22,1,'Worship Service','',1,1,1),
(11,0,23,1,'Clergy',NULL,0,1,1),
(12,0,26,1,'New Test Group',NULL,0,1,1),
(13,0,27,1,'New Test Group',NULL,0,1,1),
(14,0,28,1,'New Test Group',NULL,0,1,1),
(15,0,29,1,'New Test Group',NULL,0,1,1),
(16,0,30,1,'New Test Group',NULL,0,1,1),
(17,0,31,1,'New Test Group',NULL,0,1,1),
(18,0,32,1,'New Test Group',NULL,0,1,1),
(19,0,33,1,'New Test Group',NULL,0,1,1),
(20,0,34,1,'New Test Group',NULL,0,1,1),
(21,0,35,1,'New Test Group',NULL,0,1,1),
(22,0,36,1,'New Test Group',NULL,0,1,1),
(23,0,37,1,'sdfsdfsdf',NULL,1,1,1),
(27,4,0,2,'Groupe de chants','Responsable: Jean - Membres: Marie, Pierre',0,1,1),
(28,4,0,2,'Groupe de jeunes','Responsable: Paul - Membres: Jacques, Thomas',0,1,1);
/*!40000 ALTER TABLE `group_grp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_1`
--

DROP TABLE IF EXISTS `groupprop_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_1` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`per_ID`),
  UNIQUE KEY `per_ID` (`per_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_1`
--

LOCK TABLES `groupprop_1` WRITE;
/*!40000 ALTER TABLE `groupprop_1` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupprop_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_10`
--

DROP TABLE IF EXISTS `groupprop_10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_10` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`per_ID`),
  UNIQUE KEY `per_ID` (`per_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_10`
--

LOCK TABLES `groupprop_10` WRITE;
/*!40000 ALTER TABLE `groupprop_10` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupprop_10` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_11`
--

DROP TABLE IF EXISTS `groupprop_11`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_11` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_11`
--

LOCK TABLES `groupprop_11` WRITE;
/*!40000 ALTER TABLE `groupprop_11` DISABLE KEYS */;
INSERT INTO `groupprop_11` VALUES
(26,NULL),
(33,NULL),
(34,NULL),
(37,NULL),
(100,NULL),
(125,NULL),
(134,NULL),
(293,NULL),
(349,NULL),
(374,NULL),
(649,NULL),
(650,NULL);
/*!40000 ALTER TABLE `groupprop_11` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_13`
--

DROP TABLE IF EXISTS `groupprop_13`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_13` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_13`
--

LOCK TABLES `groupprop_13` WRITE;
/*!40000 ALTER TABLE `groupprop_13` DISABLE KEYS */;
INSERT INTO `groupprop_13` VALUES
(79,NULL),
(141,NULL),
(240,NULL),
(257,NULL),
(273,NULL),
(295,NULL),
(297,NULL),
(307,NULL),
(322,NULL),
(337,NULL),
(350,NULL),
(370,NULL),
(386,NULL),
(583,NULL),
(654,NULL),
(668,NULL),
(670,NULL),
(671,NULL);
/*!40000 ALTER TABLE `groupprop_13` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_17`
--

DROP TABLE IF EXISTS `groupprop_17`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_17` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` enum('false','true') DEFAULT NULL,
  `c2` tinyint(4) DEFAULT NULL,
  `c3` int(11) DEFAULT NULL,
  `c4` varchar(100) DEFAULT NULL,
  `c6` date DEFAULT NULL,
  `c7` varchar(100) DEFAULT NULL,
  `c8` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_17`
--

LOCK TABLES `groupprop_17` WRITE;
/*!40000 ALTER TABLE `groupprop_17` DISABLE KEYS */;
INSERT INTO `groupprop_17` VALUES
(2,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,NULL,4,NULL,NULL,'2014-08-31','Bishop Youssef','Too young'),
(5,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(26,'true',1,3,'David','2010-10-02','H.G. Bishop David',NULL),
(29,NULL,2,NULL,NULL,'2008-05-17','H.G. Bishop Bola','Asked to be excluded'),
(34,NULL,1,2,NULL,'2009-04-25','H.G. Bishop Abakeer','Asked to be excluded'),
(59,NULL,2,NULL,NULL,NULL,NULL,NULL),
(64,'true',1,1,'Kiriakos','2010-10-02','H.G. Bishop David','Add later'),
(79,NULL,2,NULL,NULL,'1994-07-01','H.G. Bishop Beshoy',NULL),
(88,NULL,1,NULL,'George','1989-04-01','H.G. Bishop Mettaos',NULL),
(89,NULL,2,NULL,NULL,'1995-06-15','H.G. Bishop Tadros',NULL),
(91,NULL,2,NULL,NULL,NULL,NULL,'Fady to get info'),
(97,NULL,2,NULL,NULL,'1995-05-28','H.G. Bishop Samuel',NULL),
(141,NULL,1,5,NULL,'2011-06-01','H.G. Bishop Aghathon',NULL),
(145,NULL,1,NULL,'Mousa','1995-06-26','H.G. Bishop Pisenti','Asked to be excluded'),
(154,NULL,2,NULL,NULL,'1998-07-09','H.G. Bishop Abraam',NULL),
(183,NULL,2,1,'Guirgis','2009-04-25','H.G. Bishop Abakeer',NULL),
(185,NULL,2,NULL,NULL,NULL,NULL,NULL),
(190,NULL,2,NULL,NULL,NULL,NULL,NULL),
(194,NULL,2,NULL,NULL,'1995-06-15','H. G. Bishop Domadius',NULL),
(208,NULL,2,NULL,NULL,'1996-04-14','H.G. Bishop Philoppos',NULL),
(216,'true',1,2,'Abanoub','2010-10-02','H.G. Bishop David',NULL),
(235,'true',1,NULL,'Stefanos','2003-05-17','H.G. Bishop Bola',NULL),
(240,NULL,3,NULL,NULL,NULL,NULL,NULL),
(242,NULL,2,NULL,NULL,'1995-06-24','H.G. Bishop Bola',NULL),
(244,NULL,2,NULL,NULL,'1995-06-14','H.H. Pope Shenouda III',NULL),
(249,NULL,1,NULL,NULL,NULL,'H.G. Bishop Abakeer',NULL),
(257,NULL,2,NULL,NULL,'2004-01-01','H.G. Bishop Bola','Asked to be excluded'),
(285,NULL,2,NULL,'George',NULL,NULL,'Asked to be exclude'),
(293,'true',1,3,NULL,'2009-04-25','H.G. Bishop Abakeer',NULL),
(297,NULL,2,NULL,NULL,NULL,NULL,NULL),
(299,NULL,2,NULL,NULL,NULL,NULL,NULL),
(300,NULL,3,2,NULL,'2008-05-17','H.G. Bishop Bola',NULL),
(301,NULL,4,5,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(303,NULL,4,3,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(307,'true',1,4,'Guirgis','2010-10-02',NULL,'H.G. Bishop David'),
(311,NULL,4,NULL,NULL,'2011-05-22','H.G. Bishop Aghathon','Too young'),
(317,NULL,3,3,NULL,'2010-10-02','H.G. Bishop David',NULL),
(320,NULL,4,NULL,NULL,NULL,NULL,'Too young'),
(321,NULL,NULL,NULL,'Michael','2005-05-01','H.G. Bishop Bola',NULL),
(323,NULL,2,NULL,'Michael','1995-05-31','H.G. Bishop Antonious Markos',NULL),
(331,NULL,3,NULL,NULL,'2010-10-02','H.G. Bishop David',NULL),
(338,NULL,2,NULL,'Boktor','2007-11-01','H.G. Bishop Mettaos',NULL),
(339,NULL,2,NULL,NULL,'1995-06-28','H.G. Bishop Abakeer',NULL),
(342,NULL,4,NULL,NULL,NULL,NULL,'Too young'),
(343,NULL,2,NULL,NULL,NULL,NULL,'Add later'),
(344,'false',4,4,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(348,NULL,2,NULL,NULL,NULL,'H.G. Bishop Pisenti',NULL),
(349,'true',1,NULL,NULL,'2010-10-02','H.G. Bishop David',NULL),
(350,NULL,2,NULL,'George','2013-10-19','H.G. Bishop Sarafem',NULL),
(351,'true',1,NULL,NULL,'1995-05-31','H.G. Bishop Philoppos',NULL),
(352,NULL,3,1,NULL,'2013-10-19','H.G. Bishop Sarafem',NULL),
(353,NULL,3,NULL,NULL,'2011-01-01','H.G. Bishop Theodosius',NULL),
(354,NULL,1,NULL,NULL,'1995-06-10','H.G. Bishop Mettaos','Asked to be excluded'),
(355,NULL,4,8,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(356,NULL,1,NULL,NULL,'2010-06-25','H.G. Bishop Aghathon','St. Mary - Can\'t do Sunday'),
(357,NULL,1,NULL,'Ibrahim','1995-05-21',NULL,NULL),
(358,NULL,2,NULL,NULL,NULL,NULL,'Asked to be excluded'),
(360,NULL,2,NULL,NULL,NULL,'H.G. Bishop Abakeer',NULL),
(362,NULL,3,1,NULL,'2008-05-17','H.G. Bishop Bola',NULL),
(363,NULL,4,7,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(364,NULL,4,6,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(365,NULL,4,2,NULL,'2013-10-19','H.G. Bishop Sarafem','Too young'),
(366,NULL,3,NULL,NULL,'1995-07-04','H.G. Bishop Theodosius',NULL),
(367,NULL,2,NULL,NULL,NULL,NULL,'Add in June'),
(369,NULL,1,NULL,NULL,'1995-05-29','H.G. Bishop Domadius','Asked to be excluded'),
(370,NULL,2,NULL,NULL,'2003-05-17','H.G. Bishop Bola',NULL),
(371,NULL,1,NULL,'Andraous',NULL,NULL,'St. Mary - Can\'t do Sunday'),
(372,NULL,3,NULL,NULL,'2010-07-27','H.G. Bishop David',NULL),
(373,NULL,3,NULL,NULL,NULL,NULL,'Fady to get info'),
(374,NULL,3,NULL,NULL,NULL,NULL,NULL),
(375,NULL,3,NULL,NULL,NULL,NULL,'Fady to get info'),
(376,NULL,2,NULL,NULL,NULL,NULL,NULL),
(377,'true',1,1,'Mikhael','1995-06-28','H.G. Bishop Aghathon',NULL),
(378,NULL,2,NULL,NULL,NULL,NULL,NULL),
(379,NULL,3,2,NULL,'2010-10-02','H.G. Bishop David','Add in April'),
(380,NULL,3,5,NULL,'2010-10-02','H.G. Bishop David',NULL),
(381,NULL,2,1,NULL,NULL,NULL,'Asked to be excluded'),
(382,NULL,3,NULL,NULL,'2010-10-02','H.G. Bishop David',NULL),
(383,NULL,2,2,NULL,'2008-05-17','H.G. Bishop Bola',NULL),
(385,NULL,3,6,NULL,'2010-10-02','H.G. Bishop David',NULL),
(386,NULL,3,6,NULL,'2008-05-17','H.G. Bishop Bola',NULL),
(387,NULL,3,7,NULL,'2008-05-17','H.G. Bishop Bola',NULL),
(388,NULL,2,NULL,NULL,NULL,NULL,'St. Mary - Can\'t commit'),
(389,NULL,2,NULL,NULL,NULL,NULL,'St. Mary - Can\'t commit'),
(390,NULL,2,NULL,NULL,NULL,NULL,'Hani to get info'),
(391,NULL,2,NULL,NULL,NULL,NULL,NULL),
(645,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `groupprop_17` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_2`
--

DROP TABLE IF EXISTS `groupprop_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_2` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL,
  `c2` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_2`
--

LOCK TABLES `groupprop_2` WRITE;
/*!40000 ALTER TABLE `groupprop_2` DISABLE KEYS */;
INSERT INTO `groupprop_2` VALUES
(4,NULL,2),
(151,NULL,NULL),
(293,NULL,NULL),
(301,NULL,1),
(304,NULL,NULL),
(309,NULL,NULL),
(311,NULL,1),
(314,NULL,2),
(319,NULL,NULL),
(328,NULL,NULL),
(344,NULL,1),
(363,NULL,NULL),
(364,NULL,NULL),
(385,NULL,NULL),
(448,NULL,NULL),
(572,NULL,3),
(576,NULL,3),
(617,NULL,NULL),
(618,NULL,1),
(633,NULL,1),
(634,NULL,1),
(635,NULL,NULL),
(636,NULL,NULL),
(637,NULL,NULL),
(639,NULL,1),
(661,NULL,NULL),
(727,NULL,NULL),
(749,NULL,NULL),
(759,NULL,NULL),
(760,NULL,NULL),
(766,NULL,NULL),
(774,NULL,NULL),
(777,NULL,NULL),
(778,NULL,NULL);
/*!40000 ALTER TABLE `groupprop_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_20`
--

DROP TABLE IF EXISTS `groupprop_20`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_20` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_20`
--

LOCK TABLES `groupprop_20` WRITE;
/*!40000 ALTER TABLE `groupprop_20` DISABLE KEYS */;
INSERT INTO `groupprop_20` VALUES
(5,NULL),
(37,NULL),
(51,NULL),
(94,NULL),
(305,NULL),
(310,NULL),
(312,NULL),
(320,NULL),
(325,NULL),
(342,NULL),
(355,NULL),
(589,NULL),
(602,NULL),
(611,NULL),
(620,NULL),
(621,NULL),
(629,NULL),
(641,NULL),
(649,NULL),
(657,NULL),
(660,NULL),
(761,NULL),
(769,NULL),
(784,NULL),
(789,NULL),
(797,NULL),
(829,NULL),
(855,NULL),
(860,NULL);
/*!40000 ALTER TABLE `groupprop_20` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_23`
--

DROP TABLE IF EXISTS `groupprop_23`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_23` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` year(4) DEFAULT NULL,
  PRIMARY KEY (`per_ID`),
  UNIQUE KEY `per_ID` (`per_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_23`
--

LOCK TABLES `groupprop_23` WRITE;
/*!40000 ALTER TABLE `groupprop_23` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupprop_23` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_25`
--

DROP TABLE IF EXISTS `groupprop_25`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_25` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` enum('false','true') DEFAULT NULL,
  `c2` int(11) DEFAULT NULL,
  `c3` date DEFAULT NULL,
  PRIMARY KEY (`per_ID`),
  UNIQUE KEY `per_ID` (`per_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_25`
--

LOCK TABLES `groupprop_25` WRITE;
/*!40000 ALTER TABLE `groupprop_25` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupprop_25` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_45`
--

DROP TABLE IF EXISTS `groupprop_45`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_45` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_45`
--

LOCK TABLES `groupprop_45` WRITE;
/*!40000 ALTER TABLE `groupprop_45` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupprop_45` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_47`
--

DROP TABLE IF EXISTS `groupprop_47`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_47` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_47`
--

LOCK TABLES `groupprop_47` WRITE;
/*!40000 ALTER TABLE `groupprop_47` DISABLE KEYS */;
INSERT INTO `groupprop_47` VALUES
(0);
/*!40000 ALTER TABLE `groupprop_47` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_49`
--

DROP TABLE IF EXISTS `groupprop_49`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_49` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_49`
--

LOCK TABLES `groupprop_49` WRITE;
/*!40000 ALTER TABLE `groupprop_49` DISABLE KEYS */;
/*!40000 ALTER TABLE `groupprop_49` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_6`
--

DROP TABLE IF EXISTS `groupprop_6`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_6` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_6`
--

LOCK TABLES `groupprop_6` WRITE;
/*!40000 ALTER TABLE `groupprop_6` DISABLE KEYS */;
INSERT INTO `groupprop_6` VALUES
(131,NULL),
(326,NULL),
(334,NULL),
(398,NULL),
(590,NULL),
(601,NULL),
(603,NULL),
(607,NULL),
(608,NULL),
(609,NULL),
(612,NULL),
(613,NULL),
(622,NULL),
(652,NULL),
(653,NULL),
(674,NULL),
(675,NULL),
(703,NULL),
(729,NULL),
(754,NULL),
(757,NULL),
(770,NULL),
(773,NULL),
(781,NULL),
(785,NULL),
(788,NULL),
(798,NULL),
(852,NULL),
(862,NULL);
/*!40000 ALTER TABLE `groupprop_6` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_7`
--

DROP TABLE IF EXISTS `groupprop_7`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_7` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` date DEFAULT NULL,
  `c2` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_7`
--

LOCK TABLES `groupprop_7` WRITE;
/*!40000 ALTER TABLE `groupprop_7` DISABLE KEYS */;
INSERT INTO `groupprop_7` VALUES
(39,NULL,NULL),
(42,NULL,NULL),
(104,NULL,NULL),
(134,NULL,NULL),
(216,NULL,NULL),
(300,NULL,1),
(303,NULL,NULL),
(313,NULL,2),
(318,NULL,2),
(327,NULL,1),
(331,NULL,2),
(365,NULL,NULL),
(573,NULL,NULL),
(575,NULL,1),
(577,NULL,1),
(581,NULL,2),
(582,NULL,2),
(662,NULL,NULL),
(663,NULL,NULL),
(664,NULL,1),
(665,NULL,2),
(748,NULL,NULL);
/*!40000 ALTER TABLE `groupprop_7` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_9`
--

DROP TABLE IF EXISTS `groupprop_9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_9` (
  `per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `c1` tinyint(4) DEFAULT NULL,
  `c2` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_9`
--

LOCK TABLES `groupprop_9` WRITE;
/*!40000 ALTER TABLE `groupprop_9` DISABLE KEYS */;
INSERT INTO `groupprop_9` VALUES
(47,NULL,NULL),
(170,NULL,NULL),
(190,NULL,NULL),
(285,NULL,NULL),
(296,2,NULL),
(317,1,NULL),
(321,2,NULL),
(329,NULL,NULL),
(330,2,NULL),
(352,2,NULL),
(362,1,NULL),
(373,1,NULL),
(379,1,NULL),
(382,NULL,NULL),
(578,1,NULL),
(579,1,NULL),
(580,NULL,NULL),
(584,1,NULL),
(585,NULL,NULL),
(586,2,NULL),
(669,NULL,NULL);
/*!40000 ALTER TABLE `groupprop_9` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groupprop_master`
--

DROP TABLE IF EXISTS `groupprop_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `groupprop_master` (
  `grp_ID` mediumint(9) unsigned NOT NULL DEFAULT 0,
  `prop_ID` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `prop_Field` varchar(5) NOT NULL DEFAULT '0',
  `prop_Name` varchar(40) DEFAULT NULL,
  `prop_Description` varchar(60) DEFAULT NULL,
  `type_ID` smallint(5) unsigned NOT NULL DEFAULT 0,
  `prop_Special` mediumint(9) unsigned DEFAULT NULL,
  `prop_PersonDisplay` enum('false','true') NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Group-specific properties order, name, description, type';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groupprop_master`
--

LOCK TABLES `groupprop_master` WRITE;
/*!40000 ALTER TABLE `groupprop_master` DISABLE KEYS */;
INSERT INTO `groupprop_master` VALUES
(23,1,'c1','sdfsaf','',6,NULL,'false');
/*!40000 ALTER TABLE `groupprop_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kioskassginment_kasm`
--

DROP TABLE IF EXISTS `kioskassginment_kasm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kioskassginment_kasm` (
  `kasm_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `kasm_kdevId` mediumint(9) DEFAULT NULL,
  `kasm_AssignmentType` mediumint(9) DEFAULT NULL,
  `kasm_EventId` mediumint(9) DEFAULT 0,
  PRIMARY KEY (`kasm_ID`),
  UNIQUE KEY `kasm_ID` (`kasm_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kioskassginment_kasm`
--

LOCK TABLES `kioskassginment_kasm` WRITE;
/*!40000 ALTER TABLE `kioskassginment_kasm` DISABLE KEYS */;
/*!40000 ALTER TABLE `kioskassginment_kasm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kioskdevice_kdev`
--

DROP TABLE IF EXISTS `kioskdevice_kdev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `kioskdevice_kdev` (
  `kdev_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `kdev_GUIDHash` char(64) DEFAULT NULL,
  `kdev_Name` varchar(50) DEFAULT NULL,
  `kdev_deviceType` mediumint(9) NOT NULL DEFAULT 0,
  `kdev_lastHeartbeat` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `kdev_Accepted` tinyint(1) DEFAULT NULL,
  `kdev_PendingCommands` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`kdev_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kioskdevice_kdev`
--

LOCK TABLES `kioskdevice_kdev` WRITE;
/*!40000 ALTER TABLE `kioskdevice_kdev` DISABLE KEYS */;
/*!40000 ALTER TABLE `kioskdevice_kdev` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_lst`
--

DROP TABLE IF EXISTS `list_lst`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `list_lst` (
  `lst_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `lst_OptionID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `lst_OptionSequence` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `lst_OptionName` varchar(50) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_lst`
--

LOCK TABLES `list_lst` WRITE;
/*!40000 ALTER TABLE `list_lst` DISABLE KEYS */;
INSERT INTO `list_lst` VALUES
(1,1,1,'Member'),
(1,2,2,'Regular Attender'),
(1,3,3,'Guest'),
(1,5,4,'Non-Attender'),
(1,4,5,'Non-Attender (staff)'),
(2,1,1,'Head of Household'),
(2,2,2,'Spouse'),
(2,3,3,'Child'),
(2,4,4,'Other Relative'),
(2,5,5,'Non Relative'),
(3,1,1,'Ministry'),
(3,2,2,'Team'),
(3,3,3,'Bible Study'),
(3,4,4,'Sunday School Class'),
(4,1,1,'True / False'),
(4,2,2,'Date'),
(4,3,3,'Text Field (50 char)'),
(4,4,4,'Text Field (100 char)'),
(4,5,5,'Text Field (Long)'),
(4,6,6,'Year'),
(4,7,7,'Season'),
(4,8,8,'Number'),
(4,9,9,'Person from Group'),
(4,10,10,'Money'),
(4,11,11,'Phone Number'),
(4,12,12,'Custom Drop-Down List'),
(5,1,1,'bAll'),
(5,2,2,'bAdmin'),
(5,3,3,'bAddRecords'),
(5,4,4,'bEditRecords'),
(5,5,5,'bDeleteRecords'),
(5,7,7,'bManageGroups'),
(5,8,8,'bFinance'),
(5,9,9,'bNotes'),
(10,1,1,'Teacher'),
(10,2,2,'Student'),
(11,1,1,'Member'),
(12,1,1,'Teacher'),
(12,2,2,'Student'),
(13,1,1,'Teacher'),
(13,2,2,'Student'),
(14,1,1,'Teacher'),
(14,2,2,'Student'),
(15,1,1,'Teacher'),
(15,2,2,'Student'),
(16,1,1,'Teacher'),
(16,2,2,'Student'),
(17,1,1,'Teacher'),
(17,2,2,'Student'),
(18,1,1,'Teacher'),
(18,2,2,'Student'),
(19,1,1,'Member'),
(20,1,1,'Member'),
(21,1,1,'Member'),
(3,5,5,'Scouts'),
(22,1,1,'Member'),
(23,1,1,'Member'),
(24,1,1,'Default Option'),
(24,2,2,'My Custom Item 1'),
(24,3,3,'My Custom Item 2'),
(25,1,1,'Default Option'),
(26,1,1,'Member'),
(27,1,1,'Member'),
(28,1,1,'Member'),
(29,1,1,'Member'),
(30,1,1,'Member'),
(31,1,1,'Member'),
(32,1,1,'Member'),
(33,1,1,'Member'),
(34,1,1,'Member'),
(35,1,1,'Member'),
(36,1,1,'Member'),
(37,1,2,'Member'),
(37,2,1,'sdfsdf');
/*!40000 ALTER TABLE `list_lst` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `location_typeId` int(11) NOT NULL,
  `location_name` varchar(256) NOT NULL,
  `location_address` varchar(45) NOT NULL,
  `location_city` varchar(45) NOT NULL,
  `location_state` varchar(45) NOT NULL,
  `location_zip` varchar(45) NOT NULL,
  `location_country` varchar(45) NOT NULL,
  `location_phone` varchar(45) DEFAULT NULL,
  `location_email` varchar(45) DEFAULT NULL,
  `location_timzezone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_attendance_mat`
--

DROP TABLE IF EXISTS `meeting_attendance_mat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_attendance_mat` (
  `mat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `mat_MeetingId` int(11) NOT NULL,
  `mat_PersonId` int(11) NOT NULL,
  `mat_IsPresent` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`mat_ID`),
  UNIQUE KEY `meeting_person` (`mat_MeetingId`,`mat_PersonId`),
  KEY `mat_MeetingId` (`mat_MeetingId`),
  KEY `mat_PersonId` (`mat_PersonId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_attendance_mat`
--

LOCK TABLES `meeting_attendance_mat` WRITE;
/*!40000 ALTER TABLE `meeting_attendance_mat` DISABLE KEYS */;
INSERT INTO `meeting_attendance_mat` VALUES
(1,1,1493,1),
(2,1,1,1);
/*!40000 ALTER TABLE `meeting_attendance_mat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_mtg`
--

DROP TABLE IF EXISTS `meeting_mtg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_mtg` (
  `mtg_ID` int(11) NOT NULL AUTO_INCREMENT,
  `mtg_Name` varchar(255) NOT NULL,
  `mtg_DateTime` datetime NOT NULL,
  `mtg_OrganizerType` varchar(20) NOT NULL DEFAULT 'church',
  `mtg_OrganizerId` int(11) NOT NULL DEFAULT 0,
  `mtg_Remarks` text DEFAULT NULL,
  `mtg_DateEntered` datetime DEFAULT NULL,
  `mtg_DateLastEdited` datetime DEFAULT NULL,
  `mtg_EnteredBy` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mtg_EditedBy` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`mtg_ID`),
  KEY `idx_meeting_datetime` (`mtg_DateTime`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_mtg`
--

LOCK TABLES `meeting_mtg` WRITE;
/*!40000 ALTER TABLE `meeting_mtg` DISABLE KEYS */;
INSERT INTO `meeting_mtg` VALUES
(1,'Réunion de prière mensuelle','2026-05-25 18:00:00','church',0,'Réunion de prière pour tous les membres','2026-05-19 22:04:01',NULL,1,0);
/*!40000 ALTER TABLE `meeting_mtg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_links`
--

DROP TABLE IF EXISTS `menu_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_links` (
  `linkId` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `linkName` varchar(50) DEFAULT NULL,
  `linkUri` text NOT NULL,
  `linkOrder` int(11) NOT NULL,
  PRIMARY KEY (`linkId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_links`
--

LOCK TABLES `menu_links` WRITE;
/*!40000 ALTER TABLE `menu_links` DISABLE KEYS */;
INSERT INTO `menu_links` VALUES
(1,'CNN','https://www.cnn.com',0),
(2,'Google','https://www.google.com',0);
/*!40000 ALTER TABLE `menu_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `multibuy_mb`
--

DROP TABLE IF EXISTS `multibuy_mb`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `multibuy_mb` (
  `mb_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `mb_per_ID` mediumint(9) NOT NULL DEFAULT 0,
  `mb_item_ID` mediumint(9) NOT NULL DEFAULT 0,
  `mb_count` decimal(8,0) DEFAULT NULL,
  PRIMARY KEY (`mb_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `multibuy_mb`
--

LOCK TABLES `multibuy_mb` WRITE;
/*!40000 ALTER TABLE `multibuy_mb` DISABLE KEYS */;
/*!40000 ALTER TABLE `multibuy_mb` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_nte`
--

DROP TABLE IF EXISTS `note_nte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_nte` (
  `nte_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `nte_per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `nte_fam_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `nte_Private` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `nte_Text` text DEFAULT NULL,
  `nte_DateEntered` datetime NOT NULL,
  `nte_DateLastEdited` datetime DEFAULT NULL,
  `nte_EnteredBy` mediumint(8) NOT NULL DEFAULT 0,
  `nte_EditedBy` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `nte_Type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`nte_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1925 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_nte`
--

LOCK TABLES `note_nte` WRITE;
/*!40000 ALTER TABLE `note_nte` DISABLE KEYS */;
INSERT INTO `note_nte` VALUES
(1,0,1,0,'Created','2016-01-01 00:00:00','2009-12-25 07:19:06',1,0,'create'),
(2,2,0,0,'Created','2016-01-01 00:00:00','2009-12-25 07:19:06',1,0,'create'),
(3,3,0,0,'Created','2016-01-01 00:00:00','2006-05-18 08:07:27',1,0,'create'),
(4,4,0,0,'Created','2016-01-01 00:00:00','2016-04-03 09:13:02',1,0,'create'),
(5,5,0,0,'Created','2016-01-01 00:00:00','2003-06-23 04:32:34',1,0,'create'),
(6,0,2,0,'Created','2016-01-01 00:00:00','2009-04-13 01:17:12',1,0,'create'),
(7,6,0,0,'Created','2016-01-01 00:00:00','2009-04-13 01:17:12',1,0,'create'),
(8,7,0,0,'Created','2016-01-01 00:00:00','2006-08-18 00:45:56',1,0,'create'),
(9,8,0,0,'Created','2016-01-01 00:00:00','2004-11-25 05:24:25',1,0,'create'),
(10,9,0,0,'Created','2016-01-01 00:00:00','2009-08-19 12:28:31',1,0,'create'),
(11,10,0,0,'Created','2016-01-01 00:00:00','2003-02-22 08:03:31',1,0,'create'),
(12,11,0,0,'Created','2016-01-01 00:00:00','2011-12-29 16:42:21',1,0,'create'),
(13,12,0,0,'Created','2016-01-01 00:00:00','2014-10-07 16:03:06',1,0,'create'),
(14,13,0,0,'Created','2016-01-01 00:00:00','2013-02-28 09:48:03',1,0,'create'),
(15,0,3,0,'Created','2016-01-01 00:00:00','2007-11-19 10:08:41',1,0,'create'),
(16,14,0,0,'Created','2016-01-01 00:00:00','2007-11-19 10:08:41',1,0,'create'),
(17,15,0,0,'Created','2016-01-01 00:00:00','2009-12-31 07:48:03',1,0,'create'),
(18,16,0,0,'Created','2016-01-01 00:00:00','2011-05-22 19:11:16',1,0,'create'),
(19,17,0,0,'Created','2016-01-01 00:00:00','2003-09-03 15:13:09',1,0,'create'),
(20,0,4,0,'Created','2016-01-01 00:00:00','2003-10-14 16:05:17',1,0,'create'),
(21,18,0,0,'Created','2016-01-01 00:00:00','2003-10-14 16:05:17',1,0,'create'),
(22,19,0,0,'Created','2016-01-01 00:00:00','2008-05-09 05:12:00',1,0,'create'),
(23,20,0,0,'Created','2016-01-01 00:00:00','2011-02-18 08:54:47',1,0,'create'),
(24,21,0,0,'Created','2016-01-01 00:00:00','2009-08-31 21:41:59',1,0,'create'),
(25,22,0,0,'Created','2016-01-01 00:00:00','2007-06-22 01:54:41',1,0,'create'),
(26,23,0,0,'Created','2016-01-01 00:00:00','2009-08-13 03:54:14',1,0,'create'),
(27,24,0,0,'Created','2016-01-01 00:00:00','2016-03-23 12:51:45',1,0,'create'),
(28,25,0,0,'Created','2016-01-01 00:00:00','2007-08-08 06:34:24',1,0,'create'),
(29,0,5,0,'Created','2016-01-01 00:00:00','2007-09-14 23:32:06',1,0,'create'),
(30,26,0,0,'Created','2016-01-01 00:00:00','2007-09-14 23:32:06',1,0,'create'),
(31,27,0,0,'Created','2016-01-01 00:00:00','2004-09-21 04:59:36',1,0,'create'),
(32,0,6,0,'Created','2016-01-01 00:00:00','2013-07-25 20:18:03',1,0,'create'),
(33,28,0,0,'Created','2016-01-01 00:00:00','2013-07-25 20:18:03',1,0,'create'),
(34,29,0,0,'Created','2016-01-01 00:00:00','2004-03-04 00:12:40',1,0,'create'),
(35,30,0,0,'Created','2016-01-01 00:00:00','2014-09-29 01:36:32',1,0,'create'),
(36,31,0,0,'Created','2016-01-01 00:00:00','2007-04-14 04:13:25',1,0,'create'),
(37,32,0,0,'Created','2016-01-01 00:00:00','2010-07-15 12:40:49',1,0,'create'),
(38,33,0,0,'Created','2016-01-01 00:00:00','2006-07-25 23:21:13',1,0,'create'),
(39,0,7,0,'Created','2016-01-01 00:00:00','2011-08-17 04:00:29',1,0,'create'),
(40,34,0,0,'Created','2016-01-01 00:00:00','2011-08-17 04:00:29',1,0,'create'),
(41,35,0,0,'Created','2016-01-01 00:00:00','2007-12-26 21:13:22',1,0,'create'),
(43,36,0,0,'Created','2016-01-01 00:00:00','2015-02-07 16:23:42',1,0,'create'),
(44,37,0,0,'Created','2016-01-01 00:00:00','2005-03-04 15:19:32',1,0,'create'),
(45,38,0,0,'Created','2016-01-01 00:00:00','2008-10-02 23:33:21',1,0,'create'),
(46,39,0,0,'Created','2016-01-01 00:00:00','2003-04-01 17:32:42',1,0,'create'),
(47,40,0,0,'Created','2016-01-01 00:00:00','2015-05-27 00:37:53',1,0,'create'),
(48,41,0,0,'Created','2016-01-01 00:00:00','2003-12-11 09:28:32',1,0,'create'),
(49,42,0,0,'Created','2016-01-01 00:00:00','2012-03-22 08:26:55',1,0,'create'),
(50,0,9,0,'Created','2016-01-01 00:00:00','2013-04-20 15:01:05',1,0,'create'),
(51,43,0,0,'Created','2016-01-01 00:00:00','2013-04-20 15:01:05',1,0,'create'),
(52,44,0,0,'Created','2016-01-01 00:00:00','2012-02-09 10:41:53',1,0,'create'),
(56,48,0,0,'Created','2016-01-01 00:00:00','2010-01-07 01:55:34',1,0,'create'),
(57,49,0,0,'Created','2016-01-01 00:00:00','2004-06-21 14:40:43',1,0,'create'),
(58,0,10,0,'Created','2016-01-01 00:00:00','2004-09-09 18:40:30',1,0,'create'),
(59,50,0,0,'Created','2016-01-01 00:00:00','2004-09-09 18:40:30',1,0,'create'),
(60,51,0,0,'Created','2016-01-01 00:00:00','2006-11-20 15:07:23',1,0,'create'),
(61,0,11,0,'Created','2016-01-01 00:00:00','2006-10-11 03:51:16',1,0,'create'),
(62,52,0,0,'Created','2016-01-01 00:00:00','2006-10-11 03:51:16',1,0,'create'),
(63,53,0,0,'Created','2016-01-01 00:00:00','2006-06-21 08:18:13',1,0,'create'),
(64,54,0,0,'Created','2016-01-01 00:00:00','2006-05-24 17:02:09',1,0,'create'),
(65,55,0,0,'Created','2016-01-01 00:00:00','2015-10-04 01:39:08',1,0,'create'),
(66,56,0,0,'Created','2016-01-01 00:00:00','2006-07-23 14:13:59',1,0,'create'),
(67,0,12,0,'Created','2016-01-01 00:00:00','2014-08-31 04:21:43',1,0,'create'),
(68,57,0,0,'Created','2016-01-01 00:00:00','2014-08-31 04:21:43',1,0,'create'),
(69,58,0,0,'Created','2016-01-01 00:00:00','2007-11-22 02:36:13',1,0,'create'),
(70,0,13,0,'Created','2016-01-01 00:00:00','2007-02-01 16:50:26',1,0,'create'),
(71,59,0,0,'Created','2016-01-01 00:00:00','2007-02-01 16:50:26',1,0,'create'),
(72,60,0,0,'Created','2016-01-01 00:00:00','2006-11-07 12:19:08',1,0,'create'),
(73,61,0,0,'Created','2016-01-01 00:00:00','2009-03-23 09:24:30',1,0,'create'),
(74,62,0,0,'Created','2016-01-01 00:00:00','2013-07-10 17:58:37',1,0,'create'),
(75,63,0,0,'Created','2016-01-01 00:00:00','2004-10-13 20:53:29',1,0,'create'),
(79,0,14,0,'Created','2016-01-01 00:00:00','2013-10-15 09:25:25',1,0,'create'),
(80,67,0,0,'Created','2016-01-01 00:00:00','2013-10-15 09:25:25',1,0,'create'),
(81,68,0,0,'Created','2016-01-01 00:00:00','2003-09-29 17:56:26',1,0,'create'),
(82,69,0,0,'Created','2016-01-01 00:00:00','2010-10-03 22:37:50',1,0,'create'),
(84,70,0,0,'Created','2016-01-01 00:00:00','2003-04-25 18:30:46',1,0,'create'),
(85,71,0,0,'Created','2016-01-01 00:00:00','2013-07-20 08:52:02',1,0,'create'),
(86,72,0,0,'Created','2016-01-01 00:00:00','2002-10-01 07:06:30',1,0,'create'),
(87,73,0,0,'Created','2016-01-01 00:00:00','2006-10-24 06:38:46',1,0,'create'),
(88,74,0,0,'Created','2016-01-01 00:00:00','2005-01-21 16:03:19',1,0,'create'),
(89,75,0,0,'Created','2016-01-01 00:00:00','2008-02-08 09:12:55',1,0,'create'),
(90,0,16,0,'Created','2016-01-01 00:00:00','2016-03-01 14:19:32',1,0,'create'),
(91,76,0,0,'Created','2016-01-01 00:00:00','2016-03-01 14:19:32',1,0,'create'),
(92,77,0,0,'Created','2016-01-01 00:00:00','2013-07-06 04:09:48',1,0,'create'),
(93,0,17,0,'Created','2016-01-01 00:00:00','2014-09-26 00:09:54',1,0,'create'),
(94,78,0,0,'Created','2016-01-01 00:00:00','2014-09-26 00:09:54',1,0,'create'),
(95,79,0,0,'Created','2016-01-01 00:00:00','2007-06-20 13:29:12',1,0,'create'),
(96,80,0,0,'Created','2016-01-01 00:00:00','2015-12-26 15:02:22',1,0,'create'),
(97,81,0,0,'Created','2016-01-01 00:00:00','2008-02-28 11:35:15',1,0,'create'),
(98,82,0,0,'Created','2016-01-01 00:00:00','2007-04-24 18:10:43',1,0,'create'),
(99,83,0,0,'Created','2016-01-01 00:00:00','2011-10-07 17:53:37',1,0,'create'),
(100,0,18,0,'Created','2016-01-01 00:00:00','2002-04-09 05:31:36',1,0,'create'),
(101,84,0,0,'Created','2016-01-01 00:00:00','2002-04-09 05:31:36',1,0,'create'),
(102,85,0,0,'Created','2016-01-01 00:00:00','2015-03-05 07:54:37',1,0,'create'),
(103,86,0,0,'Created','2016-01-01 00:00:00','2003-02-10 12:19:20',1,0,'create'),
(104,87,0,0,'Created','2016-01-01 00:00:00','2008-11-13 08:27:32',1,0,'create'),
(105,88,0,0,'Created','2016-01-01 00:00:00','2008-06-30 07:18:09',1,0,'create'),
(106,89,0,0,'Created','2016-01-01 00:00:00','2005-04-12 20:56:36',1,0,'create'),
(107,90,0,0,'Created','2016-01-01 00:00:00','2007-01-20 19:02:31',1,0,'create'),
(108,91,0,0,'Created','2016-01-01 00:00:00','2010-12-30 01:21:15',1,0,'create'),
(109,0,19,0,'Created','2016-01-01 00:00:00','2014-11-23 09:17:25',1,0,'create'),
(110,92,0,0,'Created','2016-01-01 00:00:00','2014-11-23 09:17:25',1,0,'create'),
(111,93,0,0,'Created','2016-01-01 00:00:00','2011-07-16 02:59:16',1,0,'create'),
(112,94,0,0,'Created','2016-01-01 00:00:00','2006-05-25 19:29:47',1,0,'create'),
(113,95,0,0,'Created','2016-01-01 00:00:00','2003-07-08 08:25:48',1,0,'create'),
(114,96,0,0,'Created','2016-01-01 00:00:00','2006-04-08 10:42:12',1,0,'create'),
(115,97,0,0,'Created','2016-01-01 00:00:00','2010-01-28 17:10:25',1,0,'create'),
(116,98,0,0,'Created','2016-01-01 00:00:00','2007-02-16 17:31:50',1,0,'create'),
(117,0,20,0,'Created','2016-01-01 00:00:00','2014-05-10 06:07:19',1,0,'create'),
(118,99,0,0,'Created','2016-01-01 00:00:00','2014-05-10 06:07:19',1,0,'create'),
(119,100,0,0,'Created','2016-01-01 00:00:00','2004-09-29 01:37:47',1,0,'create'),
(121,102,0,0,'Created','2016-01-01 00:00:00','2005-03-07 21:32:47',1,0,'create'),
(122,103,0,0,'Created','2016-01-01 00:00:00','2014-05-16 11:35:23',1,0,'create'),
(123,26,0,0,'Updated via Family','2016-11-19 15:23:31',NULL,1,0,'edit'),
(124,27,0,0,'Updated via Family','2016-11-19 15:23:31',NULL,1,0,'edit'),
(125,0,5,0,'Updated','2016-11-19 15:23:31',NULL,1,0,'edit'),
(126,61,0,0,'Updated','2016-11-19 15:25:34',NULL,1,0,'edit'),
(127,62,0,0,'Updated','2016-11-19 15:25:41',NULL,1,0,'edit'),
(128,63,0,0,'Updated','2016-11-19 15:26:00',NULL,1,0,'edit'),
(129,63,0,0,'Updated','2016-11-19 15:27:02',NULL,1,0,'edit'),
(130,60,0,0,'Updated','2016-11-19 15:27:13',NULL,1,0,'edit'),
(131,69,0,0,'Updated','2016-11-19 15:38:00',NULL,1,0,'edit'),
(132,69,0,0,'Profile Image Deleted','2016-11-19 15:38:03',NULL,1,0,'photo'),
(133,68,0,0,'Updated','2016-11-19 15:38:31',NULL,1,0,'edit'),
(134,67,0,0,'Updated','2016-11-19 15:38:39',NULL,1,0,'edit'),
(135,4,0,0,'Updated','2016-11-19 15:39:19',NULL,1,0,'edit'),
(136,5,0,0,'Updated','2016-11-19 15:39:30',NULL,1,0,'edit'),
(137,80,0,0,'Updated','2016-11-19 15:39:51',NULL,1,0,'edit'),
(138,81,0,0,'Updated','2016-11-19 15:39:54',NULL,1,0,'edit'),
(139,82,0,0,'Updated','2016-11-19 15:39:58',NULL,1,0,'edit'),
(140,83,0,0,'Updated','2016-11-19 15:40:22',NULL,1,0,'edit'),
(141,31,0,0,'Updated','2016-11-19 15:40:40',NULL,1,0,'edit'),
(142,33,0,0,'Updated','2016-11-19 15:40:43',NULL,1,0,'edit'),
(143,29,0,0,'Updated','2016-11-19 15:40:58',NULL,1,0,'edit'),
(144,32,0,0,'Updated','2016-11-19 15:41:02',NULL,1,0,'edit'),
(145,30,0,0,'Updated','2016-11-19 15:41:11',NULL,1,0,'edit'),
(146,51,0,0,'Updated','2016-11-19 15:41:44',NULL,1,0,'edit'),
(147,13,0,0,'Updated','2016-11-19 15:42:01',NULL,1,0,'edit'),
(148,12,0,0,'Updated','2016-11-19 15:42:04',NULL,1,0,'edit'),
(149,11,0,0,'Updated','2016-11-19 15:42:07',NULL,1,0,'edit'),
(150,10,0,0,'Updated','2016-11-19 15:42:10',NULL,1,0,'edit'),
(151,9,0,0,'Updated','2016-11-19 15:42:14',NULL,1,0,'edit'),
(152,8,0,0,'Updated','2016-11-19 15:42:20',NULL,1,0,'edit'),
(153,94,0,0,'Updated','2016-11-19 15:42:48',NULL,1,0,'edit'),
(154,95,0,0,'Updated','2016-11-19 15:42:57',NULL,1,0,'edit'),
(155,96,0,0,'Updated','2016-11-19 15:43:06',NULL,1,0,'edit'),
(156,97,0,0,'Updated','2016-11-19 15:43:10',NULL,1,0,'edit'),
(157,53,0,0,'Updated','2016-11-19 15:43:22',NULL,1,0,'edit'),
(158,27,0,0,'Updated','2016-11-19 15:43:47',NULL,1,0,'edit'),
(159,35,0,0,'Updated','2016-11-19 15:44:07',NULL,1,0,'edit'),
(160,35,0,0,'Profile Image Deleted','2016-11-19 15:44:11',NULL,1,0,'photo'),
(161,59,0,0,'Updated via Family','2016-11-19 15:46:56',NULL,1,0,'edit'),
(162,63,0,0,'Updated via Family','2016-11-19 15:46:56',NULL,1,0,'edit'),
(163,60,0,0,'Updated via Family','2016-11-19 15:46:56',NULL,1,0,'edit'),
(164,61,0,0,'Updated via Family','2016-11-19 15:46:56',NULL,1,0,'edit'),
(165,62,0,0,'Updated via Family','2016-11-19 15:46:56',NULL,1,0,'edit'),
(166,0,13,0,'Updated','2016-11-19 15:46:56',NULL,1,0,'edit'),
(167,59,0,0,'Updated via Family','2016-11-19 15:49:36',NULL,1,0,'edit'),
(168,63,0,0,'Updated via Family','2016-11-19 15:49:36',NULL,1,0,'edit'),
(169,60,0,0,'Updated via Family','2016-11-19 15:49:36',NULL,1,0,'edit'),
(170,61,0,0,'Updated via Family','2016-11-19 15:49:36',NULL,1,0,'edit'),
(171,62,0,0,'Updated via Family','2016-11-19 15:49:36',NULL,1,0,'edit'),
(172,0,13,0,'Updated','2016-11-19 15:49:36',NULL,1,0,'edit'),
(173,68,0,0,'Updated via Family','2016-11-19 15:49:58',NULL,1,0,'edit'),
(174,67,0,0,'Updated via Family','2016-11-19 15:49:58',NULL,1,0,'edit'),
(175,69,0,0,'Updated via Family','2016-11-19 15:49:58',NULL,1,0,'edit'),
(176,0,14,0,'Updated','2016-11-19 15:49:58',NULL,1,0,'edit'),
(177,99,0,0,'Updated via Family','2016-11-19 15:50:25',NULL,1,0,'edit'),
(178,100,0,0,'Updated via Family','2016-11-19 15:50:25',NULL,1,0,'edit'),
(179,102,0,0,'Updated via Family','2016-11-19 15:50:25',NULL,1,0,'edit'),
(180,103,0,0,'Updated via Family','2016-11-19 15:50:25',NULL,1,0,'edit'),
(181,0,20,0,'Updated','2016-11-19 15:50:25',NULL,1,0,'edit'),
(182,2,0,0,'Updated via Family','2016-11-19 15:50:57',NULL,1,0,'edit'),
(183,3,0,0,'Updated via Family','2016-11-19 15:50:57',NULL,1,0,'edit'),
(184,4,0,0,'Updated via Family','2016-11-19 15:50:57',NULL,1,0,'edit'),
(185,5,0,0,'Updated via Family','2016-11-19 15:50:57',NULL,1,0,'edit'),
(186,0,1,0,'Updated','2016-11-19 15:50:57',NULL,1,0,'edit'),
(187,78,0,0,'Updated via Family','2016-11-19 15:51:35',NULL,1,0,'edit'),
(188,79,0,0,'Updated via Family','2016-11-19 15:51:35',NULL,1,0,'edit'),
(189,80,0,0,'Updated via Family','2016-11-19 15:51:35',NULL,1,0,'edit'),
(190,81,0,0,'Updated via Family','2016-11-19 15:51:35',NULL,1,0,'edit'),
(191,82,0,0,'Updated via Family','2016-11-19 15:51:35',NULL,1,0,'edit'),
(192,0,17,0,'Updated','2016-11-19 15:51:35',NULL,1,0,'edit'),
(193,43,0,0,'Updated via Family','2016-11-19 15:52:17',NULL,1,0,'edit'),
(194,44,0,0,'Updated via Family','2016-11-19 15:52:17',NULL,1,0,'edit'),
(195,48,0,0,'Updated via Family','2016-11-19 15:52:17',NULL,1,0,'edit'),
(196,49,0,0,'Updated via Family','2016-11-19 15:52:17',NULL,1,0,'edit'),
(197,0,9,0,'Updated','2016-11-19 15:52:17',NULL,1,0,'edit'),
(198,28,0,0,'Updated via Family','2016-11-19 15:52:44',NULL,1,0,'edit'),
(199,30,0,0,'Updated via Family','2016-11-19 15:52:44',NULL,1,0,'edit'),
(200,0,6,0,'Updated','2016-11-19 15:52:44',NULL,1,0,'edit'),
(201,50,0,0,'Updated via Family','2016-11-19 15:52:50',NULL,1,0,'edit'),
(202,0,10,0,'Updated','2016-11-19 15:52:50',NULL,1,0,'edit'),
(203,6,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(204,7,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(205,8,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(206,9,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(207,10,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(208,11,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(209,12,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(210,13,0,0,'Updated via Family','2016-11-19 15:53:10',NULL,1,0,'edit'),
(211,0,2,0,'Updated','2016-11-19 15:53:10',NULL,1,0,'edit'),
(212,92,0,0,'Updated via Family','2016-11-19 15:53:40',NULL,1,0,'edit'),
(213,93,0,0,'Updated via Family','2016-11-19 15:53:40',NULL,1,0,'edit'),
(214,98,0,0,'Updated via Family','2016-11-19 15:53:40',NULL,1,0,'edit'),
(215,0,19,0,'Updated','2016-11-19 15:53:40',NULL,1,0,'edit'),
(216,76,0,0,'Updated via Family','2016-11-19 15:53:48',NULL,1,0,'edit'),
(217,77,0,0,'Updated via Family','2016-11-19 15:53:48',NULL,1,0,'edit'),
(218,0,16,0,'Updated','2016-11-19 15:53:48',NULL,1,0,'edit'),
(219,14,0,0,'Updated via Family','2016-11-19 15:54:09',NULL,1,0,'edit'),
(220,15,0,0,'Updated via Family','2016-11-19 15:54:09',NULL,1,0,'edit'),
(221,16,0,0,'Updated via Family','2016-11-19 15:54:09',NULL,1,0,'edit'),
(222,17,0,0,'Updated via Family','2016-11-19 15:54:09',NULL,1,0,'edit'),
(223,0,3,0,'Updated','2016-11-19 15:54:09',NULL,1,0,'edit'),
(224,52,0,0,'Updated via Family','2016-11-19 15:54:22',NULL,1,0,'edit'),
(225,54,0,0,'Updated via Family','2016-11-19 15:54:22',NULL,1,0,'edit'),
(226,55,0,0,'Updated via Family','2016-11-19 15:54:22',NULL,1,0,'edit'),
(227,56,0,0,'Updated via Family','2016-11-19 15:54:22',NULL,1,0,'edit'),
(228,0,11,0,'Updated','2016-11-19 15:54:22',NULL,1,0,'edit'),
(229,57,0,0,'Updated via Family','2016-11-19 15:54:30',NULL,1,0,'edit'),
(230,58,0,0,'Updated via Family','2016-11-19 15:54:30',NULL,1,0,'edit'),
(231,0,12,0,'Updated','2016-11-19 15:54:30',NULL,1,0,'edit'),
(232,18,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(233,19,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(234,20,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(235,21,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(236,22,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(237,23,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(238,24,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(239,25,0,0,'Updated via Family','2016-11-19 15:55:11',NULL,1,0,'edit'),
(240,0,4,0,'Updated','2016-11-19 15:55:11',NULL,1,0,'edit'),
(241,84,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(242,85,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(243,86,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(244,87,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(245,88,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(246,89,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(247,90,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(248,91,0,0,'Updated via Family','2016-11-19 15:56:04',NULL,1,0,'edit'),
(249,0,18,0,'Updated','2016-11-19 15:56:04',NULL,1,0,'edit'),
(250,26,0,0,'Updated via Family','2016-11-19 15:56:49',NULL,1,0,'edit'),
(251,0,5,0,'Updated','2016-11-19 15:56:49',NULL,1,0,'edit'),
(252,34,0,0,'Updated via Family','2016-11-19 15:56:55',NULL,1,0,'edit'),
(253,0,7,0,'Updated','2016-11-19 15:56:55',NULL,1,0,'edit'),
(254,3,0,0,'Updated','2016-11-19 16:07:39',NULL,1,0,'edit'),
(255,84,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(256,85,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(257,87,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(258,88,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(259,89,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(260,90,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(261,91,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(262,86,0,0,'Updated via Family','2016-11-19 16:42:37',NULL,1,0,'edit'),
(263,0,18,0,'Updated','2016-11-19 16:42:37',NULL,1,0,'edit'),
(264,84,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(265,85,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(266,87,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(267,88,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(268,89,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(269,90,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(270,91,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(271,86,0,0,'Updated via Family','2016-11-19 16:43:48',NULL,1,0,'edit'),
(272,0,18,0,'Updated','2016-11-19 16:43:48',NULL,1,0,'edit'),
(273,0,21,0,'Created','0000-00-00 00:00:00','2017-04-15 17:19:26',-1,0,'create'),
(274,104,0,0,'Created','2017-04-15 17:20:21',NULL,-1,0,'create'),
(275,105,0,0,'Created','2017-04-15 17:20:21',NULL,-1,0,'create'),
(276,106,0,0,'Created','2017-04-15 17:20:21',NULL,-1,0,'create'),
(277,107,0,0,'Created','2017-04-15 17:20:21',NULL,-1,0,'create'),
(278,14,0,0,'Updated via Family','2017-04-15 17:21:40',NULL,1,0,'edit'),
(279,15,0,0,'Updated via Family','2017-04-15 17:21:40',NULL,1,0,'edit'),
(280,16,0,0,'Updated via Family','2017-04-15 17:21:40',NULL,1,0,'edit'),
(281,17,0,0,'Updated via Family','2017-04-15 17:21:40',NULL,1,0,'edit'),
(282,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(283,26,0,0,'Updated via Family','2017-04-15 17:22:04',NULL,1,0,'edit'),
(284,0,5,0,'Updated','2017-04-15 17:22:04',NULL,1,0,'edit'),
(285,50,0,0,'Updated via Family','2017-04-15 17:22:19',NULL,1,0,'edit'),
(286,0,10,0,'Updated','2017-04-15 17:22:19',NULL,1,0,'edit'),
(287,0,4,0,'Updated','0000-00-00 00:00:00','2016-11-19 15:55:11',1,0,'edit'),
(288,0,4,0,'Deactivated the Family','2017-04-15 17:34:50',NULL,1,0,'edit'),
(289,3,0,0,'system user password reset','2017-12-18 00:43:09',NULL,1,0,'user'),
(290,3,0,0,'system user password changed by admin','2017-12-18 00:43:33',NULL,1,0,'user'),
(291,3,0,0,'system user password reset','2017-12-18 00:45:44',NULL,1,0,'user'),
(292,3,0,0,'system user password reset','2017-12-18 00:47:43',NULL,1,0,'user'),
(293,96,0,0,'Deleted from group: ','2017-12-23 14:46:01',NULL,1,0,'group'),
(294,96,0,0,'Deleted from group: Class 4-5','2017-12-23 14:46:59',NULL,1,0,'group'),
(295,96,0,0,'Added to group: High School Class','2017-12-23 14:48:34',NULL,1,0,'group'),
(296,3,0,0,'system user password changed by admin','2017-12-23 16:49:29',NULL,1,0,'user'),
(297,35,0,0,'Updated','2018-01-01 19:25:55',NULL,1,0,'edit'),
(298,1,0,0,NULL,'2018-02-19 17:11:42',NULL,1,0,'user'),
(299,26,0,0,'Added to group: Clergy','2019-09-08 21:23:06',NULL,1,0,'group'),
(300,2,0,0,'Added to group: Clergy','2019-09-08 21:23:18',NULL,1,0,'group'),
(301,78,0,0,'Updated','2019-09-08 21:43:50',NULL,3,0,'edit'),
(302,80,0,0,'Updated','2019-09-08 21:44:06',NULL,3,0,'edit'),
(303,50,0,0,'Updated via Family','2019-09-11 23:04:11',NULL,1,0,'edit'),
(304,0,10,0,'Updated','2019-09-11 23:04:11',NULL,1,0,'edit'),
(305,50,0,0,'Updated','2019-09-11 23:09:35',NULL,1,0,'edit'),
(306,95,0,0,'system user login reset','2020-11-27 11:40:54',NULL,1,0,'user'),
(307,95,0,0,'system user password reset','2020-11-27 11:40:56',NULL,1,0,'user'),
(308,0,2,0,'Verification email sent','2020-11-27 11:43:34',NULL,1,0,'verify-link'),
(309,3,0,0,NULL,'2020-11-27 11:45:28',NULL,1,0,'user'),
(310,105,0,0,'Updated','2021-03-21 17:45:34',NULL,1,0,'edit'),
(311,105,0,0,'Updated','2021-03-21 17:46:45',NULL,1,0,'edit'),
(312,104,0,0,'Updated','2021-04-25 09:41:33',NULL,1,0,'edit'),
(313,104,0,0,'Updated via Family','2021-04-25 09:45:44',NULL,1,0,'edit'),
(314,105,0,0,'Updated via Family','2021-04-25 09:45:44',NULL,1,0,'edit'),
(315,106,0,0,'Updated via Family','2021-04-25 09:45:44',NULL,1,0,'edit'),
(316,107,0,0,'Updated via Family','2021-04-25 09:45:44',NULL,1,0,'edit'),
(317,0,21,0,'Updated','2021-04-25 09:45:44',NULL,1,0,'edit'),
(318,95,0,0,'system user login reset','2021-04-25 10:04:41',NULL,1,0,'user'),
(319,95,0,0,'system user password reset','2021-04-25 10:04:43',NULL,1,0,'user'),
(320,0,2,0,'Verification email sent','2021-04-25 10:04:53',NULL,3,0,'verify-link'),
(321,76,0,0,'system user password changed by admin','2021-04-25 10:10:53',NULL,1,0,'user'),
(322,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(323,0,3,0,'Deactivated the Family','2021-04-25 10:21:17',NULL,3,0,'edit'),
(324,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(325,0,3,0,'Activated the Family','2021-04-25 10:21:56',NULL,3,0,'edit'),
(326,108,0,0,'Created via Family','2021-04-25 10:24:12',NULL,3,0,'create'),
(327,109,0,0,'Created via Family','2021-04-25 10:24:12',NULL,3,0,'create'),
(328,110,0,0,'Created via Family','2021-04-25 10:24:12',NULL,3,0,'create'),
(329,111,0,0,'Created via Family','2021-04-25 10:24:12',NULL,3,0,'create'),
(330,112,0,0,'Created via Family','2021-04-25 10:24:12',NULL,3,0,'create'),
(331,113,0,0,'Created via Family','2021-04-25 10:24:12',NULL,3,0,'create'),
(332,0,22,0,'Created','2021-04-25 10:24:12',NULL,3,0,'create'),
(333,114,0,0,'Created','2021-04-25 10:32:31',NULL,3,0,'create'),
(334,3,0,0,'system user changed password','2021-04-25 10:36:28',NULL,3,0,'user'),
(335,3,0,0,'system user changed password','2021-04-25 10:37:04',NULL,3,0,'user'),
(336,95,0,0,'system user login reset','2021-04-25 10:39:46',NULL,1,0,'user'),
(337,95,0,0,'system user password reset','2021-04-25 10:39:49',NULL,1,0,'user'),
(338,0,2,0,'Verification email sent','2021-04-25 10:39:55',NULL,3,0,'verify-link'),
(339,95,0,0,'system user login reset','2021-04-25 10:41:32',NULL,1,0,'user'),
(340,95,0,0,'system user password reset','2021-04-25 10:41:35',NULL,1,0,'user'),
(341,0,2,0,'Verification email sent','2021-04-25 10:41:41',NULL,3,0,'verify-link'),
(342,76,0,0,'system user password changed by admin','2021-04-25 10:47:42',NULL,1,0,'user'),
(343,0,23,0,'Created','2021-04-25 10:50:11',NULL,-1,0,'create'),
(344,115,0,0,'Created','2021-04-25 10:50:12',NULL,-1,0,'create'),
(345,116,0,0,'Created','2021-04-25 10:50:12',NULL,-1,0,'create'),
(346,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(347,0,3,0,'Deactivated the Family','2021-04-25 10:53:35',NULL,3,0,'edit'),
(348,117,0,0,'Created via Family','2021-04-25 10:54:55',NULL,3,0,'create'),
(349,118,0,0,'Created via Family','2021-04-25 10:54:55',NULL,3,0,'create'),
(350,119,0,0,'Created via Family','2021-04-25 10:54:56',NULL,3,0,'create'),
(351,120,0,0,'Created via Family','2021-04-25 10:54:56',NULL,3,0,'create'),
(352,121,0,0,'Created via Family','2021-04-25 10:54:56',NULL,3,0,'create'),
(353,122,0,0,'Created via Family','2021-04-25 10:54:56',NULL,3,0,'create'),
(354,0,24,0,'Created','2021-04-25 10:54:55',NULL,3,0,'create'),
(355,123,0,0,'Created','2021-04-25 10:56:50',NULL,3,0,'create'),
(356,3,0,0,'system user changed password','2021-04-25 10:58:36',NULL,3,0,'user'),
(357,3,0,0,'system user changed password','2021-04-25 10:58:53',NULL,3,0,'user'),
(358,124,0,0,'Created via Family','2021-04-25 12:35:39',NULL,3,0,'create'),
(359,125,0,0,'Created via Family','2021-04-25 12:35:39',NULL,3,0,'create'),
(360,126,0,0,'Created via Family','2021-04-25 12:35:39',NULL,3,0,'create'),
(361,127,0,0,'Created via Family','2021-04-25 12:35:39',NULL,3,0,'create'),
(362,128,0,0,'Created via Family','2021-04-25 12:35:39',NULL,3,0,'create'),
(363,129,0,0,'Created via Family','2021-04-25 12:35:39',NULL,3,0,'create'),
(364,0,25,0,'Created','2021-04-25 12:35:39',NULL,3,0,'create'),
(365,0,6,0,'Updated','2016-11-19 15:52:44',NULL,1,0,'edit'),
(366,0,6,0,'Deactivated the Family','2021-04-25 12:37:28',NULL,1,0,'edit'),
(367,0,6,0,'Updated','2016-11-19 15:52:44',NULL,1,0,'edit'),
(368,0,6,0,'Activated the Family','2021-04-25 12:38:17',NULL,1,0,'edit'),
(369,130,0,0,'Created via Family','2021-04-25 12:41:04',NULL,3,0,'create'),
(370,131,0,0,'Created via Family','2021-04-25 12:41:04',NULL,3,0,'create'),
(371,132,0,0,'Created via Family','2021-04-25 12:41:04',NULL,3,0,'create'),
(372,133,0,0,'Created via Family','2021-04-25 12:41:04',NULL,3,0,'create'),
(373,134,0,0,'Created via Family','2021-04-25 12:41:04',NULL,3,0,'create'),
(374,135,0,0,'Created via Family','2021-04-25 12:41:04',NULL,3,0,'create'),
(375,0,26,0,'Created','2021-04-25 12:41:04',NULL,3,0,'create'),
(376,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(377,0,3,0,'Activated the Family','2021-04-25 12:43:11',NULL,3,0,'edit'),
(378,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(379,0,3,0,'Deactivated the Family','2021-04-25 12:44:14',NULL,3,0,'edit'),
(380,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(381,0,3,0,'Activated the Family','2021-04-25 12:44:28',NULL,3,0,'edit'),
(382,136,0,0,'Created via Family','2021-04-25 12:45:41',NULL,3,0,'create'),
(383,137,0,0,'Created via Family','2021-04-25 12:45:41',NULL,3,0,'create'),
(384,138,0,0,'Created via Family','2021-04-25 12:45:41',NULL,3,0,'create'),
(385,139,0,0,'Created via Family','2021-04-25 12:45:41',NULL,3,0,'create'),
(386,140,0,0,'Created via Family','2021-04-25 12:45:41',NULL,3,0,'create'),
(387,141,0,0,'Created via Family','2021-04-25 12:45:41',NULL,3,0,'create'),
(388,0,27,0,'Created','2021-04-25 12:45:41',NULL,3,0,'create'),
(389,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(390,0,3,0,'Deactivated the Family','2021-04-25 12:46:20',NULL,3,0,'edit'),
(391,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(392,0,3,0,'Activated the Family','2021-04-25 12:47:01',NULL,3,0,'edit'),
(393,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(394,0,3,0,'Deactivated the Family','2021-04-25 12:47:11',NULL,3,0,'edit'),
(395,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(396,0,3,0,'Activated the Family','2021-04-25 12:47:22',NULL,3,0,'edit'),
(397,142,0,0,'Created via Family','2021-04-25 12:47:38',NULL,3,0,'create'),
(398,143,0,0,'Created via Family','2021-04-25 12:47:38',NULL,3,0,'create'),
(399,144,0,0,'Created via Family','2021-04-25 12:47:38',NULL,3,0,'create'),
(400,145,0,0,'Created via Family','2021-04-25 12:47:38',NULL,3,0,'create'),
(401,146,0,0,'Created via Family','2021-04-25 12:47:38',NULL,3,0,'create'),
(402,147,0,0,'Created via Family','2021-04-25 12:47:38',NULL,3,0,'create'),
(403,0,28,0,'Created','2021-04-25 12:47:38',NULL,3,0,'create'),
(404,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(405,0,3,0,'Deactivated the Family','2021-04-25 12:48:01',NULL,3,0,'edit'),
(406,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(407,0,3,0,'Activated the Family','2021-04-25 12:48:12',NULL,3,0,'edit'),
(408,148,0,0,'Created via Family','2021-04-25 12:48:31',NULL,3,0,'create'),
(409,149,0,0,'Created via Family','2021-04-25 12:48:31',NULL,3,0,'create'),
(410,150,0,0,'Created via Family','2021-04-25 12:48:31',NULL,3,0,'create'),
(411,151,0,0,'Created via Family','2021-04-25 12:48:31',NULL,3,0,'create'),
(412,152,0,0,'Created via Family','2021-04-25 12:48:31',NULL,3,0,'create'),
(413,153,0,0,'Created via Family','2021-04-25 12:48:31',NULL,3,0,'create'),
(414,0,29,0,'Created','2021-04-25 12:48:31',NULL,3,0,'create'),
(415,95,0,0,'system user login reset','2021-04-25 13:09:08',NULL,1,0,'user'),
(416,95,0,0,'system user password reset','2021-04-25 13:09:10',NULL,1,0,'user'),
(417,0,2,0,'Verification email sent','2021-04-25 13:09:15',NULL,3,0,'verify-link'),
(418,76,0,0,'system user password changed by admin','2021-04-25 13:11:31',NULL,1,0,'user'),
(419,0,30,0,'Created','2021-04-25 13:13:24',NULL,-1,0,'create'),
(420,154,0,0,'Created','2021-04-25 13:13:24',NULL,-1,0,'create'),
(421,155,0,0,'Created','2021-04-25 13:13:24',NULL,-1,0,'create'),
(422,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(423,0,3,0,'Deactivated the Family','2021-04-25 13:15:16',NULL,3,0,'edit'),
(424,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(425,0,3,0,'Activated the Family','2021-04-25 13:15:29',NULL,3,0,'edit'),
(426,156,0,0,'Created via Family','2021-04-25 13:15:57',NULL,3,0,'create'),
(427,157,0,0,'Created via Family','2021-04-25 13:15:57',NULL,3,0,'create'),
(428,158,0,0,'Created via Family','2021-04-25 13:15:57',NULL,3,0,'create'),
(429,159,0,0,'Created via Family','2021-04-25 13:15:57',NULL,3,0,'create'),
(430,160,0,0,'Created via Family','2021-04-25 13:15:57',NULL,3,0,'create'),
(431,161,0,0,'Created via Family','2021-04-25 13:15:57',NULL,3,0,'create'),
(432,0,31,0,'Created','2021-04-25 13:15:57',NULL,3,0,'create'),
(433,162,0,0,'Created','2021-04-25 13:17:35',NULL,3,0,'create'),
(434,3,0,0,'system user changed password','2021-04-25 13:18:40',NULL,3,0,'user'),
(435,3,0,0,'system user changed password','2021-04-25 13:18:50',NULL,3,0,'user'),
(436,95,0,0,'system user login reset','2021-04-25 16:15:58',NULL,1,0,'user'),
(437,95,0,0,'system user password reset','2021-04-25 16:16:00',NULL,1,0,'user'),
(438,0,2,0,'Verification email sent','2021-04-25 16:16:06',NULL,3,0,'verify-link'),
(439,76,0,0,'system user password changed by admin','2021-04-25 16:18:39',NULL,1,0,'user'),
(440,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(441,0,3,0,'Deactivated the Family','2021-04-25 16:23:48',NULL,3,0,'edit'),
(442,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(443,0,3,0,'Activated the Family','2021-04-25 16:24:03',NULL,3,0,'edit'),
(444,163,0,0,'Created via Family','2021-04-25 16:24:32',NULL,3,0,'create'),
(445,164,0,0,'Created via Family','2021-04-25 16:24:32',NULL,3,0,'create'),
(446,165,0,0,'Created via Family','2021-04-25 16:24:32',NULL,3,0,'create'),
(447,166,0,0,'Created via Family','2021-04-25 16:24:32',NULL,3,0,'create'),
(448,167,0,0,'Created via Family','2021-04-25 16:24:32',NULL,3,0,'create'),
(449,168,0,0,'Created via Family','2021-04-25 16:24:32',NULL,3,0,'create'),
(450,0,32,0,'Created','2021-04-25 16:24:31',NULL,3,0,'create'),
(451,169,0,0,'Created','2021-04-25 16:26:33',NULL,3,0,'create'),
(452,3,0,0,'system user changed password','2021-04-25 16:27:52',NULL,3,0,'user'),
(453,3,0,0,'system user changed password','2021-04-25 16:28:03',NULL,3,0,'user'),
(454,95,0,0,'system user login reset','2021-04-25 16:39:21',NULL,1,0,'user'),
(455,95,0,0,'system user password reset','2021-04-25 16:39:23',NULL,1,0,'user'),
(456,0,2,0,'Verification email sent','2021-04-25 16:39:28',NULL,3,0,'verify-link'),
(457,76,0,0,'system user password changed by admin','2021-04-25 16:42:01',NULL,1,0,'user'),
(458,95,0,0,'system user login reset','2021-04-25 16:46:55',NULL,1,0,'user'),
(459,95,0,0,'system user password reset','2021-04-25 16:46:56',NULL,1,0,'user'),
(460,0,2,0,'Verification email sent','2021-04-25 16:47:02',NULL,3,0,'verify-link'),
(461,95,0,0,'system user login reset','2021-04-25 16:48:44',NULL,1,0,'user'),
(462,95,0,0,'system user password reset','2021-04-25 16:48:47',NULL,1,0,'user'),
(463,0,2,0,'Verification email sent','2021-04-25 16:48:54',NULL,3,0,'verify-link'),
(464,76,0,0,'system user password changed by admin','2021-04-25 16:53:24',NULL,1,0,'user'),
(465,0,33,0,'Created','2021-04-25 16:55:43',NULL,-1,0,'create'),
(466,170,0,0,'Created','2021-04-25 16:55:43',NULL,-1,0,'create'),
(467,171,0,0,'Created','2021-04-25 16:55:43',NULL,-1,0,'create'),
(468,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(469,0,3,0,'Deactivated the Family','2021-04-25 16:57:34',NULL,3,0,'edit'),
(470,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(471,0,3,0,'Activated the Family','2021-04-25 16:57:51',NULL,3,0,'edit'),
(472,172,0,0,'Created via Family','2021-04-25 16:58:11',NULL,3,0,'create'),
(473,173,0,0,'Created via Family','2021-04-25 16:58:11',NULL,3,0,'create'),
(474,174,0,0,'Created via Family','2021-04-25 16:58:11',NULL,3,0,'create'),
(475,175,0,0,'Created via Family','2021-04-25 16:58:11',NULL,3,0,'create'),
(476,176,0,0,'Created via Family','2021-04-25 16:58:11',NULL,3,0,'create'),
(477,177,0,0,'Created via Family','2021-04-25 16:58:11',NULL,3,0,'create'),
(478,0,34,0,'Created','2021-04-25 16:58:11',NULL,3,0,'create'),
(479,178,0,0,'Created','2021-04-25 16:59:38',NULL,3,0,'create'),
(480,3,0,0,'system user changed password','2021-04-25 17:00:41',NULL,3,0,'user'),
(481,3,0,0,'system user changed password','2021-04-25 17:00:51',NULL,3,0,'user'),
(482,95,0,0,'system user login reset','2021-04-25 17:04:32',NULL,1,0,'user'),
(483,95,0,0,'system user password reset','2021-04-25 17:04:34',NULL,1,0,'user'),
(484,0,2,0,'Verification email sent','2021-04-25 17:04:39',NULL,3,0,'verify-link'),
(485,76,0,0,'system user password changed by admin','2021-04-25 17:06:53',NULL,1,0,'user'),
(486,95,0,0,'system user login reset','2021-04-25 17:18:54',NULL,1,0,'user'),
(487,95,0,0,'system user password reset','2021-04-25 17:18:56',NULL,1,0,'user'),
(488,0,2,0,'Verification email sent','2021-04-25 17:19:01',NULL,3,0,'verify-link'),
(489,76,0,0,'system user password changed by admin','2021-04-25 17:21:52',NULL,1,0,'user'),
(490,0,35,0,'Created','2021-04-25 17:24:16',NULL,-1,0,'create'),
(491,179,0,0,'Created','2021-04-25 17:24:16',NULL,-1,0,'create'),
(492,180,0,0,'Created','2021-04-25 17:24:16',NULL,-1,0,'create'),
(493,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(494,0,3,0,'Deactivated the Family','2021-04-25 17:28:05',NULL,3,0,'edit'),
(495,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(496,0,3,0,'Activated the Family','2021-04-25 17:28:47',NULL,3,0,'edit'),
(497,181,0,0,'Created via Family','2021-04-25 17:29:15',NULL,3,0,'create'),
(498,182,0,0,'Created via Family','2021-04-25 17:29:15',NULL,3,0,'create'),
(499,183,0,0,'Created via Family','2021-04-25 17:29:15',NULL,3,0,'create'),
(500,184,0,0,'Created via Family','2021-04-25 17:29:15',NULL,3,0,'create'),
(501,185,0,0,'Created via Family','2021-04-25 17:29:15',NULL,3,0,'create'),
(502,186,0,0,'Created via Family','2021-04-25 17:29:15',NULL,3,0,'create'),
(503,0,36,0,'Created','2021-04-25 17:29:15',NULL,3,0,'create'),
(504,187,0,0,'Created','2021-04-25 17:30:35',NULL,3,0,'create'),
(505,3,0,0,'system user changed password','2021-04-25 17:31:49',NULL,3,0,'user'),
(506,3,0,0,'system user changed password','2021-04-25 17:32:01',NULL,3,0,'user'),
(507,95,0,0,'system user login reset','2021-04-25 17:34:18',NULL,1,0,'user'),
(508,95,0,0,'system user password reset','2021-04-25 17:34:21',NULL,1,0,'user'),
(509,0,2,0,'Verification email sent','2021-04-25 17:34:27',NULL,3,0,'verify-link'),
(510,76,0,0,'system user password changed by admin','2021-04-25 17:36:33',NULL,1,0,'user'),
(511,0,37,0,'Created','2021-04-25 17:37:18',NULL,-1,0,'create'),
(512,188,0,0,'Created','2021-04-25 17:37:19',NULL,-1,0,'create'),
(513,189,0,0,'Created','2021-04-25 17:37:19',NULL,-1,0,'create'),
(514,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(515,0,3,0,'Deactivated the Family','2021-04-25 17:38:50',NULL,3,0,'edit'),
(516,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(517,0,3,0,'Activated the Family','2021-04-25 17:39:02',NULL,3,0,'edit'),
(518,190,0,0,'Created via Family','2021-04-25 17:39:21',NULL,3,0,'create'),
(519,191,0,0,'Created via Family','2021-04-25 17:39:21',NULL,3,0,'create'),
(520,192,0,0,'Created via Family','2021-04-25 17:39:21',NULL,3,0,'create'),
(521,193,0,0,'Created via Family','2021-04-25 17:39:21',NULL,3,0,'create'),
(522,194,0,0,'Created via Family','2021-04-25 17:39:21',NULL,3,0,'create'),
(523,195,0,0,'Created via Family','2021-04-25 17:39:21',NULL,3,0,'create'),
(524,0,38,0,'Created','2021-04-25 17:39:21',NULL,3,0,'create'),
(525,196,0,0,'Created','2021-04-25 17:40:34',NULL,3,0,'create'),
(526,3,0,0,'system user changed password','2021-04-25 17:41:28',NULL,3,0,'user'),
(527,3,0,0,'system user changed password','2021-04-25 17:41:37',NULL,3,0,'user'),
(528,95,0,0,'system user login reset','2021-04-25 20:00:09',NULL,1,0,'user'),
(529,95,0,0,'system user password reset','2021-04-25 20:00:11',NULL,1,0,'user'),
(530,0,2,0,'Verification email sent','2021-04-25 20:00:18',NULL,3,0,'verify-link'),
(531,76,0,0,'system user password changed by admin','2021-04-25 20:03:06',NULL,1,0,'user'),
(532,0,39,0,'Created','2021-04-25 20:05:48',NULL,-1,0,'create'),
(533,197,0,0,'Created','2021-04-25 20:05:48',NULL,-1,0,'create'),
(534,198,0,0,'Created','2021-04-25 20:05:48',NULL,-1,0,'create'),
(535,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(536,0,3,0,'Deactivated the Family','2021-04-25 20:07:22',NULL,3,0,'edit'),
(537,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(538,0,3,0,'Activated the Family','2021-04-25 20:07:35',NULL,3,0,'edit'),
(539,199,0,0,'Created via Family','2021-04-25 20:07:53',NULL,3,0,'create'),
(540,200,0,0,'Created via Family','2021-04-25 20:07:53',NULL,3,0,'create'),
(541,201,0,0,'Created via Family','2021-04-25 20:07:53',NULL,3,0,'create'),
(542,202,0,0,'Created via Family','2021-04-25 20:07:53',NULL,3,0,'create'),
(543,203,0,0,'Created via Family','2021-04-25 20:07:53',NULL,3,0,'create'),
(544,204,0,0,'Created via Family','2021-04-25 20:07:53',NULL,3,0,'create'),
(545,0,40,0,'Created','2021-04-25 20:07:53',NULL,3,0,'create'),
(546,205,0,0,'Created','2021-04-25 20:09:02',NULL,3,0,'create'),
(547,3,0,0,'system user changed password','2021-04-25 20:09:55',NULL,3,0,'user'),
(548,3,0,0,'system user changed password','2021-04-25 20:10:04',NULL,3,0,'user'),
(549,95,0,0,'system user login reset','2021-04-25 21:32:18',NULL,1,0,'user'),
(550,95,0,0,'system user password reset','2021-04-25 21:32:21',NULL,1,0,'user'),
(551,0,2,0,'Verification email sent','2021-04-25 21:32:26',NULL,3,0,'verify-link'),
(552,76,0,0,'system user password changed by admin','2021-04-25 21:35:47',NULL,1,0,'user'),
(553,19,0,0,'Updated','2021-04-25 21:36:05',NULL,1,0,'edit'),
(554,18,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(555,19,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(556,21,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(557,22,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(558,23,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(559,24,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(560,25,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(561,20,0,0,'Updated via Family','2021-04-25 21:36:43',NULL,1,0,'edit'),
(562,0,4,0,'Updated','2021-04-25 21:36:43',NULL,1,0,'edit'),
(563,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(564,0,3,0,'Deactivated the Family','2021-04-25 21:40:39',NULL,3,0,'edit'),
(565,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(566,0,3,0,'Activated the Family','2021-04-25 21:40:56',NULL,3,0,'edit'),
(567,206,0,0,'Created via Family','2021-04-25 21:41:31',NULL,3,0,'create'),
(568,207,0,0,'Created via Family','2021-04-25 21:41:31',NULL,3,0,'create'),
(569,208,0,0,'Created via Family','2021-04-25 21:41:31',NULL,3,0,'create'),
(570,209,0,0,'Created via Family','2021-04-25 21:41:31',NULL,3,0,'create'),
(571,210,0,0,'Created via Family','2021-04-25 21:41:31',NULL,3,0,'create'),
(572,211,0,0,'Created via Family','2021-04-25 21:41:31',NULL,3,0,'create'),
(573,0,41,0,'Created','2021-04-25 21:41:31',NULL,3,0,'create'),
(574,212,0,0,'Created','2021-04-25 21:43:48',NULL,3,0,'create'),
(575,3,0,0,'system user changed password','2021-04-25 21:45:00',NULL,3,0,'user'),
(576,3,0,0,'system user changed password','2021-04-25 21:45:10',NULL,3,0,'user'),
(577,95,0,0,'system user login reset','2021-04-25 21:48:47',NULL,1,0,'user'),
(578,95,0,0,'system user password reset','2021-04-25 21:48:49',NULL,1,0,'user'),
(579,0,2,0,'Verification email sent','2021-04-25 21:48:55',NULL,3,0,'verify-link'),
(580,76,0,0,'system user password changed by admin','2021-04-25 21:51:42',NULL,1,0,'user'),
(581,0,42,0,'Created','2021-04-25 21:52:35',NULL,-1,0,'create'),
(582,213,0,0,'Created','2021-04-25 21:52:35',NULL,-1,0,'create'),
(583,214,0,0,'Created','2021-04-25 21:52:35',NULL,-1,0,'create'),
(584,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(585,0,3,0,'Deactivated the Family','2021-04-25 21:54:26',NULL,3,0,'edit'),
(586,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(587,0,3,0,'Activated the Family','2021-04-25 21:54:47',NULL,3,0,'edit'),
(588,215,0,0,'Created via Family','2021-04-25 21:55:18',NULL,3,0,'create'),
(589,216,0,0,'Created via Family','2021-04-25 21:55:18',NULL,3,0,'create'),
(590,217,0,0,'Created via Family','2021-04-25 21:55:18',NULL,3,0,'create'),
(591,218,0,0,'Created via Family','2021-04-25 21:55:18',NULL,3,0,'create'),
(592,219,0,0,'Created via Family','2021-04-25 21:55:18',NULL,3,0,'create'),
(593,220,0,0,'Created via Family','2021-04-25 21:55:18',NULL,3,0,'create'),
(594,0,43,0,'Created','2021-04-25 21:55:18',NULL,3,0,'create'),
(595,221,0,0,'Created','2021-04-25 21:57:16',NULL,3,0,'create'),
(596,3,0,0,'system user changed password','2021-04-25 21:58:46',NULL,3,0,'user'),
(597,3,0,0,'system user changed password','2021-04-25 21:58:58',NULL,3,0,'user'),
(598,95,0,0,'system user login reset','2021-04-25 22:39:43',NULL,1,0,'user'),
(599,95,0,0,'system user password reset','2021-04-25 22:39:46',NULL,1,0,'user'),
(600,0,2,0,'Verification email sent','2021-04-25 22:39:53',NULL,3,0,'verify-link'),
(601,76,0,0,'system user password changed by admin','2021-04-25 22:42:54',NULL,1,0,'user'),
(602,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(603,0,3,0,'Deactivated the Family','2021-04-25 22:48:03',NULL,3,0,'edit'),
(604,0,3,0,'Updated','2017-04-15 17:21:40',NULL,1,0,'edit'),
(605,0,3,0,'Activated the Family','2021-04-25 22:48:22',NULL,3,0,'edit'),
(606,222,0,0,'Created via Family','2021-04-25 22:48:59',NULL,3,0,'create'),
(607,223,0,0,'Created via Family','2021-04-25 22:48:59',NULL,3,0,'create'),
(608,224,0,0,'Created via Family','2021-04-25 22:48:59',NULL,3,0,'create'),
(609,225,0,0,'Created via Family','2021-04-25 22:48:59',NULL,3,0,'create'),
(610,226,0,0,'Created via Family','2021-04-25 22:48:59',NULL,3,0,'create'),
(611,227,0,0,'Created via Family','2021-04-25 22:48:59',NULL,3,0,'create'),
(612,0,44,0,'Created','2021-04-25 22:48:59',NULL,3,0,'create'),
(613,228,0,0,'Created','2021-04-25 22:50:53',NULL,3,0,'create'),
(614,3,0,0,'system user changed password','2021-04-25 22:52:22',NULL,3,0,'user'),
(615,3,0,0,'system user changed password','2021-04-25 22:52:34',NULL,3,0,'user'),
(616,0,13,0,'Updated','2016-11-19 15:49:36',NULL,1,0,'edit'),
(617,0,13,0,'Deactivated the Family','2022-12-03 14:38:02',NULL,1,0,'edit'),
(618,0,13,0,'Updated','2016-11-19 15:49:36',NULL,1,0,'edit'),
(619,0,13,0,'Activated the Family','2022-12-03 14:38:26',NULL,1,0,'edit'),
(620,95,0,0,'system user deleted','2022-12-03 17:05:27',NULL,1,0,'user'),
(621,76,0,0,'system user deleted','2022-12-03 17:06:34',NULL,1,0,'user'),
(622,3,0,0,'system user deleted','2022-12-03 17:07:19',NULL,1,0,'user'),
(623,59,0,0,'system user created','2022-12-03 17:09:58',NULL,1,0,'user'),
(624,59,0,0,'system user deleted','2022-12-03 17:10:05',NULL,1,0,'user'),
(625,59,0,0,'system user created','2022-12-03 17:12:15',NULL,1,0,'user'),
(626,59,0,0,'system user deleted','2022-12-03 17:12:22',NULL,1,0,'user'),
(627,3,0,0,'system user created','2022-12-29 18:40:16',NULL,1,0,'user'),
(628,3,0,0,NULL,'2022-12-29 18:40:27',NULL,1,0,'user'),
(629,3,0,0,'system user password changed by admin','2022-12-29 18:43:18',NULL,1,0,'user'),
(630,95,0,0,'system user created','2022-12-29 21:01:30',NULL,1,0,'user'),
(631,95,0,0,'system user login reset','2022-12-29 21:01:40',NULL,1,0,'user'),
(632,95,0,0,'system user password reset','2022-12-29 21:01:42',NULL,1,0,'user'),
(633,88,0,0,'Updated','2023-11-16 12:39:33',NULL,1,0,'edit'),
(635,95,0,0,'system user password changed by admin','2025-12-01 19:32:56',NULL,1,0,'user'),
(636,95,0,0,'system user updated','2025-12-01 19:33:14',NULL,1,0,'user'),
(637,99,0,0,'system user created','2025-12-01 20:26:05',NULL,1,0,'user'),
(638,99,0,0,'system user created','2025-12-01 20:26:05',NULL,1,0,'user'),
(639,236,0,0,'system user changed password','2026-05-01 16:21:05',NULL,236,0,'user'),
(640,0,46,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(642,0,47,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(644,0,48,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(646,0,49,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(648,0,50,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(650,0,51,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(652,0,52,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(654,0,53,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(656,0,54,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(658,0,55,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(660,0,56,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(662,0,57,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(664,0,58,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(666,0,59,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(668,0,60,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(670,0,61,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(672,0,62,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(674,0,63,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(676,0,64,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(678,0,65,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(680,0,66,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(682,0,67,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(684,0,68,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(686,0,69,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(688,0,70,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(690,0,71,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(692,0,72,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(694,0,73,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(696,0,74,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(698,0,75,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(700,0,76,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(702,0,77,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(704,0,78,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(706,0,79,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(708,0,80,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(710,0,81,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(712,0,82,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(714,0,83,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(716,0,84,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(718,0,85,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(720,0,86,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(722,0,87,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(724,0,88,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(726,0,89,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(728,0,90,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(730,0,91,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(732,0,92,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(734,0,93,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(736,0,94,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(738,0,95,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(740,0,96,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(742,0,97,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(744,0,98,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(746,0,99,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(748,0,100,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(750,0,101,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(752,0,102,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(754,0,103,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(756,0,104,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(758,0,105,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(760,0,106,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(762,0,107,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(764,0,108,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(766,0,109,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(768,0,110,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(770,0,111,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(772,0,112,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(774,0,113,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(776,0,114,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(778,0,115,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(780,0,116,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(782,0,117,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(784,0,118,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(786,0,119,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(788,0,120,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(790,0,121,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(792,0,122,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(794,0,123,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(796,0,124,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(798,0,125,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(800,0,126,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(802,0,127,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(804,0,128,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(806,0,129,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(808,0,130,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(810,0,131,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(812,0,132,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(814,0,133,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(816,0,134,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(818,0,135,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(820,0,136,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(822,0,137,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(824,0,138,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(826,0,139,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(828,0,140,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(830,0,141,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(832,0,142,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(834,0,143,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(836,0,144,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(838,0,145,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(840,0,146,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(842,0,147,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(844,0,148,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(846,0,149,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(848,0,150,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(850,0,151,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(852,0,152,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(854,0,153,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(856,0,154,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(858,0,155,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(860,0,156,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(862,0,157,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(864,0,158,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(866,0,159,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(868,0,160,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(870,0,161,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(872,0,162,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(874,0,163,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(876,0,164,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(878,0,165,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(880,0,166,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(882,0,167,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(884,0,168,0,'Créé','2026-05-02 07:32:58',NULL,1,0,'create'),
(886,0,169,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(888,0,170,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(890,0,171,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(892,0,172,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(894,0,173,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(896,0,174,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(898,0,175,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(900,0,176,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(902,0,177,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(904,0,178,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(906,0,179,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(908,0,180,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(910,0,181,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(912,0,182,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(914,0,183,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(916,0,184,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(918,0,185,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(920,0,186,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(922,0,187,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(924,0,188,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(926,0,189,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(928,0,190,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(930,0,191,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(932,0,192,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(934,0,193,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(936,0,194,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(938,0,195,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(940,0,196,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(942,0,197,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(944,0,198,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(946,0,199,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(948,0,200,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(950,0,201,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(952,0,202,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(954,0,203,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(956,0,204,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(958,0,205,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(960,0,206,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(962,0,207,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(964,0,208,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(966,0,209,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(968,0,210,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(970,0,211,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(972,0,212,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(974,0,213,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(976,0,214,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(978,0,215,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(980,0,216,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(982,0,217,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(984,0,218,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(986,0,219,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(988,0,220,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(990,0,221,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(992,0,222,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(994,0,223,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(996,0,224,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(998,0,225,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1000,0,226,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1002,0,227,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1004,0,228,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1006,0,229,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1008,0,230,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1010,0,231,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1012,0,232,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1014,0,233,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1016,0,234,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1018,0,235,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1020,0,236,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1022,0,237,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1024,0,238,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1026,0,239,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1028,0,240,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1030,0,241,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1032,0,242,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1034,0,243,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1036,0,244,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1038,0,245,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1040,0,246,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1042,0,247,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1044,0,248,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1046,0,249,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1048,0,250,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1050,0,251,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1052,0,252,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1054,0,253,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1056,0,254,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1058,0,255,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1060,0,256,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1062,0,257,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1064,0,258,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1066,0,259,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1068,0,260,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1070,0,261,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1072,0,262,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1074,0,263,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1076,0,264,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1078,0,265,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1080,0,266,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1082,0,267,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1084,0,268,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1086,0,269,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1088,0,270,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1090,0,271,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1092,0,272,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1094,0,273,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1096,0,274,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1098,0,275,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1100,0,276,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1102,0,277,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1104,0,278,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1106,0,279,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1108,0,280,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1110,0,281,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1112,0,282,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1114,0,283,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1116,0,284,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1118,0,285,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1120,0,286,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1122,0,287,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1124,0,288,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1126,0,289,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1128,0,290,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1130,0,291,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1132,0,292,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1134,0,293,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1136,0,294,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1138,0,295,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1140,0,296,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1142,0,297,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1144,0,298,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1146,0,299,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1148,0,300,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1150,0,301,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1152,0,302,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1154,0,303,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1156,0,304,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1158,0,305,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1160,0,306,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1162,0,307,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1164,0,308,0,'Créé','2026-05-02 07:32:59',NULL,1,0,'create'),
(1166,0,309,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1168,0,310,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1170,0,311,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1172,0,312,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1174,0,313,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1176,0,314,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1178,0,315,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1180,0,316,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1182,0,317,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1184,0,318,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1186,0,319,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1188,0,320,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1190,0,321,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1192,0,322,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1194,0,323,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1196,0,324,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1198,0,325,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1200,0,326,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1202,0,327,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1204,0,328,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1206,0,329,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1208,0,330,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1210,0,331,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1212,0,332,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1214,0,333,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1216,0,334,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1218,0,335,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1220,0,336,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1222,0,337,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1224,0,338,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1226,0,339,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1228,0,340,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1230,0,341,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1232,0,342,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1234,0,343,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1236,0,344,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1238,0,345,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1240,0,346,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1242,0,347,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1244,0,348,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1246,0,349,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1248,0,350,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1250,0,351,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1252,0,352,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1254,0,353,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1256,0,354,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1258,0,355,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1260,0,356,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1262,0,357,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1264,0,358,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1266,0,359,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1268,0,360,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1270,0,361,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1272,0,362,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1274,0,363,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1276,0,364,0,'Créé','2026-05-02 07:33:00',NULL,1,0,'create'),
(1278,0,365,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1279,561,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1280,0,366,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1281,562,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1282,0,367,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1283,563,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1284,0,368,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1285,564,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1286,0,369,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1287,565,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1288,0,370,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1289,566,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1290,0,371,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1291,567,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1292,0,372,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1293,568,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1294,0,373,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1295,569,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1296,0,374,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1297,570,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1298,0,375,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1299,571,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1300,0,376,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1301,572,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1302,0,377,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1303,573,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1304,0,378,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1305,574,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1306,0,379,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1307,575,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1308,0,380,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1309,576,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1310,0,381,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1311,577,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1312,0,382,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1313,578,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1314,0,383,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1315,579,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1316,0,384,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1317,580,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1318,0,385,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1319,581,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1320,0,386,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1321,582,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1322,0,387,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1323,583,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1324,0,388,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1325,584,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1326,0,389,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1327,585,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1328,0,390,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1329,586,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1330,0,391,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1331,587,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1332,0,392,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1333,588,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1334,0,393,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1335,589,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1336,0,394,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1337,590,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1338,0,395,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1339,591,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1340,0,396,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1341,592,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1342,0,397,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1343,593,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1344,0,398,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1345,594,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1346,0,399,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1347,595,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1348,0,400,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1349,596,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1350,0,401,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1351,597,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1352,0,402,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1353,598,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1354,0,403,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1355,599,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1356,0,404,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1357,600,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1358,0,405,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1359,601,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1360,0,406,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1361,602,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1362,0,407,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1363,603,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1364,0,408,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1365,604,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1366,0,409,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1367,605,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1368,0,410,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1369,606,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1370,0,411,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1371,607,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1372,0,412,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1373,608,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1374,0,413,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1375,609,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1376,0,414,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1377,610,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1378,0,415,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1379,611,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1380,0,416,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1381,612,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1382,0,417,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1383,613,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1384,0,418,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1385,614,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1386,0,419,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1387,615,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1388,0,420,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1389,616,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1390,0,421,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1391,617,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1392,0,422,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1393,618,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1394,0,423,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1395,619,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1396,0,424,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1397,620,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1398,0,425,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1399,621,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1400,0,426,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1401,622,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1402,0,427,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1403,623,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1404,0,428,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1405,624,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1406,0,429,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1407,625,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1408,0,430,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1409,626,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1410,0,431,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1411,627,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1412,0,432,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1413,628,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1414,0,433,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1415,629,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1416,0,434,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1417,630,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1418,0,435,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1419,631,0,0,'Créé','2026-05-02 07:33:14',NULL,1,0,'create'),
(1420,0,436,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1421,632,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1422,0,437,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1423,633,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1424,0,438,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1425,634,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1426,0,439,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1427,635,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1428,0,440,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1429,636,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1430,0,441,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1431,637,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1432,0,442,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1433,638,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1434,0,443,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1435,639,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1436,0,444,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1437,640,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1438,0,445,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1439,641,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1440,0,446,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1441,642,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1442,0,447,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1443,643,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1444,0,448,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1445,644,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1446,0,449,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1447,645,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1448,0,450,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1449,646,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1450,0,451,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1451,647,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1452,0,452,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1453,648,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1454,0,453,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1455,649,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1456,0,454,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1457,650,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1458,0,455,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1459,651,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1460,0,456,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1461,652,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1462,0,457,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1463,653,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1464,0,458,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1465,654,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1466,0,459,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1467,655,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1468,0,460,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1469,656,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1470,0,461,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1471,657,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1472,0,462,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1473,658,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1474,0,463,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1475,659,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1476,0,464,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1477,660,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1478,0,465,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1479,661,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1480,0,466,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1481,662,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1482,0,467,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1483,663,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1484,0,468,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1485,664,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1486,0,469,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1487,665,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1488,0,470,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1489,666,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1490,0,471,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1491,667,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1492,0,472,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1493,668,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1494,0,473,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1495,669,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1496,0,474,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1497,670,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1498,0,475,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1499,671,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1500,0,476,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1501,672,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1502,0,477,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1503,673,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1504,0,478,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1505,674,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1506,0,479,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1507,675,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1508,0,480,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1509,676,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1510,0,481,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1511,677,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1512,0,482,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1513,678,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1514,0,483,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1515,679,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1516,0,484,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1517,680,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1518,0,485,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1519,681,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1520,0,486,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1521,682,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1522,0,487,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1523,683,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1524,0,488,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1525,684,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1526,0,489,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1527,685,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1528,0,490,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1529,686,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1530,0,491,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1531,687,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1532,0,492,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1533,688,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1534,0,493,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1535,689,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1536,0,494,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1537,690,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1538,0,495,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1539,691,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1540,0,496,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1541,692,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1542,0,497,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1543,693,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1544,0,498,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1545,694,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1546,0,499,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1547,695,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1548,0,500,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1549,696,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1550,0,501,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1551,697,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1552,0,502,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1553,698,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1554,0,503,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1555,699,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1556,0,504,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1557,700,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1558,0,505,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1559,701,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1560,0,506,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1561,702,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1562,0,507,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1563,703,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1564,0,508,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1565,704,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1566,0,509,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1567,705,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1568,0,510,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1569,706,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1570,0,511,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1571,707,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1572,0,512,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1573,708,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1574,0,513,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1575,709,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1576,0,514,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1577,710,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1578,0,515,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1579,711,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1580,0,516,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1581,712,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1582,0,517,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1583,713,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1584,0,518,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1585,714,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1586,0,519,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1587,715,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1588,0,520,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1589,716,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1590,0,521,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1591,717,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1592,0,522,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1593,718,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1594,0,523,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1595,719,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1596,0,524,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1597,720,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1598,0,525,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1599,721,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1600,0,526,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1601,722,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1602,0,527,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1603,723,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1604,0,528,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1605,724,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1606,0,529,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1607,725,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1608,0,530,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1609,726,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1610,0,531,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1611,727,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1612,0,532,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1613,728,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1614,0,533,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1615,729,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1616,0,534,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1617,730,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1618,0,535,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1619,731,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1620,0,536,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1621,732,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1622,0,537,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1623,733,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1624,0,538,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1625,734,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1626,0,539,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1627,735,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1628,0,540,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1629,736,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1630,0,541,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1631,737,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1632,0,542,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1633,738,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1634,0,543,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1635,739,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1636,0,544,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1637,740,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1638,0,545,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1639,741,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1640,0,546,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1641,742,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1642,0,547,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1643,743,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1644,0,548,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1645,744,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1646,0,549,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1647,745,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1648,0,550,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1649,746,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1650,0,551,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1651,747,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1652,0,552,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1653,748,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1654,0,553,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1655,749,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1656,0,554,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1657,750,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1658,0,555,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1659,751,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1660,0,556,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1661,752,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1662,0,557,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1663,753,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1664,0,558,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1665,754,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1666,0,559,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1667,755,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1668,0,560,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1669,756,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1670,0,561,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1671,757,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1672,0,562,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1673,758,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1674,0,563,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1675,759,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1676,0,564,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1677,760,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1678,0,565,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1679,761,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1680,0,566,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1681,762,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1682,0,567,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1683,763,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1684,0,568,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1685,764,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1686,0,569,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1687,765,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1688,0,570,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1689,766,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1690,0,571,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1691,767,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1692,0,572,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1693,768,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1694,0,573,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1695,769,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1696,0,574,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1697,770,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1698,0,575,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1699,771,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1700,0,576,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1701,772,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1702,0,577,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1703,773,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1704,0,578,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1705,774,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1706,0,579,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1707,775,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1708,0,580,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1709,776,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1710,0,581,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1711,777,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1712,0,582,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1713,778,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1714,0,583,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1715,779,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1716,0,584,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1717,780,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1718,0,585,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1719,781,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1720,0,586,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1721,782,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1722,0,587,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1723,783,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1724,0,588,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1725,784,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1726,0,589,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1727,785,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1728,0,590,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1729,786,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1730,0,591,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1731,787,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1732,0,592,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1733,788,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1734,0,593,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1735,789,0,0,'Créé','2026-05-02 07:33:15',NULL,1,0,'create'),
(1736,0,594,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1737,790,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1738,0,595,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1739,791,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1740,0,596,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1741,792,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1742,0,597,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1743,793,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1744,0,598,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1745,794,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1746,0,599,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1747,795,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1748,0,600,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1749,796,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1750,0,601,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1751,797,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1752,0,602,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1753,798,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1754,0,603,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1755,799,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1756,0,604,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1757,800,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1758,0,605,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1759,801,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1760,0,606,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1761,802,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1762,0,607,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1763,803,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1764,0,608,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1765,804,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1766,0,609,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1767,805,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1768,0,610,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1769,806,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1770,0,611,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1771,807,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1772,0,612,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1773,808,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1774,0,613,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1775,809,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1776,0,614,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1777,810,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1778,0,615,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1779,811,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1780,0,616,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1781,812,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1782,0,617,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1783,813,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1784,0,618,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1785,814,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1786,0,619,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1787,815,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1788,0,620,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1789,816,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1790,0,621,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1791,817,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1792,0,622,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1793,818,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1794,0,623,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1795,819,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1796,0,624,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1797,820,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1798,0,625,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1799,821,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1800,0,626,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1801,822,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1802,0,627,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1803,823,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1804,0,628,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1805,824,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1806,0,629,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1807,825,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1808,0,630,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1809,826,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1810,0,631,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1811,827,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1812,0,632,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1813,828,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1814,0,633,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1815,829,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1816,0,634,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1817,830,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1818,0,635,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1819,831,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1820,0,636,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1821,832,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1822,0,637,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1823,833,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1824,0,638,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1825,834,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1826,0,639,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1827,835,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1828,0,640,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1829,836,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1830,0,641,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1831,837,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1832,0,642,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1833,838,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1834,0,643,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1835,839,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1836,0,644,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1837,840,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1838,0,645,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1839,841,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1840,0,646,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1841,842,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1842,0,647,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1843,843,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1844,0,648,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1845,844,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1846,0,649,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1847,845,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1848,0,650,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1849,846,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1850,0,651,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1851,847,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1852,0,652,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1853,848,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1854,0,653,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1855,849,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1856,0,654,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1857,850,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1858,0,655,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1859,851,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1860,0,656,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1861,852,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1862,0,657,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1863,853,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1864,0,658,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1865,854,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1866,0,659,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1867,855,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1868,0,660,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1869,856,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1870,0,661,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1871,857,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1872,0,662,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1873,858,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1874,0,663,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1875,859,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1876,0,664,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1877,860,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1878,0,665,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1879,861,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1880,0,666,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1881,862,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1882,0,667,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1883,863,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1884,0,668,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1885,864,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1886,0,669,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1887,865,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1888,0,670,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1889,866,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1890,0,671,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1891,867,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1892,0,672,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1893,868,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1894,0,673,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1895,869,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1896,0,674,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1897,870,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1898,0,675,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1899,871,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1900,0,676,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1901,872,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1902,0,677,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1903,873,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1904,0,678,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1905,874,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1906,0,679,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1907,875,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1908,0,680,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1909,876,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1910,0,681,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1911,877,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1912,0,682,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1913,878,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1914,0,683,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1915,879,0,0,'Créé','2026-05-02 07:33:16',NULL,1,0,'create'),
(1916,1311,0,0,'Image de profil téléchargée','2026-05-02 08:10:55',NULL,1492,0,'photo'),
(1917,0,1016,0,'Mis à jour','2026-05-02 09:33:25',NULL,1492,0,'edit'),
(1918,1268,0,0,'Mis à jour','2026-05-02 09:33:25',NULL,1492,0,'edit'),
(1919,1269,0,0,'Mis à jour','2026-05-02 09:33:25',NULL,1492,0,'edit'),
(1920,0,1016,0,'Données Familiale vérifiées','2026-05-02 09:34:01',NULL,1492,0,'verify'),
(1921,0,1016,0,'Mis à jour','2026-05-02 09:36:17',NULL,1492,0,'edit'),
(1922,1268,0,0,'Mis à jour','2026-05-02 09:36:17',NULL,1492,0,'edit'),
(1923,1269,0,0,'Mis à jour','2026-05-02 09:36:17',NULL,1492,0,'edit'),
(1924,1311,0,0,'Mis à jour','2026-05-19 21:34:29',NULL,1493,0,'edit');
/*!40000 ALTER TABLE `note_nte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paddlenum_pn`
--

DROP TABLE IF EXISTS `paddlenum_pn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `paddlenum_pn` (
  `pn_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `pn_fr_ID` mediumint(9) unsigned DEFAULT NULL,
  `pn_Num` mediumint(9) unsigned DEFAULT NULL,
  `pn_per_ID` mediumint(9) NOT NULL DEFAULT 0,
  PRIMARY KEY (`pn_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paddlenum_pn`
--

LOCK TABLES `paddlenum_pn` WRITE;
/*!40000 ALTER TABLE `paddlenum_pn` DISABLE KEYS */;
/*!40000 ALTER TABLE `paddlenum_pn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person2group2role_p2g2r`
--

DROP TABLE IF EXISTS `person2group2role_p2g2r`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `person2group2role_p2g2r` (
  `p2g2r_per_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `p2g2r_grp_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `p2g2r_rle_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`p2g2r_per_ID`,`p2g2r_grp_ID`),
  KEY `p2g2r_per_ID` (`p2g2r_per_ID`,`p2g2r_grp_ID`,`p2g2r_rle_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person2group2role_p2g2r`
--

LOCK TABLES `person2group2role_p2g2r` WRITE;
/*!40000 ALTER TABLE `person2group2role_p2g2r` DISABLE KEYS */;
/*!40000 ALTER TABLE `person2group2role_p2g2r` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person2volunteeropp_p2vo`
--

DROP TABLE IF EXISTS `person2volunteeropp_p2vo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `person2volunteeropp_p2vo` (
  `p2vo_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `p2vo_per_ID` mediumint(9) DEFAULT NULL,
  `p2vo_vol_ID` mediumint(9) DEFAULT NULL,
  PRIMARY KEY (`p2vo_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person2volunteeropp_p2vo`
--

LOCK TABLES `person2volunteeropp_p2vo` WRITE;
/*!40000 ALTER TABLE `person2volunteeropp_p2vo` DISABLE KEYS */;
/*!40000 ALTER TABLE `person2volunteeropp_p2vo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_custom`
--

DROP TABLE IF EXISTS `person_custom`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_custom` (
  `per_ID` mediumint(9) NOT NULL DEFAULT 0,
  `c1` mediumint(9) DEFAULT NULL,
  `c2` varchar(50) DEFAULT NULL,
  `c3` varchar(100) DEFAULT NULL,
  `c4` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`per_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_custom`
--

LOCK TABLES `person_custom` WRITE;
/*!40000 ALTER TABLE `person_custom` DISABLE KEYS */;
INSERT INTO `person_custom` VALUES
(1311,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `person_custom` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_custom_master`
--

DROP TABLE IF EXISTS `person_custom_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_custom_master` (
  `custom_Order` smallint(6) NOT NULL DEFAULT 0,
  `custom_Field` varchar(5) NOT NULL DEFAULT '',
  `custom_Name` varchar(40) NOT NULL DEFAULT '',
  `custom_Special` mediumint(8) unsigned DEFAULT NULL,
  `custom_FieldSec` tinyint(4) NOT NULL,
  `type_ID` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`custom_Field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_custom_master`
--

LOCK TABLES `person_custom_master` WRITE;
/*!40000 ALTER TABLE `person_custom_master` DISABLE KEYS */;
INSERT INTO `person_custom_master` VALUES
(1,'c1','Father of confession',11,2,9),
(2,'c2','Father of confession - Other',NULL,2,3),
(3,'c3','Highest Degree Received',NULL,1,4),
(4,'c4','My Custom Drop Down List',24,1,12);
/*!40000 ALTER TABLE `person_custom_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person_per`
--

DROP TABLE IF EXISTS `person_per`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `person_per` (
  `per_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `per_Title` varchar(50) DEFAULT NULL,
  `per_FirstName` varchar(50) DEFAULT NULL,
  `per_MiddleName` varchar(50) DEFAULT NULL,
  `per_LastName` varchar(50) DEFAULT NULL,
  `per_Suffix` varchar(50) DEFAULT NULL,
  `per_Address1` varchar(50) DEFAULT NULL,
  `per_Address2` varchar(50) DEFAULT NULL,
  `per_City` varchar(50) DEFAULT NULL,
  `per_State` varchar(50) DEFAULT NULL,
  `per_Zip` varchar(50) DEFAULT NULL,
  `per_Country` varchar(50) DEFAULT NULL,
  `per_HomePhone` varchar(30) DEFAULT NULL,
  `per_WorkPhone` varchar(30) DEFAULT NULL,
  `per_CellPhone` varchar(30) DEFAULT NULL,
  `per_Email` varchar(50) DEFAULT NULL,
  `per_WorkEmail` varchar(50) DEFAULT NULL,
  `per_BirthMonth` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `per_BirthDay` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `per_BirthYear` smallint(4) unsigned DEFAULT NULL,
  `per_MembershipDate` date DEFAULT NULL,
  `per_Gender` tinyint(1) unsigned NOT NULL DEFAULT 0,
  `per_fmr_ID` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `per_cls_ID` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `per_fam_ID` smallint(5) unsigned NOT NULL DEFAULT 0,
  `per_Envelope` smallint(5) unsigned DEFAULT NULL,
  `per_DateLastEdited` datetime DEFAULT NULL,
  `per_DateEntered` datetime NOT NULL,
  `per_EnteredBy` smallint(5) NOT NULL DEFAULT 0,
  `per_EditedBy` smallint(5) unsigned DEFAULT 0,
  `per_FriendDate` date DEFAULT NULL,
  `per_Flags` mediumint(9) NOT NULL DEFAULT 0,
  `per_Facebook` varchar(50) DEFAULT NULL,
  `per_Twitter` varchar(50) DEFAULT NULL,
  `per_LinkedIn` varchar(50) DEFAULT NULL,
  `per_DiscipleMakerID` mediumint(9) unsigned DEFAULT NULL,
  PRIMARY KEY (`per_ID`),
  KEY `idx_disciple_maker` (`per_DiscipleMakerID`),
  CONSTRAINT `fk_disciple_maker` FOREIGN KEY (`per_DiscipleMakerID`) REFERENCES `person_per` (`per_ID`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1494 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person_per`
--

LOCK TABLES `person_per` WRITE;
/*!40000 ALTER TABLE `person_per` DISABLE KEYS */;
INSERT INTO `person_per` VALUES
(1201,NULL,'ARMEL',NULL,'ESSOMBA',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'+221776952918',NULL,NULL,0,0,NULL,NULL,1,1,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1202,NULL,'Audrey',NULL,'BAGOA',NULL,NULL,NULL,'Amitié 2',NULL,NULL,NULL,NULL,NULL,'778571505',NULL,NULL,0,0,NULL,NULL,1,2,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1203,NULL,'Audrey',NULL,'Happi',NULL,NULL,NULL,'Amitié 2',NULL,NULL,NULL,NULL,NULL,'775593795',NULL,NULL,9,1,2025,NULL,1,1,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1204,NULL,'Dina Urielle Yipènè',NULL,'NEBIE',NULL,NULL,NULL,'Amitié 2',NULL,NULL,NULL,NULL,NULL,'+221711143602',NULL,NULL,10,18,2003,NULL,1,1,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1205,NULL,'Grace charden',NULL,'NGATSONGO AATSOLEDILLA',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'773969526',NULL,NULL,10,13,1990,NULL,1,1,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1206,NULL,'Mary-Madaline N.',NULL,'FONGUAZI',NULL,NULL,NULL,'Sicap Liberté 1',NULL,NULL,NULL,NULL,NULL,'787171957',NULL,NULL,7,9,1996,NULL,1,1,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1207,NULL,'Sopie Alida',NULL,'N\'din',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'773184185',NULL,NULL,0,0,NULL,NULL,2,1,2,1006,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1208,NULL,'Absa',NULL,'Pomane',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1007,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1209,NULL,'Emmanuel',NULL,'FAYE',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1007,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1210,NULL,'Germaine',NULL,'Maman',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1007,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1211,NULL,'H. Paulin',NULL,'Nemlin',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'765304206',NULL,NULL,0,0,NULL,NULL,1,1,2,1007,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1212,NULL,'Mélanie',NULL,'Sagna',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1007,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1213,NULL,'Adassa',NULL,'EKWOGHE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1214,NULL,'Alain',NULL,'EKWOGHE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'774653128',NULL,NULL,0,0,NULL,NULL,1,2,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1215,NULL,'Blessing',NULL,'EKWOGHE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'786077507',NULL,NULL,0,0,NULL,NULL,1,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1216,NULL,'Chanceline',NULL,'EKWOGHE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'781301208',NULL,NULL,0,0,NULL,NULL,2,2,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1217,NULL,'Daniel',NULL,'YOTA',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,2,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1218,NULL,'Luce Florette',NULL,'BISSA ANGOUE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'782951160',NULL,NULL,0,0,NULL,NULL,2,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1219,NULL,'MENGUE',NULL,'Vincent',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'+221784659298',NULL,NULL,0,0,NULL,NULL,2,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1220,NULL,'Marie',NULL,'YOTA',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1221,NULL,'Nadege',NULL,'Tchatat',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'788634318',NULL,NULL,0,0,NULL,NULL,2,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1222,NULL,'Sami',NULL,'Tchatat',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1223,NULL,'Sarah',NULL,'Tchatat',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1224,NULL,'Victor',NULL,'Yede',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'771975240',NULL,NULL,0,0,NULL,NULL,1,1,2,1008,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1225,NULL,'Affi Viviane',NULL,'EHOUTY',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1226,NULL,'Alizee',NULL,'BOUCKANDOU',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1227,NULL,'Catherine aby',NULL,'GUEYE',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1228,NULL,'Corinta',NULL,'NAKIZENON',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'777884579',NULL,NULL,0,0,NULL,NULL,2,2,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1229,NULL,'Isaac Daniel',NULL,'NAKIZENON',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1230,NULL,'Porinda',NULL,'TCHOUMOU',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1231,NULL,'Praise Djessouton',NULL,'NAKIZENON',NULL,NULL,NULL,'Maristes 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1009,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1232,NULL,'Agnès',NULL,'Mbom maih',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'+221710531750',NULL,NULL,0,0,NULL,NULL,1,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1233,NULL,'Ernest',NULL,'KIBALO AWIKODO',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'783137582',NULL,NULL,0,0,NULL,NULL,1,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1234,NULL,'Ernest Kibalo Essozolam',NULL,'AWIKODO',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'221783137582',NULL,NULL,0,0,NULL,NULL,1,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1235,NULL,'Firmin',NULL,'METINOU DJOU',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,2,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1236,NULL,'Flore',NULL,'Oky',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'770946533',NULL,NULL,0,0,NULL,NULL,2,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1237,NULL,'Ilona',NULL,'ELAGE ETOGE',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,10,1,2019,NULL,2,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1238,NULL,'Joelle',NULL,'PELASSE',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'221771943736',NULL,NULL,7,13,2005,NULL,2,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1239,NULL,'Marie',NULL,'Anne',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'785904694',NULL,NULL,0,0,NULL,NULL,2,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1240,NULL,'Michel',NULL,'Demba',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'769212604',NULL,NULL,0,0,NULL,NULL,1,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1241,NULL,'Philomène',NULL,'Sr',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'770610320',NULL,NULL,0,0,NULL,NULL,2,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1242,NULL,'Rhyvelle Partcy',NULL,'NEOSSI MONTHE',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'776954743',NULL,NULL,2,20,1995,NULL,1,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1243,NULL,'Syntiche kacela Bermine',NULL,'Zosset',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'771177635',NULL,NULL,10,1,2002,NULL,2,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1244,NULL,'William Henry',NULL,'Mbom Maih',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'+245966601419',NULL,NULL,0,0,NULL,NULL,1,1,2,1010,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1245,NULL,'Aimé',NULL,'LARE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'781862863',NULL,NULL,0,0,NULL,NULL,1,1,2,1011,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1246,NULL,'Denise',NULL,'Tendeng',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'774719477',NULL,NULL,0,0,NULL,NULL,2,1,2,1011,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1247,NULL,'Guy Arsène',NULL,'IMOGO',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'221778506467',NULL,NULL,8,27,2001,NULL,2,1,2,1011,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1248,NULL,'Northya',NULL,'ELLI',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1011,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1249,NULL,'Akoele Jeanne',NULL,'Teko',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'278',NULL,NULL,2,23,2004,NULL,2,1,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1250,NULL,'Akoko Jeannette',NULL,'TEKO',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'+221705627546',NULL,NULL,2,23,2004,NULL,2,1,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1251,NULL,'Awa Ndiaye',NULL,'SAMBOU',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'+221764067832',NULL,NULL,0,0,NULL,NULL,2,1,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1252,NULL,'Elom',NULL,'AMEFIA-KOFFIE',NULL,NULL,NULL,'Colobane',NULL,NULL,NULL,NULL,NULL,'778047272',NULL,NULL,0,0,NULL,NULL,1,2,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1253,NULL,'Floris',NULL,'KOFFI',NULL,NULL,NULL,'Colobane',NULL,NULL,NULL,NULL,NULL,'777360099',NULL,NULL,0,0,NULL,NULL,1,2,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1254,NULL,'HEUREUSE',NULL,'BOYENGUET',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'781562508',NULL,NULL,0,0,NULL,NULL,2,1,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1255,NULL,'Nicia',NULL,'NIAKISSA',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'762153909',NULL,NULL,0,0,NULL,NULL,2,1,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1256,NULL,'Nis exaucé',NULL,'NIAKISSA',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'778664397',NULL,NULL,0,0,NULL,NULL,1,1,2,1012,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1257,NULL,'Alassani',NULL,'KORIKO',NULL,NULL,NULL,'Keur Mbaye Fall',NULL,NULL,NULL,NULL,NULL,'777342090',NULL,NULL,0,0,NULL,NULL,1,1,2,1013,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1258,NULL,'Olga',NULL,'SAGNA',NULL,NULL,NULL,'Keur Mbaye Fall',NULL,NULL,NULL,NULL,NULL,'221773690810',NULL,NULL,0,0,NULL,NULL,2,2,2,1013,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1259,NULL,'Rosalie',NULL,'SAGNA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1013,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1260,NULL,'Albert Kotiaw',NULL,'SENE',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'763352968',NULL,NULL,0,0,NULL,NULL,1,2,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1261,NULL,'Amadou',NULL,'SENE',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1262,NULL,'Diouf',NULL,'Mane',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'781093132',NULL,NULL,0,0,NULL,NULL,1,2,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1263,NULL,'Diégane',NULL,'SENE',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1264,NULL,'Marie Angèle clémentine',NULL,'DIATTA',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'777570783',NULL,NULL,0,0,NULL,NULL,2,1,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1265,NULL,'Ousmane',NULL,'SENE',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1266,NULL,'Thérèse Marie',NULL,'TENDENG',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'775379000',NULL,NULL,10,16,1996,NULL,2,1,2,1014,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1267,NULL,'Alizee',NULL,'Bouckandou  Moudouma',NULL,NULL,NULL,'Maristes 2',NULL,NULL,NULL,NULL,NULL,'773401639',NULL,NULL,4,4,2026,NULL,2,1,2,1015,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1268,NULL,'Alphonsine Isabelle','','Boissy','',NULL,NULL,'Derkle',NULL,NULL,NULL,NULL,NULL,'782850546',NULL,NULL,1,1,1996,NULL,2,1,2,1016,NULL,'2026-05-02 09:36:17','2026-05-02 07:57:59',1,1492,NULL,0,NULL,NULL,NULL,NULL),
(1269,NULL,'Plim Christelle','','KONSO','',NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'221778783332',NULL,NULL,3,25,2003,NULL,2,1,2,1016,NULL,'2026-05-02 09:36:17','2026-05-02 07:57:59',1,1492,NULL,0,NULL,NULL,NULL,NULL),
(1270,NULL,'Amex Verlain',NULL,'ONIANE',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'781208075',NULL,NULL,0,0,NULL,NULL,1,1,2,1017,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1271,NULL,'Darwin',NULL,'TCHICAYA',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'770946053',NULL,NULL,0,0,NULL,NULL,1,1,2,1017,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1272,NULL,'Sheirole  Josialine',NULL,'Nzassi Mboumba',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1017,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1273,NULL,'Amexelle',NULL,'Oniane',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'778244494',NULL,NULL,4,30,2003,NULL,2,1,2,1018,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1274,NULL,'Bell',NULL,'MADAMA',NULL,NULL,NULL,'Sicap Liberté 5',NULL,NULL,NULL,NULL,NULL,'707472638',NULL,NULL,12,18,2015,NULL,1,1,2,1018,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1275,NULL,'Germaine',NULL,'MBENGE',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'781560930',NULL,NULL,0,0,NULL,NULL,2,1,2,1018,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1276,NULL,'Koubanza',NULL,'Christaime nocheldy',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'709605481',NULL,NULL,9,22,2001,NULL,2,1,2,1018,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1277,NULL,'Princesse Andrée',NULL,'KOUNDI TSAMBA',NULL,NULL,NULL,'Sicap Liberté 5',NULL,NULL,NULL,NULL,NULL,'781560940',NULL,NULL,0,0,NULL,NULL,2,1,2,1018,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1278,NULL,'TSAMBA',NULL,'KOUNDI',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1018,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1279,NULL,'Angéline',NULL,'BAKAM',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1019,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1280,NULL,'Fidèle',NULL,'BAKAM',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1019,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1281,NULL,'Anselme',NULL,'Bandiaky',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'778921068',NULL,NULL,0,0,NULL,NULL,2,1,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1282,NULL,'Benoît',NULL,'Bandiaky',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'777219766',NULL,NULL,0,0,NULL,NULL,1,1,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1283,NULL,'Florence',NULL,'Bidiar',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'779269121',NULL,NULL,0,0,NULL,NULL,2,1,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1284,NULL,'Maurille',NULL,'Tendeng',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'771559921',NULL,NULL,0,0,NULL,NULL,2,1,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1285,NULL,'Nancy',NULL,'Bandiaky',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'777219766',NULL,NULL,0,0,NULL,NULL,1,1,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1286,NULL,'Rebecca',NULL,'Dione',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1287,NULL,'Valery',NULL,'BANDIAKY',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1288,NULL,'Valery',NULL,'Kampal',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'775087339',NULL,NULL,0,0,NULL,NULL,1,2,2,1020,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1289,NULL,'Archange',NULL,'ÉDO',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,11,8,2013,NULL,2,1,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1290,NULL,'Kenania Gladys Annaelle Hope',NULL,'Ngwaby Mouagny',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'775258337',NULL,NULL,1,7,2014,NULL,2,1,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1291,NULL,'Maeva Chanice',NULL,'Opohoun',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'708592452',NULL,NULL,4,16,1996,NULL,2,1,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1292,NULL,'Marietou',NULL,'Tendeng',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,2,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1293,NULL,'Naomi Emmanuelle',NULL,'Niankini',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'775258337',NULL,NULL,0,0,NULL,NULL,2,1,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1294,NULL,'Nelly',NULL,'OSSA',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'786398666',NULL,NULL,0,0,NULL,NULL,1,2,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1295,NULL,'Oscar',NULL,'OSSA',NULL,NULL,NULL,'ZAC Mbao',NULL,NULL,NULL,NULL,NULL,'785944948',NULL,NULL,0,0,NULL,NULL,1,2,2,1021,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1296,NULL,'Armel Theauld',NULL,'MILEBE Nkombo',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'781257987',NULL,NULL,0,0,NULL,NULL,1,1,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1297,NULL,'Benie Urielle',NULL,'Pongo Nganie',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'785202445',NULL,NULL,3,18,2003,NULL,2,1,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1298,NULL,'Besty',NULL,'NKOUNKOU',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'781309413',NULL,NULL,0,0,NULL,NULL,1,2,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1299,NULL,'David Gédéon',NULL,'SABOUKOULOU',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'777897263',NULL,NULL,11,22,2001,NULL,1,1,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1300,NULL,'Emilien',NULL,'Mbili',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'777354236',NULL,NULL,0,0,NULL,NULL,1,1,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1301,NULL,'Herrys',NULL,'NKOUNKOU',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'+221774413241',NULL,NULL,0,0,NULL,NULL,1,2,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1302,NULL,'Reine Nathalie',NULL,'MPONGO NGANIE',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'787103349',NULL,NULL,6,13,2004,NULL,2,1,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1303,NULL,'Reine Theresa',NULL,'Mpongo Nganie',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'710179017',NULL,NULL,6,13,2004,NULL,2,1,2,1022,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1304,NULL,'Armelle',NULL,'Tchango',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'221763779753',NULL,NULL,0,0,NULL,NULL,2,1,2,1023,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1305,NULL,'Dieudonnée',NULL,'Akoa Akoa',NULL,NULL,NULL,'Scat Urbam',NULL,NULL,NULL,NULL,NULL,'763779753',NULL,NULL,0,0,NULL,NULL,2,1,2,1023,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1306,NULL,'Marie',NULL,'Defo',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'761951638',NULL,NULL,0,0,NULL,NULL,2,1,2,1023,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1307,NULL,'Marie Angelique',NULL,'Defo',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'761951638',NULL,NULL,0,0,NULL,NULL,2,1,2,1023,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1308,NULL,'Megane',NULL,'Takenne',NULL,NULL,NULL,'Ouest Foire',NULL,NULL,NULL,NULL,NULL,'221788214733',NULL,NULL,0,0,NULL,NULL,2,1,2,1023,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1309,NULL,'Prince',NULL,'MBOUNOU',NULL,NULL,NULL,'Scat Urbam',NULL,NULL,NULL,NULL,NULL,'763779753',NULL,NULL,0,0,NULL,NULL,2,1,2,1023,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1310,NULL,'Aulide',NULL,'KOUAME',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1024,NULL,NULL,'2026-05-02 07:57:59',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1311,'','Ghislain','','ONDIA','','','','Fass','','','','','','768162579','','',0,0,NULL,NULL,1,1,2,1024,0,'2026-05-19 21:34:29','2026-05-02 07:58:00',1,1493,NULL,0,'','','',1235),
(1312,NULL,'Khadim',NULL,'LENGOUNGA',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'+221772623120',NULL,NULL,0,0,NULL,NULL,1,1,2,1024,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1313,NULL,'Axelle',NULL,'GBONON',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'786366702',NULL,NULL,0,0,NULL,NULL,2,1,2,1025,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1314,NULL,'Dagbo',NULL,'Yoan',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'784579004',NULL,NULL,6,28,1999,NULL,1,1,2,1025,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1315,NULL,'Jennifer',NULL,'Ossey-pea',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'780180065',NULL,NULL,7,28,1998,NULL,1,1,2,1025,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1316,NULL,'Azi adah',NULL,'NTSAME OBIANG oumarou',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'781671027',NULL,NULL,5,16,2003,NULL,1,1,2,1026,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1317,NULL,'Divine victoire Résignée',NULL,'GARCIA GINE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'778767465',NULL,NULL,6,22,1992,NULL,2,1,2,1026,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1318,NULL,'Eric Steeven',NULL,'OBIANG NDONG',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1026,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1319,NULL,'Aziza Pajy Franchelle',NULL,'PINDA NGUIAS',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'777552900',NULL,NULL,1,13,1999,NULL,2,1,2,1027,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1320,NULL,'Luc Evan\'s',NULL,'SABA',NULL,NULL,NULL,'Sicap Liberté 4',NULL,NULL,NULL,NULL,NULL,'777086972',NULL,NULL,0,0,NULL,NULL,1,1,2,1027,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1321,NULL,'Samyrah Christie',NULL,'OBONE NZUE',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'777966901',NULL,NULL,0,0,NULL,NULL,2,1,2,1027,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1322,NULL,'Baem Brice',NULL,'BAGOA',NULL,NULL,NULL,'Amitié 2',NULL,NULL,NULL,NULL,NULL,'772241860',NULL,NULL,1,4,1999,NULL,2,2,2,1028,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1323,NULL,'Leïla',NULL,'NZENGUE-BANGOYI',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'786072048',NULL,NULL,5,27,2001,NULL,2,1,2,1028,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1324,NULL,'Marcelle Olive',NULL,'BOUSSEYI LOUNDOU',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'786071012',NULL,NULL,1,22,2005,NULL,2,1,2,1028,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1325,NULL,'Bena Veroll Elisabeth',NULL,'GOUAMBA BITSI',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'771939979',NULL,NULL,5,26,2003,NULL,1,1,2,1029,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1326,NULL,'Eliézer',NULL,'GNARO',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'+221772098781',NULL,NULL,0,0,NULL,NULL,1,1,2,1029,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1327,NULL,'GANGA',NULL,'Exaucée',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'+221781572394',NULL,NULL,5,24,2002,NULL,2,1,2,1029,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1328,NULL,'Graciela Mégane',NULL,'Didi Tchoutouo II',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'777619127',NULL,NULL,7,7,2006,NULL,2,1,2,1029,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1329,NULL,'Keren',NULL,'LEKOSSO',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'+221789902350',NULL,NULL,6,19,2007,NULL,1,1,2,1029,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1330,NULL,'Octavie Berenice',NULL,'EKISSI',NULL,NULL,NULL,'Mamelles',NULL,NULL,NULL,NULL,NULL,'+221774918132',NULL,NULL,11,13,2026,NULL,2,1,2,1029,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1331,NULL,'Brigina Pha',NULL,'MENGUE ME NKWELE',NULL,NULL,NULL,'Jet d\'eau',NULL,NULL,NULL,NULL,NULL,'770952469',NULL,NULL,6,5,1998,NULL,2,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1332,NULL,'Dorine',NULL,'INGUIESSI BISSAGOU',NULL,NULL,NULL,'HLM 1',NULL,NULL,NULL,NULL,NULL,'772909180',NULL,NULL,4,17,2000,NULL,2,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1333,NULL,'Fabiola',NULL,'MAGNE TADIE',NULL,NULL,NULL,'Dieuppeul',NULL,NULL,NULL,NULL,NULL,'221784234943',NULL,NULL,10,14,1994,NULL,2,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1334,NULL,'Fabiola',NULL,'Moguem Tachago',NULL,NULL,NULL,'Dieuppeul',NULL,NULL,NULL,NULL,NULL,'774046551',NULL,NULL,0,0,NULL,NULL,2,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1335,NULL,'Loriane Michaëlla',NULL,'NNO ANGO',NULL,NULL,NULL,'Sacré-Cœur 2',NULL,NULL,NULL,NULL,NULL,'772071783',NULL,NULL,10,19,2000,NULL,2,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1336,NULL,'Louis Franck',NULL,'ADEWINOGO',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'221781937159',NULL,NULL,0,0,NULL,NULL,1,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1337,NULL,'Tressy Sydarlia',NULL,'IGNANGA IGNANGA',NULL,NULL,NULL,'HLM 3',NULL,NULL,NULL,NULL,NULL,'787897186',NULL,NULL,5,7,2001,NULL,2,1,2,1030,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1338,NULL,'Britch whynel',NULL,'MBOUANGA',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'778263383',NULL,NULL,0,0,NULL,NULL,1,1,2,1031,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1339,NULL,'Franchnel Médish',NULL,'DJADJI MBOKO',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'774592104',NULL,NULL,4,20,2001,NULL,1,1,2,1031,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1340,NULL,'Iverson Heritier',NULL,'DE-TOPOMONDJO',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'221775924739',NULL,NULL,6,15,2004,NULL,1,1,2,1031,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1341,NULL,'CORNELLY',NULL,'MBOURANGON',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'778736322',NULL,NULL,8,23,1998,NULL,1,1,2,1032,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1342,NULL,'Faith Miracle',NULL,'EBALE',NULL,NULL,NULL,'Ouest Foire',NULL,NULL,NULL,NULL,NULL,'785939126',NULL,NULL,0,0,NULL,NULL,2,1,2,1032,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1343,NULL,'Jean Cléo',NULL,'SEPHA MAISSA',NULL,NULL,NULL,'Ouest Foire',NULL,NULL,NULL,NULL,NULL,'777358637',NULL,NULL,2,25,2001,NULL,1,1,2,1032,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1344,NULL,'PAUL CHRIST BONHEUR',NULL,'TANGA',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'772664019',NULL,NULL,10,5,1999,NULL,1,1,2,1032,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1345,NULL,'Petit Samuel Derry',NULL,'ALLOGO MINKO',NULL,NULL,NULL,'Ouest Foire',NULL,NULL,NULL,NULL,NULL,'+221773094012',NULL,NULL,0,0,NULL,NULL,1,1,2,1032,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1346,NULL,'Shana Leila',NULL,'Andeme Minang',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'781266074',NULL,NULL,0,0,NULL,NULL,2,1,2,1032,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1347,NULL,'Catherine',NULL,'SENGHOR',NULL,NULL,NULL,'Ngor',NULL,NULL,NULL,NULL,NULL,'+221785290061',NULL,NULL,5,18,1999,NULL,2,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1348,NULL,'Guynola Darisca',NULL,'MENZENE MAYOMBO',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'769415338',NULL,NULL,0,0,NULL,NULL,2,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1349,NULL,'Leila Chatare',NULL,'ETALATALA ALAMIGUI',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'707232076',NULL,NULL,11,19,1998,NULL,2,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1350,NULL,'Marie Noël Daba',NULL,'Diouf',NULL,NULL,NULL,'HLM 5',NULL,NULL,NULL,NULL,NULL,'774588709',NULL,NULL,0,0,NULL,NULL,2,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1351,NULL,'Nahomy Senn-wildrine',NULL,'SIMBA OYILIGA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'772509667',NULL,NULL,0,0,NULL,NULL,2,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1352,NULL,'Noura Fatima Helen',NULL,'Dao',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'786095967',NULL,NULL,12,10,2004,NULL,1,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1353,NULL,'Simonea Enola',NULL,'SIMBA ATSAME',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'776143885',NULL,NULL,3,31,2004,NULL,2,1,2,1033,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1354,NULL,'Catherine',NULL,'Diouf',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'778711073',NULL,NULL,6,20,1997,NULL,2,1,2,1034,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1355,NULL,'Monique',NULL,'Ndong',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'765771888',NULL,NULL,12,24,2002,NULL,2,1,2,1034,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1356,NULL,'Rocky Daba',NULL,'Sarr',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'703701317',NULL,NULL,1,30,2003,NULL,2,1,2,1034,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1357,NULL,'Seynabou',NULL,'Sarr',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'96',NULL,NULL,8,4,1999,NULL,1,2,2,1034,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1358,NULL,'Charelle',NULL,'Charelle IGNANGA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1035,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1359,NULL,'Chrisline',NULL,'MOUYAMA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1035,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1360,NULL,'Claudy Esthy',NULL,'BOUITI',NULL,NULL,NULL,'HLM 5',NULL,NULL,NULL,NULL,NULL,'773757257',NULL,NULL,5,15,2005,NULL,1,1,2,1035,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1361,NULL,'Emmanuély Piérrick',NULL,'MONGO',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'777159074',NULL,NULL,0,0,NULL,NULL,1,1,2,1035,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1362,NULL,'Hugues',NULL,'MANFOUMBI',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'784733822',NULL,NULL,12,1,2003,NULL,1,1,2,1035,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1363,NULL,'Pressy',NULL,'OVONO',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1035,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1364,NULL,'Chris Jones',NULL,'Khoufidissa',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1036,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1365,NULL,'Hanniel',NULL,'Coulidiati',NULL,NULL,NULL,'Castors',NULL,NULL,NULL,NULL,NULL,'781773774',NULL,NULL,4,7,1995,NULL,1,1,2,1036,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1366,NULL,'Marie Noëlle',NULL,'Ando',NULL,NULL,NULL,'Castors',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1036,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1367,NULL,'Chris Olsem',NULL,'Matoumona',NULL,NULL,NULL,'Patte d\'Oie',NULL,NULL,NULL,NULL,NULL,'+221771711937',NULL,NULL,0,0,NULL,NULL,1,1,2,1037,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1368,NULL,'Reveli',NULL,'LEPOUPOU',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'777191495',NULL,NULL,8,17,1993,NULL,1,1,2,1037,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1369,NULL,'Christiana',NULL,'Kossonou',NULL,NULL,NULL,'Yoff',NULL,NULL,NULL,NULL,NULL,'773025444',NULL,NULL,0,0,NULL,NULL,2,2,2,1038,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1370,NULL,'Corinne',NULL,'Kossonou',NULL,NULL,NULL,'Yoff',NULL,NULL,NULL,NULL,NULL,'773025444',NULL,NULL,0,0,NULL,NULL,2,1,2,1038,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1371,NULL,'Grâce',NULL,'Lambert',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'785971508',NULL,NULL,0,0,NULL,NULL,2,1,2,1038,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1372,NULL,'Mickael',NULL,'Kossonou',NULL,NULL,NULL,'Yoff',NULL,NULL,NULL,NULL,NULL,'773025444',NULL,NULL,0,0,NULL,NULL,1,1,2,1038,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1373,NULL,'Mickaella',NULL,'Kossonou',NULL,NULL,NULL,'Yoff',NULL,NULL,NULL,NULL,NULL,'773025444',NULL,NULL,0,0,NULL,NULL,2,1,2,1038,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1374,NULL,'Ouattara Idrissa',NULL,'Kossonou',NULL,NULL,NULL,'Yoff',NULL,NULL,NULL,NULL,NULL,'776486345',NULL,NULL,0,0,NULL,NULL,2,2,2,1038,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1375,NULL,'Christophe Henri Assissé',NULL,'BODIAN',NULL,NULL,NULL,'Keur Massar',NULL,NULL,NULL,NULL,NULL,'783004950',NULL,NULL,3,26,1997,NULL,1,1,2,1039,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1376,NULL,'Cliff Childéric',NULL,'ODZÛME ASSA',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'+221783836343',NULL,NULL,5,15,2000,NULL,1,1,2,1040,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1377,NULL,'Colier',NULL,'NA',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'701107949',NULL,NULL,0,0,NULL,NULL,1,1,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1378,NULL,'DAMASSOH',NULL,'Josué',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1379,NULL,'Joe',NULL,'MPEZ TSHIMWANG',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'789648855',NULL,NULL,0,0,NULL,NULL,2,2,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1380,NULL,'Josué',NULL,'DAMASSOH',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'705361887',NULL,NULL,0,0,NULL,NULL,1,1,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1381,NULL,'Martin',NULL,'SUIGABANFMOURI',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'777291237',NULL,NULL,0,0,NULL,NULL,1,1,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1382,NULL,'Olivia',NULL,'NA',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'784792596',NULL,NULL,0,0,NULL,NULL,2,1,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1383,NULL,'Privat',NULL,'SALLA MAKELE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'771610851',NULL,NULL,0,0,NULL,NULL,1,1,2,1041,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1384,NULL,'Corally',NULL,'THOMOS',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'781958812',NULL,NULL,0,0,NULL,NULL,1,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1385,NULL,'David Josué',NULL,'Akiana',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'785305406',NULL,NULL,10,23,2002,NULL,1,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1386,NULL,'Ellie',NULL,'OSSENGUE',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'787582423',NULL,NULL,4,21,2026,NULL,2,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1387,NULL,'Ellie',NULL,'OSSENGUE',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'787582423',NULL,NULL,4,21,2026,NULL,2,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1388,NULL,'GEORDY',NULL,'OSSERE',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'775005372',NULL,NULL,7,27,1999,NULL,1,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1389,NULL,'Henri',NULL,'LINDHAS EPONGHAS',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'+221787107032',NULL,NULL,2,18,2001,NULL,1,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1390,NULL,'Mauricette Leslie',NULL,'NZENGUI',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'781311985',NULL,NULL,9,6,1994,NULL,2,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1391,NULL,'Roy Jofred',NULL,'OSSENGUE',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'784690865',NULL,NULL,6,8,1999,NULL,1,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1392,NULL,'Stevie',NULL,'KOSSINGA',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'777674307',NULL,NULL,0,0,NULL,NULL,2,1,2,1042,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1393,NULL,'Cyr',NULL,'MOASSA',NULL,NULL,NULL,'Jet d\'eau',NULL,NULL,NULL,NULL,NULL,'784238682',NULL,NULL,0,0,NULL,NULL,1,1,2,1043,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1394,NULL,'Rislène karmelia',NULL,'Kitsoro mbombi',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'773816497',NULL,NULL,11,24,2000,NULL,2,1,2,1043,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1395,NULL,'Daniel',NULL,'Tatsoula',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'706199490',NULL,NULL,0,0,NULL,NULL,1,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1396,NULL,'Evodie de Gloria',NULL,'Guelega',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,10,28,2005,NULL,2,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1397,NULL,'JEREMIAS',NULL,'ALU',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1398,NULL,'Jeamira Jeanis',NULL,'Alene Bissoe',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'785423422',NULL,NULL,8,4,2001,NULL,1,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1399,NULL,'Marie',NULL,'BIVEGHE',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,4,15,2026,NULL,2,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1400,NULL,'Miranda Fortune',NULL,'MEIGUIM',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'658459581',NULL,NULL,1,8,2008,NULL,2,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1401,NULL,'Rosairine',NULL,'Faurgie',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1402,NULL,'Victoire Esther',NULL,'Melajio',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'710386553',NULL,NULL,0,0,NULL,NULL,1,1,2,1044,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1403,NULL,'Doriane Anuarite',NULL,'NZAPAOZO SAGBALE',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'781972176',NULL,NULL,3,19,2000,NULL,2,1,2,1045,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1404,NULL,'Horlin, Loveday',NULL,'MOUNGUENGUI-MACKANA',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'773447557',NULL,NULL,3,25,1999,NULL,1,1,2,1045,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1405,NULL,'Juste',NULL,'Boussougou',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1045,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1406,NULL,'KOUAME CHRISTIAN',NULL,'YAO',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'781322863',NULL,NULL,12,17,1995,NULL,1,1,2,1045,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1407,NULL,'Thecle',NULL,'Mariam Djibrine',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'779506078',NULL,NULL,9,24,1999,NULL,2,1,2,1045,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1408,NULL,'Dusty cherel',NULL,'Malonga',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'777182267',NULL,NULL,0,0,NULL,NULL,1,2,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1409,NULL,'Elisabeth Daysilia',NULL,'OBOBE ELLA EPS MALONGA',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'777049533',NULL,NULL,0,0,NULL,NULL,2,2,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1410,NULL,'Junior alfonse',NULL,'Kombila Sita',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'772225294',NULL,NULL,0,0,NULL,NULL,2,1,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1411,NULL,'Orvane Benini',NULL,'Diop',NULL,NULL,NULL,'Fann Résidence',NULL,NULL,NULL,NULL,NULL,'787535357',NULL,NULL,0,0,NULL,NULL,1,1,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1412,NULL,'Princesse kloriane',NULL,'Nguende Vanke',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'785924770',NULL,NULL,0,0,NULL,NULL,2,1,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1413,NULL,'Seth',NULL,'Abbecy Anguilet',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'772706293',NULL,NULL,0,0,NULL,NULL,1,1,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1414,NULL,'Wilma',NULL,'Mboumba',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'764075775',NULL,NULL,0,0,NULL,NULL,2,1,2,1046,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1415,NULL,'E. Doriane',NULL,'Wouamba',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'+221774640204',NULL,NULL,0,0,NULL,NULL,2,1,2,1047,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1416,NULL,'Gade Exauce',NULL,'BIBIS',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'781514707',NULL,NULL,5,31,2001,NULL,2,1,2,1047,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1417,NULL,'Moïse Carmel',NULL,'Fodedo Nguetsa',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'221772323623',NULL,NULL,0,0,NULL,NULL,1,1,2,1047,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1418,NULL,'Syntia',NULL,'Epitaha boulombi',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'212620388990',NULL,NULL,6,2,1997,NULL,2,1,2,1047,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1419,NULL,'Waleska Yoricka',NULL,'MAVOUNGOU',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'787872090',NULL,NULL,0,0,NULL,NULL,2,1,2,1047,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1420,NULL,'Zidane',NULL,'FOFEDO',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'774111665',NULL,NULL,0,0,NULL,NULL,2,1,2,1047,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1421,NULL,'EL-GIBBORD',NULL,'EFOUNDZOLA',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'221784335216',NULL,NULL,0,0,NULL,NULL,1,1,2,1048,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1422,NULL,'ESSI EVODIE',NULL,'KOFFI',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1049,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1423,NULL,'Edem',NULL,'AKPO',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,2,2,1049,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1424,NULL,'KOSI EDEM',NULL,'AKPO',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,2,2,1049,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1425,NULL,'Meheza',NULL,'ABISS',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1049,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1426,NULL,'Ed-Asaph',NULL,'EKOME NDONG',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'781261130',NULL,NULL,1,29,2007,NULL,1,1,2,1050,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1427,NULL,'Jarode',NULL,'Nash',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'776211824',NULL,NULL,0,0,NULL,NULL,2,1,2,1050,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1428,NULL,'Maxwell',NULL,'KASSI MAMADOU',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'221777130872',NULL,NULL,2,29,2004,NULL,1,1,2,1050,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1429,NULL,'Nek Rodolphe',NULL,'Guindogba',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'785399732',NULL,NULL,9,20,2000,NULL,2,1,2,1050,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1430,NULL,'Edylain Marcel',NULL,'NGASSAKI OKOKO',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'221783077268',NULL,NULL,12,9,1999,NULL,1,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1431,NULL,'Emmanuel',NULL,'MOUKILA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'775196354',NULL,NULL,0,0,NULL,NULL,1,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1432,NULL,'Havila',NULL,'CUIEGOUEI',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,4,20,2010,NULL,2,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1433,NULL,'Louis Le Maire',NULL,'LOUSSOLOUMO GONY',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'784391664',NULL,NULL,4,10,2004,NULL,2,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1434,NULL,'Louis Ulrich',NULL,'Tenkeu',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'785852149',NULL,NULL,0,0,NULL,NULL,1,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1435,NULL,'Melia Princia Séraphine',NULL,'NGABIE OPENA',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'784883295',NULL,NULL,9,13,2005,NULL,2,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1436,NULL,'N\'vola Yvonne',NULL,'AKATCHI',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'705845705',NULL,NULL,9,2,2002,NULL,2,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1437,NULL,'Rita leslie',NULL,'CUIEGOUEI',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'774780578',NULL,NULL,0,0,NULL,NULL,2,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1438,NULL,'Smile poup\'s monamour',NULL,'Loemba zassi',NULL,NULL,NULL,'Scat Urbam',NULL,NULL,NULL,NULL,NULL,'777118836',NULL,NULL,2,4,2003,NULL,1,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1439,NULL,'William Bradley',NULL,'Gwes',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'785810718',NULL,NULL,4,6,2005,NULL,1,1,2,1051,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1440,NULL,'Essi',NULL,'NDOSSANI',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,2,2,1052,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1441,NULL,'Eva',NULL,'BOLEGA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'775787622',NULL,NULL,2,22,2001,NULL,2,2,2,1053,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1442,NULL,'Patrick',NULL,'BOLEGA',NULL,NULL,NULL,'Point E',NULL,NULL,NULL,NULL,NULL,'774802736',NULL,NULL,5,6,1994,NULL,1,2,2,1053,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1443,NULL,'Farida Sarah l’adorée',NULL,'Reckoundji',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'771287607',NULL,NULL,2,5,1998,NULL,2,1,2,1054,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1444,NULL,'Lisa',NULL,'OYENGA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1054,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1445,NULL,'Nally Jennifer',NULL,'Taty',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'773910072',NULL,NULL,4,23,1997,NULL,1,1,2,1054,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1446,NULL,'Fernando Stomy',NULL,'LOUDIT',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'765287898',NULL,NULL,0,0,NULL,NULL,1,1,2,1055,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1447,NULL,'Fransline',NULL,'OYOUKOU ITOUA',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1055,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1448,NULL,'Jessy Graziella',NULL,'MOUDIONZE BOUKA',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'777965483',NULL,NULL,0,0,NULL,NULL,2,1,2,1055,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1449,NULL,'Jov Fabri',NULL,'MOUDIONZE',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'781786958',NULL,NULL,0,0,NULL,NULL,1,1,2,1055,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1450,NULL,'Judicaël',NULL,'Bekale EKOME',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'761805881',NULL,NULL,0,0,NULL,NULL,1,1,2,1055,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1451,NULL,'Patrick Nat\'si',NULL,'POATI',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'772083075',NULL,NULL,0,0,NULL,NULL,1,1,2,1055,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1452,NULL,'Flora Emile',NULL,'MBELANGANI',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'784830165',NULL,NULL,7,13,2001,NULL,2,1,2,1056,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1453,NULL,'Florence Leïla Ossouka',NULL,'ANGUILET WALKER',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'776615148',NULL,NULL,0,0,NULL,NULL,2,1,2,1056,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1454,NULL,'Marisa Syndy',NULL,'DOUMA BISSAKA',NULL,NULL,NULL,'Ouakam',NULL,NULL,NULL,NULL,NULL,'776177609',NULL,NULL,0,0,NULL,NULL,1,1,2,1056,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1455,NULL,'Frèse',NULL,'YABOUI',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'773978263',NULL,NULL,8,8,1998,NULL,2,1,2,1057,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1456,NULL,'Loriz',NULL,'MITATI',NULL,NULL,NULL,'Ngor',NULL,NULL,NULL,NULL,NULL,'771878779',NULL,NULL,0,0,NULL,NULL,1,1,2,1057,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1457,NULL,'Sephora',NULL,'NA',NULL,NULL,NULL,'Grand Dakar',NULL,NULL,NULL,NULL,NULL,'789208109',NULL,NULL,0,0,NULL,NULL,2,1,2,1057,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1458,NULL,'JOYCE ROYALE',NULL,'MAKEU',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'771170212',NULL,NULL,0,0,NULL,NULL,2,1,2,1058,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1459,NULL,'Jeanny Gloria',NULL,'NGONGANG KEPMEGNI',NULL,NULL,NULL,'Médina',NULL,NULL,NULL,NULL,NULL,'785967246759072395',NULL,NULL,6,28,2000,NULL,2,1,2,1058,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1460,NULL,'Jessica',NULL,'NGATOUA',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'774567310',NULL,NULL,0,0,NULL,NULL,2,1,2,1058,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1461,NULL,'Santchi Mylène',NULL,'Matang',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,9,9,2004,NULL,2,1,2,1058,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1462,NULL,'Jean-Prudence II Gadiel',NULL,'MVE ELLA',NULL,NULL,NULL,'Mermoz',NULL,NULL,NULL,NULL,NULL,'783882160',NULL,NULL,7,25,2002,NULL,1,1,2,1059,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1463,NULL,'Oceane Stany Hercylia',NULL,'NYNGONE NZIENGUI',NULL,NULL,NULL,'Niarry Tally',NULL,NULL,NULL,NULL,NULL,'771973456',NULL,NULL,9,4,2006,NULL,2,1,2,1059,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1464,NULL,'Jennifer Fara',NULL,'AWOUNFACK',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'772250469',NULL,NULL,6,5,2004,NULL,2,1,2,1060,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1465,NULL,'Ravel Patrick',NULL,'Yoka Dimi',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'777536627',NULL,NULL,0,0,NULL,NULL,1,1,2,1060,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1466,NULL,'Joana Juliette',NULL,'NGUEMA',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'783823814',NULL,NULL,3,29,1998,NULL,2,1,2,1061,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1467,NULL,'ORNY MARCIA',NULL,'NGALENDE NDOUO',NULL,NULL,NULL,'Gueule Tapée',NULL,NULL,NULL,NULL,NULL,'769082056',NULL,NULL,5,11,2001,NULL,2,1,2,1061,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1468,NULL,'Joséphine',NULL,'Diouf',NULL,NULL,NULL,'Dieuppeul',NULL,NULL,NULL,NULL,NULL,'785324009',NULL,NULL,0,0,NULL,NULL,2,1,2,1062,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1469,NULL,'Julien Dercy',NULL,'BOUBENGA-NZAHOU',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'778152166',NULL,NULL,7,5,1996,NULL,1,1,2,1063,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1470,NULL,'Silnelle-Brufene-Shilie',NULL,'ITCHIEMBOU BOUSSOUGOU',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'+221775070689',NULL,NULL,4,21,2021,NULL,2,1,2,1063,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1471,NULL,'Sophonie Jairus',NULL,'OMBOUNGOU-TOMBI',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'778485040',NULL,NULL,0,0,NULL,NULL,1,1,2,1063,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1472,NULL,'Karene Idricia',NULL,'MADADA',NULL,NULL,NULL,'Sicap Liberté 6',NULL,NULL,NULL,NULL,NULL,'774800142',NULL,NULL,3,7,2002,NULL,2,1,2,1064,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1473,NULL,'Meildna Xaviéra',NULL,'MENGUE ME ZUE',NULL,NULL,NULL,'Sicap Liberté 2',NULL,NULL,NULL,NULL,NULL,'784715634',NULL,NULL,8,19,2000,NULL,2,1,2,1064,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1474,NULL,'Nélissa Gaëlle',NULL,'BICHUI BI NDONG',NULL,NULL,NULL,'Sicap Liberté 2',NULL,NULL,NULL,NULL,NULL,'777970246',NULL,NULL,5,8,1997,NULL,2,1,2,1064,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1475,NULL,'Ruth Nora',NULL,'Banguid',NULL,NULL,NULL,'Sacré-Cœur 3',NULL,NULL,NULL,NULL,NULL,'776785015',NULL,NULL,12,20,2001,NULL,2,1,2,1064,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1476,NULL,'Kowen',NULL,'Zarambaud b’niyat',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'787221132',NULL,NULL,10,24,2004,NULL,1,1,2,1065,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1477,NULL,'MBOKO',NULL,'MVOULOU',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1065,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1478,NULL,'Tyty Darcy Ivann',NULL,'MVOULOU MBOKO',NULL,NULL,NULL,'Fass',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,1,1,2,1065,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1479,NULL,'Marie-Noëlle',NULL,'MANZILA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1066,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1480,NULL,'Maxime',NULL,'NAKIZENON',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,2,2,1067,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1481,NULL,'Melissa Patinie',NULL,'TUEGUEM',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'767230030',NULL,NULL,0,0,NULL,NULL,2,1,2,1068,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1482,NULL,'Nathalie',NULL,'DIOUF',NULL,NULL,NULL,'Cité Lamy',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1068,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1483,NULL,'Stephanie',NULL,'GNONLONFOUN',NULL,NULL,NULL,'Parcelles Assainies',NULL,NULL,NULL,NULL,NULL,'+221780161626',NULL,NULL,0,0,NULL,NULL,2,1,2,1068,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1484,NULL,'Véronique',NULL,'KAMPAL',NULL,NULL,NULL,'Mbour 1',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,0,0,NULL,NULL,2,1,2,1068,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1485,NULL,'Prince Farley',NULL,'Nzenguet Mouanga',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'773447092',NULL,NULL,0,0,NULL,NULL,1,1,2,1069,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1486,NULL,'TCHICAYA',NULL,'Belcera',NULL,NULL,NULL,'Dieuppeul',NULL,NULL,NULL,NULL,NULL,'781430670',NULL,NULL,0,0,NULL,NULL,2,1,2,1069,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1487,NULL,'Rachel',NULL,'Mouloungui',NULL,NULL,NULL,'Ouest Foire',NULL,NULL,NULL,NULL,NULL,'772780708',NULL,NULL,0,0,NULL,NULL,1,1,2,1070,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1488,NULL,'Richelle',NULL,'NDJANKO MBIEDA',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,'771200288',NULL,NULL,4,30,1997,NULL,2,1,2,1071,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1489,NULL,'VIRGINIE',NULL,'DEDE DADIE',NULL,NULL,NULL,'Colobane',NULL,NULL,NULL,NULL,NULL,'785459206',NULL,NULL,12,10,1997,NULL,2,1,2,1071,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1490,NULL,'ÉDOUARD SINGANE ADIOUBE',NULL,'DIATTA',NULL,NULL,NULL,'Grand Yoff',NULL,NULL,NULL,NULL,NULL,'776551375',NULL,NULL,6,8,1997,NULL,2,1,2,1072,NULL,NULL,'2026-05-02 07:58:00',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1491,NULL,'Admin',NULL,'Système',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin@churchcrm.local',NULL,0,0,NULL,NULL,1,0,0,1073,NULL,NULL,'2026-05-02 07:58:35',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1492,NULL,'Admin',NULL,'Systeme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'admin@churchcrm',NULL,0,0,NULL,NULL,1,0,0,1074,NULL,NULL,'2026-05-02 08:04:33',1,0,NULL,0,NULL,NULL,NULL,NULL),
(1493,NULL,'Ghislain',NULL,'Ondia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ghislain@localhost',NULL,0,0,NULL,NULL,0,0,0,0,NULL,NULL,'2026-05-19 21:27:27',1,0,NULL,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `person_per` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pledge_plg`
--

DROP TABLE IF EXISTS `pledge_plg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pledge_plg` (
  `plg_plgID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `plg_FamID` mediumint(9) DEFAULT NULL,
  `plg_FYID` mediumint(9) DEFAULT NULL,
  `plg_date` date DEFAULT NULL,
  `plg_amount` decimal(8,2) DEFAULT NULL,
  `plg_schedule` enum('Weekly','Monthly','Quarterly','Once','Other') DEFAULT NULL,
  `plg_method` enum('CREDITCARD','CHECK','CASH','BANKDRAFT') DEFAULT NULL,
  `plg_comment` text DEFAULT NULL,
  `plg_DateLastEdited` date NOT NULL DEFAULT '2016-01-01',
  `plg_EditedBy` mediumint(9) NOT NULL DEFAULT 0,
  `plg_PledgeOrPayment` enum('Pledge','Payment') NOT NULL DEFAULT 'Pledge',
  `plg_fundID` tinyint(3) unsigned DEFAULT NULL,
  `plg_depID` mediumint(9) unsigned DEFAULT NULL,
  `plg_CheckNo` bigint(16) unsigned DEFAULT NULL,
  `plg_Problem` tinyint(1) DEFAULT NULL,
  `plg_scanString` text DEFAULT NULL,
  `plg_aut_ID` mediumint(9) NOT NULL DEFAULT 0,
  `plg_aut_Cleared` tinyint(1) NOT NULL DEFAULT 0,
  `plg_aut_ResultID` mediumint(9) NOT NULL DEFAULT 0,
  `plg_NonDeductible` decimal(8,2) NOT NULL,
  `plg_GroupKey` varchar(64) NOT NULL,
  PRIMARY KEY (`plg_plgID`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pledge_plg`
--

LOCK TABLES `pledge_plg` WRITE;
/*!40000 ALTER TABLE `pledge_plg` DISABLE KEYS */;
INSERT INTO `pledge_plg` VALUES
(1,13,22,'2018-03-04',30.00,'Once','CASH','','2018-03-04',1,'Payment',1,1,NULL,NULL,'',0,0,0,0.00,'cash|0|13|1|2018-03-04'),
(2,13,22,'2018-03-04',20.00,'Once','CASH','','2018-03-04',1,'Payment',2,1,NULL,NULL,'',0,0,0,0.00,'cash|0|13|1|2018-03-04'),
(3,13,22,'2018-03-04',100.00,'Once','CASH','','2018-03-04',1,'Payment',3,1,NULL,NULL,'',0,0,0,0.00,'cash|0|13|1|2018-03-04'),
(4,14,22,'2018-03-04',100.00,'Once','CHECK','','2018-03-04',1,'Payment',1,1,127,NULL,'',0,0,0,0.00,'127|0|14|1|2018-03-04'),
(5,20,22,'2018-03-04',500.00,'Once','CHECK','','2018-03-04',1,'Payment',1,2,100,NULL,'',0,0,0,0.00,'100|0|20|1|2018-03-04'),
(6,20,22,'2018-03-04',100.00,'Once','CHECK','','2018-03-04',1,'Payment',2,2,100,NULL,'',0,0,0,0.00,'100|0|20|1|2018-03-04'),
(7,20,22,'2018-03-04',100.00,'Once','CHECK','','2018-03-04',1,'Payment',3,2,100,NULL,'',0,0,0,0.00,'100|0|20|1|2018-03-04'),
(8,20,22,'2018-03-04',25.00,'Once','CHECK','','2018-03-04',1,'Payment',1,3,5532,NULL,'',0,0,0,0.00,'5532|0|20|1|2018-03-04'),
(9,20,22,'2018-03-04',25.00,'Once','CHECK','','2018-03-04',1,'Payment',2,3,5532,NULL,'',0,0,0,0.00,'5532|0|20|1|2018-03-04'),
(10,20,22,'2018-03-04',25.00,'Once','CHECK','','2018-03-04',1,'Payment',3,3,5532,NULL,'',0,0,0,0.00,'5532|0|20|1|2018-03-04'),
(11,1,22,'2018-03-04',300.00,'Once','CHECK','','2018-03-04',1,'Payment',1,3,773,NULL,'',0,0,0,0.00,'773|0|1|1|2018-03-04'),
(12,1,22,'2018-03-04',26.00,'Once','CHECK','','2018-03-04',1,'Payment',2,3,773,NULL,'',0,0,0,0.00,'773|0|1|1|2018-03-04'),
(13,1,22,'2018-03-04',20.00,'Once','CHECK','','2018-03-04',1,'Payment',3,3,773,NULL,'',0,0,0,0.00,'773|0|1|1|2018-03-04'),
(14,9,22,'2018-03-04',50.00,'Once','CASH','','2018-03-04',1,'Payment',1,4,NULL,NULL,'',0,0,0,0.00,'cash|0|9|1|2018-03-04'),
(15,6,22,'2018-03-04',100.00,'Once','CASH','','2018-03-04',1,'Payment',1,5,NULL,NULL,'',0,0,0,0.00,'cash|0|6|1|2018-03-04'),
(16,6,22,'2018-03-04',20.00,'Once','CASH','','2018-03-04',1,'Payment',3,5,NULL,NULL,'',0,0,0,0.00,'cash|0|6|1|2018-03-04'),
(17,10,22,'2018-03-04',90.00,'Once','CASH','','2018-03-04',1,'Payment',1,5,NULL,NULL,'',0,0,0,0.00,'cash|0|10|1|2018-03-04'),
(18,10,22,'2018-03-04',140.00,'Once','CASH','','2018-03-04',1,'Payment',2,5,NULL,NULL,'',0,0,0,0.00,'cash|0|10|1|2018-03-04'),
(19,10,22,'2018-03-04',95.00,'Once','CASH','','2018-03-04',1,'Payment',3,5,NULL,NULL,'',0,0,0,0.00,'cash|0|10|1|2018-03-04'),
(20,9,23,'2019-09-19',11.00,'Quarterly','CASH','1fasdfasd','2019-09-09',1,'Pledge',1,0,NULL,NULL,'',0,0,0,0.00,'cash|0|9|1|2019-09-19'),
(21,9,23,'2019-09-19',333.00,'Quarterly','CASH','3333','2019-09-09',1,'Pledge',2,0,NULL,NULL,'',0,0,0,0.00,'cash|0|9|1|2019-09-19'),
(22,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|0|0|1|2021-04-25'),
(23,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|1|0|1|2021-04-25'),
(24,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|2|0|1|2021-04-25'),
(25,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|3|0|1|2021-04-25'),
(26,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|4|0|1|2021-04-25'),
(27,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|5|0|1|2021-04-25'),
(28,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|6|0|1|2021-04-25'),
(29,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|7|0|1|2021-04-25'),
(30,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|8|0|1|2021-04-25'),
(31,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|9|0|1|2021-04-25'),
(32,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|10|0|1|2021-04-25'),
(33,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|11|0|1|2021-04-25'),
(34,0,25,'2021-04-25',1000.00,'Once','CHECK','','2021-04-25',1,'Payment',1,5,111,NULL,'',0,0,0,0.00,'111|12|0|1|2021-04-25');
/*!40000 ALTER TABLE `pledge_plg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property_pro`
--

DROP TABLE IF EXISTS `property_pro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `property_pro` (
  `pro_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `pro_Class` varchar(10) NOT NULL DEFAULT '',
  `pro_prt_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `pro_Name` varchar(200) NOT NULL DEFAULT '0',
  `pro_Description` text NOT NULL,
  `pro_Prompt` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`pro_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property_pro`
--

LOCK TABLES `property_pro` WRITE;
/*!40000 ALTER TABLE `property_pro` DISABLE KEYS */;
INSERT INTO `property_pro` VALUES
(1,'p',1,'Disabled','has a disability.','What is the nature of the disability?'),
(2,'f',2,'Single Parent','is a single-parent household.',''),
(3,'g',3,'Youth','is youth-oriented.',''),
(4,'g',3,'Scouts','',''),
(5,'f',2,'Test','Who','What do you want'),
(6,'p',1,'Test','Who','What do you want'),
(7,'f',2,'Test','Who','What do you want'),
(8,'p',1,'Test','Who','What do you want'),
(9,'f',2,'Test','Who','What do you want'),
(10,'p',1,'Test','Who','What do you want'),
(11,'f',2,'Test','Who','What do you want'),
(12,'p',1,'Test','Who','What do you want'),
(13,'f',2,'Test','Who','What do you want'),
(14,'p',1,'Test','Who','What do you want'),
(15,'f',2,'Test','Who','What do you want'),
(16,'p',1,'Test','Who','What do you want'),
(17,'f',2,'Test','Who','What do you want'),
(18,'p',1,'Test','Who','What do you want'),
(19,'f',2,'Test','Who','What do you want'),
(20,'p',1,'Test','Who','What do you want'),
(21,'f',2,'Test','Who','What do you want'),
(22,'p',1,'Test','Who','What do you want'),
(23,'f',2,'Test','Who','What do you want'),
(24,'p',1,'Test','Who','What do you want'),
(25,'f',2,'Test','Who','What do you want'),
(26,'p',1,'Test','Who','What do you want'),
(27,'f',2,'Test','Who','What do you want'),
(28,'p',1,'Test','Who','What do you want'),
(29,'f',2,'Test','Who','What do you want'),
(30,'p',1,'Test','Who','What do you want');
/*!40000 ALTER TABLE `property_pro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `propertytype_prt`
--

DROP TABLE IF EXISTS `propertytype_prt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `propertytype_prt` (
  `prt_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `prt_Class` varchar(10) NOT NULL DEFAULT '',
  `prt_Name` varchar(50) NOT NULL DEFAULT '',
  `prt_Description` text NOT NULL,
  PRIMARY KEY (`prt_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `propertytype_prt`
--

LOCK TABLES `propertytype_prt` WRITE;
/*!40000 ALTER TABLE `propertytype_prt` DISABLE KEYS */;
INSERT INTO `propertytype_prt` VALUES
(1,'p','General','General Person Properties'),
(2,'f','General','General Family Properties'),
(3,'g','General','General Group Properties');
/*!40000 ALTER TABLE `propertytype_prt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `query_qry`
--

DROP TABLE IF EXISTS `query_qry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `query_qry` (
  `qry_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `qry_SQL` text NOT NULL,
  `qry_Name` varchar(255) NOT NULL DEFAULT '',
  `qry_Description` text NOT NULL,
  `qry_Count` tinyint(1) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`qry_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=202 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `query_qry`
--

LOCK TABLES `query_qry` WRITE;
/*!40000 ALTER TABLE `query_qry` DISABLE KEYS */;
INSERT INTO `query_qry` VALUES
(9,'SELECT \r\nper_ID as AddToCart, \r\nCONCAT(per_FirstName,\' \',per_LastName) AS Name, \r\nCONCAT(r2p_Value,\' \') AS Value\r\nFROM person_per,record2property_r2p\r\nWHERE per_ID = r2p_record_ID\r\nAND r2p_pro_ID = ~PropertyID~\r\nORDER BY per_LastName','Person by Property','Returns person records which are assigned the given property.',1),
(18,'SELECT per_ID as AddToCart, per_BirthDay as Day, CONCAT(per_FirstName,\' \',per_LastName) AS Name FROM person_per WHERE per_cls_ID=~percls~ AND per_BirthMonth=~birthmonth~ ORDER BY per_BirthDay','Birthdays','People with birthdays in a particular month',0),
(21,'SELECT per_ID as AddToCart, CONCAT(\'<a href=/people/view/\',per_ID,\'>\',per_FirstName,\' \',per_LastName,\'</a>\') AS Name FROM person_per LEFT JOIN person2group2role_p2g2r ON per_id = p2g2r_per_ID WHERE p2g2r_grp_ID=~group~ ORDER BY per_LastName','Registered students','Find Registered students',1),
(22,'SELECT per_ID as AddToCart, DAYOFMONTH(per_MembershipDate) as Day, per_MembershipDate AS DATE, CONCAT(per_FirstName,\' \',per_LastName) AS Name FROM person_per WHERE per_cls_ID=1 AND MONTH(per_MembershipDate)=~membermonth~ ORDER BY per_MembershipDate','Membership anniversaries','Members who joined in a particular month',0),
(25,'SELECT per_ID as AddToCart, CONCAT(\'<a href=/people/view/\',per_ID,\'>\',per_FirstName,\' \',per_LastName,\'</a>\') AS Name FROM person_per LEFT JOIN person2volunteeropp_p2vo ON per_id = p2vo_per_ID WHERE p2vo_vol_ID = ~volopp~ ORDER BY per_LastName','Volunteers','Find volunteers for a particular opportunity',1),
(26,'SELECT per_ID as AddToCart, CONCAT(per_FirstName,\' \',per_LastName) AS Name FROM person_per WHERE DATE_SUB(NOW(),INTERVAL ~friendmonths~ MONTH)<per_FriendDate ORDER BY per_MembershipDate','Recent friends','Friends who signed up in previous months',0),
(28,'SELECT fam_Name, a.plg_amount as PlgFY1, b.plg_amount as PlgFY2 from family_fam left join pledge_plg a on a.plg_famID = fam_ID and a.plg_FYID=~fyid1~ and a.plg_PledgeOrPayment=\'Pledge\' left join pledge_plg b on b.plg_famID = fam_ID and b.plg_FYID=~fyid2~ and b.plg_PledgeOrPayment=\'Pledge\' order by fam_Name','Pledge comparison','Compare pledges between two fiscal years',1),
(30,'SELECT per_ID as AddToCart, CONCAT(per_FirstName,\' \',per_LastName) AS Name, fam_address1, fam_city, fam_state, fam_zip FROM person_per join family_fam on per_fam_id=fam_id where per_fmr_id<>3 and per_fam_id in (select fam_id from family_fam inner join pledge_plg a on a.plg_famID=fam_ID and a.plg_FYID=~fyid1~ and a.plg_amount>0) and per_fam_id not in (select fam_id from family_fam inner join pledge_plg b on b.plg_famID=fam_ID and b.plg_FYID=~fyid2~ and b.plg_amount>0)','Missing pledges','Find people who pledged one year but not another',1),
(31,'select per_ID as AddToCart, per_FirstName, per_LastName, per_email from person_per, autopayment_aut where aut_famID=per_fam_ID and aut_CreditCard!=\"\" and per_email!=\"\" and (per_fmr_ID=1 or per_fmr_ID=2 or per_cls_ID=1)','Credit Card People','People who are configured to pay by credit card.',0),
(32,'SELECT fam_Name, fam_Envelope, b.fun_Name as Fund_Name, a.plg_amount as Pledge from family_fam left join pledge_plg a on a.plg_famID = fam_ID and a.plg_FYID=~fyid~ and a.plg_PledgeOrPayment=\'Pledge\' and a.plg_amount>0 join donationfund_fun b on b.fun_ID = a.plg_fundID order by fam_Name, a.plg_fundID','Family Pledge by Fiscal Year','Pledge summary by family name for each fund for the selected fiscal year',1),
(100,'SELECT a.per_ID as AddToCart, CONCAT(\'<a href=/people/view/\',a.per_ID,\'>\',a.per_FirstName,\' \',a.per_LastName,\'</a>\') AS Name FROM person_per AS a LEFT JOIN person2volunteeropp_p2vo p2v1 ON (a.per_id = p2v1.p2vo_per_ID AND p2v1.p2vo_vol_ID = ~volopp1~) LEFT JOIN person2volunteeropp_p2vo p2v2 ON (a.per_id = p2v2.p2vo_per_ID AND p2v2.p2vo_vol_ID = ~volopp2~) WHERE p2v1.p2vo_per_ID=p2v2.p2vo_per_ID ORDER BY per_LastName','Volunteers','Find volunteers for who match two specific opportunity codes',1),
(200,'SELECT a.per_ID as AddToCart, CONCAT(\'<a href=/people/view/\',a.per_ID,\'>\',a.per_FirstName,\' \',a.per_LastName,\'</a>\') AS Name FROM person_per AS a LEFT JOIN person_custom pc ON a.per_id = pc.per_ID WHERE pc.~custom~=\'~value~\' ORDER BY per_LastName','CustomSearch','Find people with a custom field value',1);
/*!40000 ALTER TABLE `query_qry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queryparameteroptions_qpo`
--

DROP TABLE IF EXISTS `queryparameteroptions_qpo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `queryparameteroptions_qpo` (
  `qpo_ID` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `qpo_qrp_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `qpo_Display` varchar(50) NOT NULL DEFAULT '',
  `qpo_Value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`qpo_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queryparameteroptions_qpo`
--

LOCK TABLES `queryparameteroptions_qpo` WRITE;
/*!40000 ALTER TABLE `queryparameteroptions_qpo` DISABLE KEYS */;
INSERT INTO `queryparameteroptions_qpo` VALUES
(1,4,'Male','1'),
(2,4,'Female','2'),
(3,6,'Male','1'),
(4,6,'Female','2'),
(5,15,'Name','CONCAT(COALESCE(`per_FirstName`,\'),COALESCE(`per_MiddleName`,\'),COALESCE(`per_LastName`,\'))'),
(6,15,'Zip Code','fam_Zip'),
(7,15,'State','fam_State'),
(8,15,'City','fam_City'),
(9,15,'Home Phone','per_HomePhone'),
(10,27,'2012/2013','17'),
(11,27,'2013/2014','18'),
(12,27,'2014/2015','19'),
(13,27,'2015/2016','20'),
(14,28,'2012/2013','17'),
(15,28,'2013/2014','18'),
(16,28,'2014/2015','19'),
(17,28,'2015/2016','20'),
(18,30,'2012/2013','17'),
(19,30,'2013/2014','18'),
(20,30,'2014/2015','19'),
(21,30,'2015/2016','20'),
(22,31,'2012/2013','17'),
(23,31,'2013/2014','18'),
(24,31,'2014/2015','19'),
(25,31,'2015/2016','20'),
(26,15,'Email','per_Email'),
(27,15,'WorkEmail','per_WorkEmail'),
(28,32,'2012/2013','17'),
(29,32,'2013/2014','18'),
(30,32,'2014/2015','19'),
(31,32,'2015/2016','20'),
(32,33,'Member','1'),
(33,33,'Regular Attender','2'),
(34,33,'Guest','3'),
(35,33,'Non-Attender','4'),
(36,33,'Non-Attender (staff)','5'),
(37,28,'2016/2017','21'),
(38,28,'2017/2018','22'),
(39,28,'2018/2019','23'),
(40,28,'2019/2020','24'),
(41,28,'2020/2021','25'),
(42,28,'2021/2022','26'),
(43,28,'2022/2023','27'),
(44,30,'2016/2017','21'),
(45,30,'2017/2018','22'),
(46,30,'2018/2019','23'),
(47,30,'2019/2020','24'),
(48,30,'2020/2021','25'),
(49,30,'2021/2022','26'),
(50,30,'2022/2023','27'),
(51,31,'2016/2017','21'),
(52,31,'2017/2018','22'),
(53,31,'2018/2019','23'),
(54,31,'2019/2020','24'),
(55,31,'2020/2021','25'),
(56,31,'2021/2022','26'),
(57,31,'2022/2023','27'),
(58,32,'2016/2017','21'),
(59,32,'2017/2018','22'),
(60,32,'2018/2019','23'),
(61,32,'2019/2020','24'),
(62,32,'2020/2021','25'),
(63,32,'2021/2022','26'),
(64,32,'2022/2023','27');
/*!40000 ALTER TABLE `queryparameteroptions_qpo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queryparameters_qrp`
--

DROP TABLE IF EXISTS `queryparameters_qrp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `queryparameters_qrp` (
  `qrp_ID` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `qrp_qry_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `qrp_Type` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `qrp_OptionSQL` text DEFAULT NULL,
  `qrp_Name` varchar(25) DEFAULT NULL,
  `qrp_Description` text DEFAULT NULL,
  `qrp_Alias` varchar(25) DEFAULT NULL,
  `qrp_Default` varchar(25) DEFAULT NULL,
  `qrp_Required` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `qrp_InputBoxSize` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `qrp_Validation` varchar(5) NOT NULL DEFAULT '',
  `qrp_NumericMax` int(11) DEFAULT NULL,
  `qrp_NumericMin` int(11) DEFAULT NULL,
  `qrp_AlphaMinLength` int(11) DEFAULT NULL,
  `qrp_AlphaMaxLength` int(11) DEFAULT NULL,
  PRIMARY KEY (`qrp_ID`),
  KEY `qrp_qry_ID` (`qrp_qry_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=203 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queryparameters_qrp`
--

LOCK TABLES `queryparameters_qrp` WRITE;
/*!40000 ALTER TABLE `queryparameters_qrp` DISABLE KEYS */;
INSERT INTO `queryparameters_qrp` VALUES
(1,4,0,NULL,'Minimum Age','The minimum age for which you want records returned.','min','0',0,5,'n',120,0,NULL,NULL),
(2,4,0,NULL,'Maximum Age','The maximum age for which you want records returned.','max','120',1,5,'n',120,0,NULL,NULL),
(4,6,1,'','Gender','The desired gender to search the database for.','gender','1',1,0,'',0,0,0,0),
(5,7,2,'SELECT lst_OptionID as Value, lst_OptionName as Display FROM list_lst WHERE lst_ID=2 ORDER BY lst_OptionSequence','Family Role','Select the desired family role.','role','1',0,0,'',0,0,0,0),
(6,7,1,'','Gender','The gender for which you would like records returned.','gender','1',1,0,'',0,0,0,0),
(8,9,2,'SELECT pro_ID AS Value, pro_Name as Display \r\nFROM property_pro\r\nWHERE pro_Class= \'p\' \r\nORDER BY pro_Name ','Property','The property for which you would like person records returned.','PropertyID','0',1,0,'',0,0,0,0),
(9,10,2,'SELECT distinct don_date as Value, don_date as Display FROM donations_don ORDER BY don_date ASC','Beginning Date','Please select the beginning date to calculate total contributions for each member (i.e. YYYY-MM-DD). NOTE: You can only choose dates that contain donations.','startdate','1',1,0,'0',0,0,0,0),
(10,10,2,'SELECT distinct don_date as Value, don_date as Display FROM donations_don\r\nORDER BY don_date DESC','Ending Date','Please enter the last date to calculate total contributions for each member (i.e. YYYY-MM-DD).','enddate','1',1,0,'',0,0,0,0),
(14,15,0,'','Search','Enter any part of the following: Name, City, State, Zip, Home Phone, Email, or Work Email.','searchstring','',1,0,'',0,0,0,0),
(15,15,1,'','Field','Select field to search for.','searchwhat','1',1,0,'',0,0,0,0),
(16,11,2,'SELECT distinct don_date as Value, don_date as Display FROM donations_don ORDER BY don_date ASC','Beginning Date','Please select the beginning date to calculate total contributions for each member (i.e. YYYY-MM-DD). NOTE: You can only choose dates that contain donations.','startdate','1',1,0,'0',0,0,0,0),
(17,11,2,'SELECT distinct don_date as Value, don_date as Display FROM donations_don\r\nORDER BY don_date DESC','Ending Date','Please enter the last date to calculate total contributions for each member (i.e. YYYY-MM-DD).','enddate','1',1,0,'',0,0,0,0),
(18,18,0,'','Month','The birthday month for which you would like records returned.','birthmonth','1',1,0,'',12,1,1,2),
(19,19,2,'SELECT grp_ID AS Value, grp_Name AS Display FROM group_grp ORDER BY grp_Type','Class','The sunday school class for which you would like records returned.','group','1',1,0,'',12,1,1,2),
(20,20,2,'SELECT grp_ID AS Value, grp_Name AS Display FROM group_grp ORDER BY grp_Type','Class','The sunday school class for which you would like records returned.','group','1',1,0,'',12,1,1,2),
(21,21,2,'SELECT grp_ID AS Value, grp_Name AS Display FROM group_grp ORDER BY grp_Type','Registered students','Group of registered students','group','1',1,0,'',12,1,1,2),
(22,22,0,'','Month','The membership anniversary month for which you would like records returned.','membermonth','1',1,0,'',12,1,1,2),
(25,25,2,'SELECT vol_ID AS Value, vol_Name AS Display FROM volunteeropportunity_vol ORDER BY vol_Name','Volunteer opportunities','Choose a volunteer opportunity','volopp','1',1,0,'',12,1,1,2),
(26,26,0,'','Months','Number of months since becoming a friend','friendmonths','1',1,0,'',24,1,1,2),
(27,28,1,'','First Fiscal Year','First fiscal year for comparison','fyid1','9',1,0,'',12,9,0,0),
(28,28,1,'','Second Fiscal Year','Second fiscal year for comparison','fyid2','9',1,0,'',12,9,0,0),
(30,30,1,'','First Fiscal Year','Pledged this year','fyid1','9',1,0,'',12,9,0,0),
(31,30,1,'','Second Fiscal Year','but not this year','fyid2','9',1,0,'',12,9,0,0),
(32,32,1,'','Fiscal Year','Fiscal Year.','fyid','9',1,0,'',12,9,0,0),
(33,18,1,'','Classification','Member, Regular Attender, etc.','percls','1',1,0,'',12,1,1,2),
(100,100,2,'SELECT vol_ID AS Value, vol_Name AS Display FROM volunteeropportunity_vol ORDER BY vol_Name','Volunteer opportunities','First volunteer opportunity choice','volopp1','1',1,0,'',12,1,1,2),
(101,100,2,'SELECT vol_ID AS Value, vol_Name AS Display FROM volunteeropportunity_vol ORDER BY vol_Name','Volunteer opportunities','Second volunteer opportunity choice','volopp2','1',1,0,'',12,1,1,2),
(200,200,2,'SELECT custom_field as Value, custom_Name as Display FROM person_custom_master','Custom field','Choose customer person field','custom','1',0,0,'',0,0,0,0),
(201,200,0,'','Field value','Match custom field to this value','value','1',0,0,'',0,0,0,0);
/*!40000 ALTER TABLE `queryparameters_qrp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record2property_r2p`
--

DROP TABLE IF EXISTS `record2property_r2p`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `record2property_r2p` (
  `r2p_pro_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `r2p_record_ID` mediumint(8) unsigned NOT NULL DEFAULT 0,
  `r2p_Value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record2property_r2p`
--

LOCK TABLES `record2property_r2p` WRITE;
/*!40000 ALTER TABLE `record2property_r2p` DISABLE KEYS */;
INSERT INTO `record2property_r2p` VALUES
(4,7,''),
(4,8,''),
(1,59,'N/A'),
(1,114,'N/A'),
(1,123,'N/A'),
(1,162,'N/A'),
(1,169,'N/A'),
(1,178,'N/A'),
(1,187,'N/A'),
(1,196,'N/A'),
(1,205,'N/A'),
(1,212,'N/A'),
(1,221,'N/A'),
(1,228,'N/A');
/*!40000 ALTER TABLE `record2property_r2p` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result_res`
--

DROP TABLE IF EXISTS `result_res`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `result_res` (
  `res_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `res_echotype1` text NOT NULL,
  `res_echotype2` text NOT NULL,
  `res_echotype3` text NOT NULL,
  `res_authorization` text NOT NULL,
  `res_order_number` text NOT NULL,
  `res_reference` text NOT NULL,
  `res_status` text NOT NULL,
  `res_avs_result` text NOT NULL,
  `res_security_result` text NOT NULL,
  `res_mac` text NOT NULL,
  `res_decline_code` text NOT NULL,
  `res_tran_date` text NOT NULL,
  `res_merchant_name` text NOT NULL,
  `res_version` text NOT NULL,
  `res_EchoServer` text NOT NULL,
  PRIMARY KEY (`res_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result_res`
--

LOCK TABLES `result_res` WRITE;
/*!40000 ALTER TABLE `result_res` DISABLE KEYS */;
/*!40000 ALTER TABLE `result_res` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `token` varchar(99) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `reference_id` int(9) NOT NULL,
  `valid_until_date` datetime DEFAULT NULL,
  `remainingUses` int(2) DEFAULT NULL,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES
('60857719bfd23','password',3,'2021-04-26 10:05:13',1),
('60857f497052c','password',3,'2021-04-26 10:40:09',1),
('60857fb53e96f','password',3,'2021-04-26 10:41:57',1),
('6085a2436f14e','password',3,'2021-04-26 13:09:23',1),
('6085ce0e1e0c4','password',3,'2021-04-26 16:16:14',1),
('6085d38aee1d1','password',3,'2021-04-26 16:39:38',1),
('6085d553a4d50','password',3,'2021-04-26 16:47:15',1),
('6085d5c1b5c6a','password',3,'2021-04-26 16:49:05',1),
('6085d96fe2f87','password',3,'2021-04-26 17:04:47',1),
('6085dccdac282','password',3,'2021-04-26 17:19:09',1),
('6085e06ba44ec','password',3,'2021-04-26 17:34:35',1),
('6086029bea898','password',3,'2021-04-26 20:00:27',1),
('60861832ad541','password',3,'2021-04-26 21:32:34',1),
('60861c0fc4780','password',3,'2021-04-26 21:49:03',1),
('608627f7874a1','verifyFamily',2,'2021-05-02 22:39:51',5),
('608628078bc34','password',3,'2021-04-26 22:40:07',1),
('63ae25e2b31a7','password',3,'2022-12-30 18:42:26',1);
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_settings` (
  `user_id` int(11) NOT NULL,
  `setting_name` varchar(50) NOT NULL,
  `setting_value` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`setting_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_settings`
--

LOCK TABLES `user_settings` WRITE;
/*!40000 ALTER TABLE `user_settings` DISABLE KEYS */;
INSERT INTO `user_settings` VALUES
(0,'ui.email.delimiter',','),
(1,'finance.FY','23'),
(1,'finance.show.payments','true'),
(1,'finance.show.pledges','true'),
(1,'finance.show.since','2016-01-01'),
(1,'ui.email.delimiter',','),
(1,'ui.locale','fr_FR'),
(1,'ui.search.calendar.end',NULL),
(1,'ui.search.calendar.start',NULL),
(1,'ui.style','skin-red'),
(1,'ui.table.size','10'),
(3,'finance.FY','23'),
(3,'finance.show.payments','0'),
(3,'finance.show.pledges','0'),
(3,'finance.show.since','2016-01-01'),
(3,'ui.email.delimiter',','),
(3,'ui.locale','en_US'),
(3,'ui.search.calendar.end',NULL),
(3,'ui.search.calendar.start',NULL),
(3,'ui.style','skin-yellow-light'),
(3,'ui.table.size','10'),
(76,'finance.FY','20'),
(76,'finance.show.payments','0'),
(76,'finance.show.pledges','0'),
(76,'finance.show.since','2016-01-01'),
(76,'ui.email.delimiter',','),
(76,'ui.search.calendar.end',NULL),
(76,'ui.search.calendar.start',NULL),
(76,'ui.style','skin-blue'),
(76,'ui.table.size','10'),
(95,'finance.FY','20'),
(95,'finance.show.payments','0'),
(95,'finance.show.pledges','0'),
(95,'finance.show.since','2016-01-01'),
(95,'ui.email.delimiter',','),
(95,'ui.search.calendar.end',NULL),
(95,'ui.search.calendar.start',NULL),
(95,'ui.style','skin-blue'),
(95,'ui.table.size','10'),
(236,'ui.locale','fr_FR'),
(1200,'finance.show.payments','true'),
(1200,'finance.show.pledges','true'),
(1492,'finance.show.payments','true'),
(1492,'finance.show.pledges','true'),
(1493,'notification.dismissed.system-update-available','true');
/*!40000 ALTER TABLE `user_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_usr`
--

DROP TABLE IF EXISTS `user_usr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_usr` (
  `usr_per_ID` mediumint(9) unsigned NOT NULL DEFAULT 0,
  `usr_Password` varchar(500) NOT NULL DEFAULT '',
  `usr_NeedPasswordChange` tinyint(3) unsigned NOT NULL DEFAULT 1,
  `usr_LastLogin` datetime NOT NULL DEFAULT '2016-01-01 00:00:00',
  `usr_LoginCount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usr_FailedLogins` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_AddRecords` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_EditRecords` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_DeleteRecords` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_MenuOptions` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_ManageGroups` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_Finance` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_Notes` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_Admin` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_SearchLimit` tinyint(4) DEFAULT 10,
  `usr_Style` varchar(50) DEFAULT 'Style.css',
  `usr_showPledges` tinyint(1) NOT NULL DEFAULT 0,
  `usr_showPayments` tinyint(1) NOT NULL DEFAULT 0,
  `usr_showSince` date NOT NULL DEFAULT '2016-01-01',
  `usr_defaultFY` mediumint(9) NOT NULL DEFAULT 10,
  `usr_currentDeposit` mediumint(9) NOT NULL DEFAULT 0,
  `usr_UserName` varchar(32) DEFAULT NULL,
  `usr_apiKey` varchar(255) DEFAULT NULL,
  `group_id` mediumint(8) unsigned DEFAULT NULL,
  `usr_EditSelf` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `usr_CalStart` date DEFAULT NULL,
  `usr_CalEnd` date DEFAULT NULL,
  `usr_CalNoSchool1` date DEFAULT NULL,
  `usr_CalNoSchool2` date DEFAULT NULL,
  `usr_CalNoSchool3` date DEFAULT NULL,
  `usr_CalNoSchool4` date DEFAULT NULL,
  `usr_CalNoSchool5` date DEFAULT NULL,
  `usr_CalNoSchool6` date DEFAULT NULL,
  `usr_CalNoSchool7` date DEFAULT NULL,
  `usr_CalNoSchool8` date DEFAULT NULL,
  `usr_SearchFamily` tinyint(3) DEFAULT NULL,
  `usr_TwoFactorAuthSecret` varchar(255) DEFAULT NULL,
  `usr_TwoFactorAuthLastKeyTimestamp` int(11) DEFAULT NULL,
  `usr_TwoFactorAuthRecoveryCodes` text DEFAULT NULL,
  PRIMARY KEY (`usr_per_ID`),
  UNIQUE KEY `usr_UserName` (`usr_UserName`),
  UNIQUE KEY `usr_apiKey_unique` (`usr_apiKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_usr`
--

LOCK TABLES `user_usr` WRITE;
/*!40000 ALTER TABLE `user_usr` DISABLE KEYS */;
INSERT INTO `user_usr` VALUES
(3,'$2y$12$uWQcp6KU7C4JCTaVH.0hiekfpga36yBVhXG8.M/w9u3MmvHt/NWi2',0,'2025-11-30 02:08:31',2,0,1,1,1,1,1,1,1,0,10,'skin-yellow-light',0,0,'2016-01-01',26,0,'tony.wade@example.com','JZJApQ9XOnF7nvupWZlTWBRrqMtHE9eNcWBTUzEWGqL4Sdqp6C',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4,'$2y$12$e3o8rmvWUYdgzUNB/AAMK.pRvT9rwsIZx4wYB0brOmVPB1UL.HA5S',0,'2016-01-01 00:00:00',0,0,0,0,0,0,0,0,0,0,10,'skin-blue',0,0,'2016-01-01',26,0,'limited.user','limitedUserApiKeyForTesting123456789012345678',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(95,'$2y$12$7R0MqgyidzOqzXPrGbYdkO.y/decFpwSJM..fznzzvT4wiZqaJE4q',0,'2022-12-29 21:01:30',0,0,1,1,0,0,0,0,0,0,10,'skin-blue',0,0,'2016-01-01',26,0,'judith.matthews@example.com',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(99,'$2y$12$OTZ5Y/hvCNVkfQqbQfNjRO/x2cBnx5O3yMJt4jXKw/yu/NjuxTHTK',1,'2025-12-01 20:26:05',0,0,0,0,0,0,0,0,0,0,10,'skin-blue',0,0,'2016-01-01',29,0,'amanda.black@example.com',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(236,'$2y$12$GVDoSSwnvAZ4NrZUOpd0N.zP8mzfnriC4p69L3u1aGQSim0mf0UnK',0,'2026-05-01 16:20:50',2,0,1,1,0,0,1,0,1,0,10,'Style.css',0,0,'2016-01-01',10,0,'jean.resp',NULL,27,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(239,'$2y$12$rvb384gGVeDpF/O4t2NZvOpArO5EJu3ewzAu2pqooWILkjvBD2Q7C',1,'2016-01-01 00:00:00',0,0,1,1,0,0,1,0,1,0,10,'Style.css',0,0,'2016-01-01',10,0,'paul.resp',NULL,28,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(1492,'y2$..9lKEQy.ketgqjx5ocJA.iansWNu.BN0VNipMLOSGnkpwJbUG4F6',1,'2026-05-02 17:33:06',387,5,0,0,0,0,0,0,0,1,10,'skin-red',1,1,'2016-01-01',23,1,'Admin','ajGwpy8Pdai22XDUpqjC5Ob04v0eG7EGgb4vz2bD2juT8YDmfM',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),
(1493,'$2y$12$rzLTS5/gGBUkzlcfiESGpOFYm/zYPGc48w.wum0pTHOyUO23Z6XJa',0,'2026-05-20 11:13:39',9,0,0,0,0,0,0,0,0,1,10,'Style.css',0,0,'2016-01-01',10,0,'Ghislain','3625906c59d4ecabcd6c86d0a53c8494b60579a2',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user_usr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userconfig_ucfg`
--

DROP TABLE IF EXISTS `userconfig_ucfg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `userconfig_ucfg` (
  `ucfg_per_id` mediumint(9) unsigned NOT NULL,
  `ucfg_id` int(11) NOT NULL DEFAULT 0,
  `ucfg_name` varchar(50) NOT NULL DEFAULT '',
  `ucfg_value` text DEFAULT NULL,
  `ucfg_type` enum('text','number','date','boolean','textarea') NOT NULL DEFAULT 'text',
  `ucfg_tooltip` text NOT NULL,
  `ucfg_permission` enum('FALSE','TRUE') NOT NULL DEFAULT 'FALSE',
  `ucfg_cat` varchar(20) NOT NULL,
  PRIMARY KEY (`ucfg_per_id`,`ucfg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userconfig_ucfg`
--

LOCK TABLES `userconfig_ucfg` WRITE;
/*!40000 ALTER TABLE `userconfig_ucfg` DISABLE KEYS */;
INSERT INTO `userconfig_ucfg` VALUES
(0,0,'bEmailMailto','1','boolean','User permission to send email via mailto: links','TRUE',''),
(0,1,'sMailtoDelimiter',',','text','Delimiter to separate emails in mailto: links','TRUE',''),
(0,5,'bCreateDirectory','0','boolean','User permission to create directories','FALSE','SECURITY'),
(0,6,'bExportCSV','0','boolean','User permission to export CSV files','FALSE','SECURITY'),
(0,10,'bAddEvent','0','boolean','Allow user to add new event','FALSE','SECURITY'),
(1,0,'bEmailMailto','1','boolean','User permission to send email via mailto: links','TRUE',''),
(1,1,'sMailtoDelimiter',',','text','user permission to send email via mailto: links','TRUE',''),
(1,5,'bCreateDirectory','1','boolean','User permission to create directories','TRUE',''),
(1,6,'bExportCSV','1','boolean','User permission to export CSV files','TRUE',''),
(3,0,'bEmailMailto','1','boolean','User permission to send email via mailto: links','TRUE',''),
(3,1,'sMailtoDelimiter',',','text','Delimiter to separate emails in mailto: links','TRUE',''),
(3,5,'bCreateDirectory','','boolean','User permission to create directories','FALSE','SECURITY'),
(3,6,'bExportCSV','','boolean','User permission to export CSV files','FALSE','SECURITY'),
(3,10,'bAddEvent','','boolean','Allow user to add new event','FALSE','SECURITY'),
(59,0,'bEmailMailto','1','boolean','User permission to send email via mailto: links','TRUE',''),
(59,1,'sMailtoDelimiter',',','text','Delimiter to separate emails in mailto: links','TRUE',''),
(59,5,'bCreateDirectory','','boolean','User permission to create directories','FALSE','SECURITY'),
(59,6,'bExportCSV','','boolean','User permission to export CSV files','FALSE','SECURITY'),
(59,10,'bAddEvent','','boolean','Allow user to add new event','FALSE','SECURITY'),
(76,0,'bEmailMailto','1','boolean','User permission to send email via mailto: links','TRUE',''),
(76,1,'sMailtoDelimiter',',','text','Delimiter to separate emails in mailto: links','TRUE',''),
(76,5,'bCreateDirectory','','boolean','User permission to create directories','FALSE','SECURITY'),
(76,6,'bExportCSV','','boolean','User permission to export CSV files','FALSE','SECURITY'),
(76,10,'bAddEvent','','boolean','Allow user to add new event','FALSE','SECURITY'),
(95,0,'bEmailMailto','1','boolean','User permission to send email via mailto: links','TRUE',''),
(95,1,'sMailtoDelimiter',',','text','Delimiter to separate emails in mailto: links','TRUE',''),
(95,5,'bCreateDirectory','','boolean','User permission to create directories','FALSE','SECURITY'),
(95,6,'bExportCSV','','boolean','User permission to export CSV files','FALSE','SECURITY'),
(95,10,'bAddEvent','','boolean','Allow user to add new event','FALSE','SECURITY');
/*!40000 ALTER TABLE `userconfig_ucfg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `version_ver`
--

DROP TABLE IF EXISTS `version_ver`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `version_ver` (
  `ver_ID` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `ver_version` varchar(50) NOT NULL DEFAULT '',
  `ver_update_start` datetime DEFAULT NULL,
  `ver_update_end` datetime DEFAULT NULL,
  PRIMARY KEY (`ver_ID`),
  UNIQUE KEY `ver_version` (`ver_version`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `version_ver`
--

LOCK TABLES `version_ver` WRITE;
/*!40000 ALTER TABLE `version_ver` DISABLE KEYS */;
INSERT INTO `version_ver` VALUES
(1,'3.5.0','2019-02-10 20:14:23',NULL),
(2,'3.5.2','2019-09-10 22:54:56','2019-09-10 22:54:56'),
(3,'3.5.4','2019-10-11 22:45:35','2019-10-11 22:45:35'),
(4,'4.0.0','2020-06-16 13:11:20','2020-06-16 13:11:20'),
(5,'4.1.0','2020-06-16 13:11:20','2020-06-16 13:11:21'),
(6,'4.2.3','2020-10-17 01:46:16','2020-10-17 01:46:16'),
(7,'4.3.1','2020-11-23 18:55:02','2020-11-23 18:55:02'),
(8,'4.3.2','2020-12-10 01:57:09','2020-12-10 01:57:09'),
(9,'4.4.0','2021-03-21 17:44:23','2021-03-21 17:44:23'),
(10,'4.4.1','2021-05-09 13:58:09','2021-04-27 13:58:09'),
(11,'4.4.2','2021-05-09 13:58:09','2021-04-27 13:58:09'),
(12,'4.4.3','2021-05-09 13:58:09','2021-04-27 13:58:09'),
(13,'4.4.4','2021-07-08 13:58:09','2021-07-08 13:58:09'),
(14,'4.4.5','2021-07-09 13:58:09','2021-07-09 13:58:09'),
(15,'4.5.0','2021-07-09 13:58:09','2021-09-03 13:58:09'),
(16,'4.5.1','2022-12-03 14:02:00','2022-12-03 14:02:00'),
(17,'4.5.2','2022-12-28 21:42:20','2022-12-28 21:42:20'),
(18,'4.5.3','2023-01-01 20:32:08','2023-01-01 20:32:08'),
(19,'5.0.0','2023-05-06 17:29:55','2023-05-06 17:29:55'),
(20,'5.0.5','2023-10-21 19:04:42','2023-10-21 19:04:42'),
(21,'5.1.0','2023-10-31 23:33:49','2023-10-31 23:33:49'),
(22,'5.2.2','2023-11-05 12:28:43','2023-11-05 12:28:43'),
(23,'5.2.3','2023-11-16 12:39:14','2023-11-16 12:39:14'),
(24,'5.3.0','2023-11-18 11:10:21','2023-11-18 11:10:21'),
(25,'5.3.1','2023-11-21 02:04:10','2023-11-21 02:04:10'),
(27,'5.4.0','2023-12-03 20:27:58','2023-12-03 20:27:58'),
(29,'5.4.3','2024-01-03 23:24:10','2024-01-03 23:24:10'),
(30,'5.5.0','2024-01-03 23:43:18','2024-01-03 23:43:18'),
(31,'5.6.0','2024-03-07 20:35:26','2024-03-07 20:35:26'),
(32,'5.7.0','2024-03-08 11:58:40','2024-03-08 11:58:40'),
(33,'5.8.0','2024-04-25 14:50:41','2024-04-25 14:50:41'),
(35,'5.9.0','2024-07-13 17:23:00','2024-07-13 17:23:00'),
(36,'5.17.0','2024-07-13 17:23:02','2025-03-28 17:23:02'),
(37,'5.18.0','2025-05-10 20:09:48','2025-05-10 20:09:48'),
(38,'5.19.0','2025-09-01 13:44:08','2025-09-01 13:44:08'),
(39,'5.20.0','2025-10-11 15:27:51','2025-10-11 15:27:51'),
(40,'5.21.0','2025-10-13 02:54:08','2025-10-13 02:54:08'),
(41,'5.22.0','2025-10-20 00:31:20','2025-10-20 00:31:20'),
(42,'6.0.0','2025-11-01 21:56:03','2025-11-01 21:56:03'),
(43,'6.0.1','2025-11-15 20:47:13','2025-11-15 20:47:13'),
(44,'6.0.2','2025-11-16 01:28:56','2025-11-16 01:28:56'),
(45,'6.1.0','2025-11-21 02:25:12','2025-11-21 02:25:12'),
(46,'6.2.0','2025-11-21 04:32:38','2025-11-21 04:32:38'),
(47,'6.3.0','2025-11-27 02:22:39','2025-11-27 02:22:39'),
(48,'6.4.0','2025-12-06 02:24:41','2025-12-06 02:24:41'),
(49,'6.5.0','2025-12-13 00:20:35','2025-12-13 00:20:35'),
(50,'6.5.1','2025-12-14 17:34:29','2025-12-14 17:34:29'),
(51,'6.5.2','2025-12-15 00:59:49','2025-12-15 00:59:49'),
(52,'6.5.3','2025-12-15 01:26:13','2025-12-15 01:26:13'),
(53,'6.5.4','2025-12-15 01:31:56','2025-12-15 01:31:56'),
(55,'6.6.0','2025-12-21 00:24:18','2025-12-21 00:24:18'),
(56,'6.6.1','2025-12-26 17:36:40','2025-12-26 17:36:40'),
(57,'6.7.0','2025-12-29 16:58:20','2025-12-29 16:58:20'),
(58,'6.7.1','2026-01-19 18:05:17','2026-01-19 18:05:17'),
(59,'6.7.2','2026-01-25 21:24:56','2026-01-25 21:24:56'),
(60,'6.7.3','2026-01-30 02:27:27','2026-01-30 02:27:27'),
(61,'6.8.0','2026-01-31 16:57:37','2026-01-31 16:57:37'),
(62,'6.8.1','2026-02-01 21:22:06','2026-02-01 21:22:06'),
(63,'7.0.0','2026-02-07 18:19:35','2026-02-07 18:19:35'),
(64,'7.0.1','2026-02-28 01:03:43','2026-02-28 01:03:43'),
(65,'7.0.2','2026-03-05 00:33:03','2026-03-05 00:33:03'),
(66,'7.0.3','2026-03-10 00:56:16','2026-03-10 00:56:16'),
(67,'7.0.4','2026-03-18 17:06:40','2026-03-18 17:06:40'),
(68,'7.0.5','2026-03-18 19:28:55','2026-03-18 19:28:55'),
(69,'7.1.0','2026-03-19 19:04:36','2026-03-19 19:04:36'),
(70,'7.1.1','2026-04-05 14:36:43','2026-04-05 14:36:43'),
(71,'7.1.2','2026-04-06 18:47:07','2026-04-06 18:47:07'),
(72,'7.2.0','2026-04-10 12:27:54','2026-04-10 12:27:54'),
(73,'7.2.1','2026-04-13 21:25:56','2026-04-13 21:25:56'),
(74,'7.2.2','2026-04-17 00:16:04','2026-04-17 00:16:04'),
(75,'7.2.3','2026-04-23 05:18:45','2026-04-23 05:18:45'),
(76,'7.3.0','2026-04-25 15:27:48','2026-04-25 15:27:48'),
(77,'7.3.1','2026-04-26 16:11:39','2026-04-26 16:11:39'),
(78,'7.3.2','2026-04-30 19:48:51','2026-04-30 19:48:51');
/*!40000 ALTER TABLE `version_ver` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volunteeropportunity_vol`
--

DROP TABLE IF EXISTS `volunteeropportunity_vol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `volunteeropportunity_vol` (
  `vol_ID` int(3) NOT NULL AUTO_INCREMENT,
  `vol_Order` int(3) NOT NULL DEFAULT 0,
  `vol_Active` enum('true','false') NOT NULL DEFAULT 'true',
  `vol_Name` varchar(30) DEFAULT NULL,
  `vol_Description` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`vol_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volunteeropportunity_vol`
--

LOCK TABLES `volunteeropportunity_vol` WRITE;
/*!40000 ALTER TABLE `volunteeropportunity_vol` DISABLE KEYS */;
/*!40000 ALTER TABLE `volunteeropportunity_vol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `whycame_why`
--

DROP TABLE IF EXISTS `whycame_why`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `whycame_why` (
  `why_ID` mediumint(9) NOT NULL AUTO_INCREMENT,
  `why_per_ID` mediumint(9) NOT NULL DEFAULT 0,
  `why_join` text NOT NULL,
  `why_come` text NOT NULL,
  `why_suggest` text NOT NULL,
  `why_hearOfUs` text NOT NULL,
  PRIMARY KEY (`why_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `whycame_why`
--

LOCK TABLES `whycame_why` WRITE;
/*!40000 ALTER TABLE `whycame_why` DISABLE KEYS */;
/*!40000 ALTER TABLE `whycame_why` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'churchcrm'
--

--
-- Dumping routines for database 'churchcrm'
--

--
-- Final view structure for view `email_count`
--

/*!50001 DROP VIEW IF EXISTS `email_count`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`churchcrm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `email_count` AS select `email_list`.`email` AS `email`,count(0) AS `total` from `email_list` group by `email_list`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `email_list`
--

/*!50001 DROP VIEW IF EXISTS `email_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb3 */;
/*!50001 SET character_set_results     = utf8mb3 */;
/*!50001 SET collation_connection      = utf8mb3_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`churchcrm`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `email_list` AS select `family_fam`.`fam_Email` AS `email`,'family' AS `type`,`family_fam`.`fam_ID` AS `id` from `family_fam` where `family_fam`.`fam_Email` is not null and `family_fam`.`fam_Email` <> '' union select `person_per`.`per_Email` AS `email`,'person_home' AS `type`,`person_per`.`per_ID` AS `id` from `person_per` where `person_per`.`per_Email` is not null and `person_per`.`per_Email` <> '' union select `person_per`.`per_WorkEmail` AS `email`,'person_work' AS `type`,`person_per`.`per_ID` AS `id` from `person_per` where `person_per`.`per_WorkEmail` is not null and `person_per`.`per_WorkEmail` <> '' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-20 15:49:22
